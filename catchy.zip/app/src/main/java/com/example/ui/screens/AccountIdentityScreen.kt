package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CatchyButton
import com.example.ui.components.CatchyTextField
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchySuccess
import com.example.ui.theme.CatchyViolet
import com.example.ui.theme.CatchyWarning
import com.example.ui.viewmodel.AccountViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccountIdentityScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val verificationDispatch by viewModel.latestVerificationDispatch.collectAsState()
  val verificationFeedback by viewModel.verificationFeedback.collectAsState()
  val isVerifying by viewModel.isVerifying.collectAsState()
  val isEditingProfile by viewModel.isEditingProfile.collectAsState()
  val editFullName by viewModel.editFullName.collectAsState()
  val editPhotoUri by viewModel.editPhotoUri.collectAsState()
  val profileFeedback by viewModel.profileFeedback.collectAsState()

  val scrollState = rememberScrollState()
  val context = LocalContext.current

  val user = currentUser

  if (user == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background),
      contentAlignment = Alignment.Center
    ) {
      CircularProgressIndicator(color = CatchyIndigoLight)
    }
    return
  }

  // Dialog for editing allowed profile info (Full Name & Photo only)
  if (isEditingProfile) {
    EditProfileDialog(
      fullName = editFullName,
      onFullNameChange = { viewModel.onEditFullNameChange(it) },
      selectedPhotoUri = editPhotoUri,
      onPhotoSelected = { viewModel.onEditPhotoUriChange(it) },
      onSave = { viewModel.saveEditableProfile() },
      onDismiss = { viewModel.cancelEditingProfile() }
    )
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(horizontal = 20.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top Navigation / Brand Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan)))
              .padding(1.5.dp)
          ) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(9.dp))
                .background(MaterialTheme.colorScheme.surface),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "C",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                color = CatchyCyan
              )
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Catchy",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
            Text(
              text = "Account System",
              style = MaterialTheme.typography.bodySmall,
              color = CatchyCyan
            )
          }
        }

        OutlinedButton(
          onClick = { viewModel.signOut() },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
          modifier = Modifier.testTag("sign_out_button")
        ) {
          Icon(
            imageVector = Icons.Default.ExitToApp,
            contentDescription = "Sign Out",
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = stringResource(R.string.sign_out_button),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Profile Identity Hero Card
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Profile Photo Avatar
          val avatarColor = when (user.profilePhotoUri) {
            "avatar_1" -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
            "avatar_2" -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
            "avatar_3" -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
            else -> listOf(Color(0xFF10B981), Color(0xFF059669))
          }

          Box(
            modifier = Modifier
              .size(82.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(avatarColor))
              .border(3.dp, CatchyIndigoLight.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = user.fullName.take(2).uppercase(),
              style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Full Name (Editable Profile Information)
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Text(
              text = user.fullName,
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(
              onClick = { viewModel.startEditingProfile(user.fullName, user.profilePhotoUri) },
              modifier = Modifier
                .size(32.dp)
                .testTag("edit_profile_button")
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit Profile Name or Photo",
                tint = CatchyCyan,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Text(
            text = user.email,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(16.dp))

          // AUTOMATIC UNIQUE USER ID BADGE (Prominently displayed)
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            border = androidx.compose.foundation.BorderStroke(1.dp, CatchyIndigo.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked Identifier",
                    tint = CatchyCyan,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "AUTOMATIC USER ID",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      letterSpacing = 1.sp
                    ),
                    color = CatchyCyan
                  )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = user.userId,
                  style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                  ),
                  color = Color.White
                )
              }

              IconButton(
                onClick = {
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  val clip = ClipData.newPlainText("Catchy User ID", user.userId)
                  clipboard.setPrimaryClip(clip)
                  Toast.makeText(context, "User ID copied: ${user.userId}", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.testTag("copy_userid_button")
              ) {
                Icon(
                  imageVector = Icons.Default.ContentCopy,
                  contentDescription = "Copy User ID",
                  tint = CatchyIndigoLight
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Email Verification Status Chip
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(
                if (user.isEmailVerified) CatchySuccess.copy(alpha = 0.15f)
                else CatchyWarning.copy(alpha = 0.15f)
              )
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(
              imageVector = if (user.isEmailVerified) Icons.Default.VerifiedUser else Icons.Default.Info,
              contentDescription = null,
              tint = if (user.isEmailVerified) CatchySuccess else CatchyWarning,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (user.isEmailVerified) "Email Verified & Associated" else "Pending Email Verification",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = if (user.isEmailVerified) CatchySuccess else CatchyWarning
            )
          }

          if (!profileFeedback.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = profileFeedback ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = CatchySuccess
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // EMAIL VERIFICATION ACTION CARD (If not verified)
      if (!user.isEmailVerified) {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyWarning.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Email,
                contentDescription = null,
                tint = CatchyWarning,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Email Verification Dispatch",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CatchyWarning
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "A verification email has been dispatched to ${user.email}. Use your verification code to confirm ownership of this account.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Show active verification code from dispatch for testing
            user.emailVerificationCode?.let { code ->
              Spacer(modifier = Modifier.height(10.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(CatchyIndigo.copy(alpha = 0.2f))
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(
                  text = "Security Code: $code",
                  style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                  ),
                  color = CatchyCyan
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = { viewModel.verifyEmail(user.emailVerificationCode) },
                enabled = !isVerifying,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CatchySuccess),
                modifier = Modifier
                  .weight(1f)
                  .testTag("verify_email_button")
              ) {
                if (isVerifying) {
                  CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                } else {
                  Icon(imageVector = Icons.Default.MarkEmailRead, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Verify Now", fontWeight = FontWeight.Bold)
                }
              }

              OutlinedButton(
                onClick = { viewModel.resendVerificationEmail() },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CatchyIndigoLight),
                border = androidx.compose.foundation.BorderStroke(1.dp, CatchyIndigoLight),
                modifier = Modifier
                  .weight(1f)
                  .testTag("resend_verification_button")
              ) {
                Text("Resend Code", fontWeight = FontWeight.SemiBold)
              }
            }

            if (!verificationFeedback.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = verificationFeedback ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = if (verificationFeedback?.contains("success", ignoreCase = true) == true) CatchySuccess else MaterialTheme.colorScheme.error
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }

      // FIXED CORE ACCOUNT INFORMATION (Section 3)
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(
              imageVector = Icons.Default.Shield,
              contentDescription = null,
              tint = CatchyIndigoLight,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Fixed Core Account Identity",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Fixed info notice banner
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
              .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
              .padding(10.dp)
          ) {
            Row(verticalAlignment = Alignment.Top) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(16.dp).padding(top = 2.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stringResource(R.string.fixed_info_notice),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // List of Fixed Identity Attributes
          FixedIdentityRow(label = "Unique User ID", value = user.userId, isMonospace = true)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Registered Email", value = user.email)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Date of Birth", value = user.dateOfBirth)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Gender", value = user.gender)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Address / Location", value = user.addressLocation)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Education Status", value = user.educationStatus)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Occupation Status", value = user.occupationStatus)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Skills", value = user.skills)
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 10.dp))

          FixedIdentityRow(label = "Marital Status", value = user.maritalStatus)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // EDITABLE PROFILE DETAILS CARD (Section 3)
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Editable Profile Details",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
            }

            TextButton(
              onClick = { viewModel.startEditingProfile(user.fullName, user.profilePhotoUri) },
              modifier = Modifier.testTag("open_edit_profile_dialog")
            ) {
              Text("Edit", color = CatchyCyan, fontWeight = FontWeight.Bold)
            }
          }

          Text(
            text = stringResource(R.string.editable_info_notice),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Display Name",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = user.fullName,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onBackground
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(CatchyIndigo.copy(alpha = 0.15f))
                .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(
                text = "Editable",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CatchyIndigoLight
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // FUTURE DATA ARCHITECTURE READINESS HOOKS (Section 7)
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Account Architecture Ready",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Connected internal identity [${user.id.take(8)}...] ready for Catchy expansion modules:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(10.dp))

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            val modules = listOf(
              "Profile", "Friends", "Following", "Chat", "Messages",
              "Notifications", "Reels", "Communities", "Catchy Help", "Catchy Solutions"
            )
            modules.forEach { moduleName ->
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(MaterialTheme.colorScheme.surface)
                  .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = moduleName,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun FixedIdentityRow(
  label: String,
  value: String,
  isMonospace: Boolean = false
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = value,
        style = if (isMonospace) {
          MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        } else {
          MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
        },
        color = MaterialTheme.colorScheme.onBackground
      )
      Spacer(modifier = Modifier.width(6.dp))
      Icon(
        imageVector = Icons.Default.Lock,
        contentDescription = "Fixed and locked",
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.size(13.dp)
      )
    }
  }
}

@Composable
private fun EditProfileDialog(
  fullName: String,
  onFullNameChange: (String) -> Unit,
  selectedPhotoUri: String?,
  onPhotoSelected: (String?) -> Unit,
  onSave: () -> Unit,
  onDismiss: () -> Unit
) {
  val avatarPresets = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Edit Profile Details",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "You may only modify your Full Name and Profile Photo. Core account attributes are permanently locked.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        CatchyTextField(
          value = fullName,
          onValueChange = onFullNameChange,
          label = "Full Name",
          placeholder = "Enter your full name",
          testTag = "edit_fullname_input"
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = "Select Profile Avatar",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          avatarPresets.forEachIndexed { index, avatarId ->
            val isSelected = selectedPhotoUri == avatarId
            val bgColors = when (index) {
              0 -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
              1 -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
              2 -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
              else -> listOf(Color(0xFF10B981), Color(0xFF059669))
            }

            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(bgColors))
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) CatchyCyan else Color.Transparent,
                  shape = CircleShape
                )
                .clickable { onPhotoSelected(avatarId) }
                .testTag("edit_avatar_preset_$index"),
              contentAlignment = Alignment.Center
            ) {
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = "Selected Avatar",
                  tint = Color.White
                )
              } else {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = Color.White.copy(alpha = 0.8f),
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onSave,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
        modifier = Modifier.testTag("save_profile_button")
      ) {
        Text("Save Changes")
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("cancel_edit_profile_button")
      ) {
        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    },
    shape = RoundedCornerShape(20.dp),
    containerColor = MaterialTheme.colorScheme.surface
  )
}
