package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PeopleOutline
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.CatchyPost
import com.example.data.model.UserAccount
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyDarkSurface
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoDark
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchyViolet
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyNavTab
import com.example.ui.viewmodel.HelpCenterTab
import com.example.ui.viewmodel.CatchyNotificationItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Catchy Home Screen featuring:
 * - Header: [Catchy Logo] Catchy ... ? 🔔 ☰
 * - Search: 🔍 Search Catchy
 * - Post Composer: "What's on your mind?" with Photo, Video, Help actions
 * - Feed and community members discovery
 */
@Composable
fun CatchyFeedScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val feedPosts by viewModel.feedPosts.collectAsState()
  val otherUsers by viewModel.otherUsers.collectAsState()
  val newPostInput by viewModel.newPostInput.collectAsState()
  val postAttachmentType by viewModel.postAttachmentType.collectAsState()
  val postAttachmentLabel by viewModel.postAttachmentLabel.collectAsState()
  val searchQuery by viewModel.homeSearchQuery.collectAsState()
  val notifications by viewModel.notifications.collectAsState()
  val showNotificationsSheet by viewModel.showNotificationsSheet.collectAsState()
  val showCatchyMenuSheet by viewModel.showCatchyMenuSheet.collectAsState()
  val showHelpDialog by viewModel.showHelpDialog.collectAsState()
  val showFriendsSheet by viewModel.showFriendsSheet.collectAsState()

  // New Home Screen States
  val likedPostIds by viewModel.likedPostIds.collectAsState()
  val trendingTopics by viewModel.trendingTopics.collectAsState()
  val selectedTrendingTag by viewModel.selectedTrendingTag.collectAsState()
  val showFullTrending by viewModel.showFullTrending.collectAsState()
  val helpPosts by viewModel.helpPosts.collectAsState()
  val activeHelpPost by viewModel.activeHelpPost.collectAsState()
  val activeHelpAnswers by viewModel.activeHelpAnswers.collectAsState()
  val helpAnswerInput by viewModel.helpAnswerInput.collectAsState()
  val isCreatingHelpPost by viewModel.isCreatingHelpPost.collectAsState()
  val helpPostTitleInput by viewModel.helpPostTitleInput.collectAsState()
  val helpPostDescInput by viewModel.helpPostDescInput.collectAsState()
  val helpPostLocationInput by viewModel.helpPostLocationInput.collectAsState()
  val stories by viewModel.stories.collectAsState()
  val activeStory by viewModel.activeStory.collectAsState()
  val isAddingStory by viewModel.isAddingStory.collectAsState()
  val storyTextInput by viewModel.storyTextInput.collectAsState()
  val selectedGradientIndex by viewModel.selectedGradientIndex.collectAsState()
  val activeCommentPost by viewModel.activeCommentPost.collectAsState()
  val activePostComments by viewModel.activePostComments.collectAsState()
  val commentInput by viewModel.commentInput.collectAsState()
  val editingPost by viewModel.editingPost.collectAsState()
  val editPostInput by viewModel.editPostInput.collectAsState()
  val postDeleteTarget by viewModel.postDeleteTarget.collectAsState()

  val context = LocalContext.current
  var showPhotoPicker by remember { mutableStateOf(false) }
  var showVideoPicker by remember { mutableStateOf(false) }

  val unreadNotifsCount = notifications.count { !it.isRead }
  val showHelpCenter by viewModel.showHelpCenter.collectAsState()
  val showJobsScreen by viewModel.showJobsScreen.collectAsState()
  val showInvestmentScreen by viewModel.showInvestmentScreen.collectAsState()
  val showBusinessScreen by viewModel.showBusinessScreen.collectAsState()
  val showCommunityScreen by viewModel.showCommunityScreen.collectAsState()

  // Filtered posts and users for search query
  val isSearching = searchQuery.isNotBlank()
  val filteredPosts = if (isSearching) {
    val q = searchQuery.trim().lowercase()
    feedPosts.filter {
      it.content.lowercase().contains(q) ||
        it.authorName.lowercase().contains(q) ||
        it.authorUserId.lowercase().contains(q)
    }
  } else if (selectedTrendingTag != null) {
    val tag = selectedTrendingTag!!.lowercase()
    feedPosts.filter {
      it.content.lowercase().contains(tag) ||
        it.hashtags?.lowercase()?.contains(tag) == true
    }
  } else {
    feedPosts
  }

  val filteredUsers = if (isSearching) {
    val q = searchQuery.trim().lowercase()
    otherUsers.filter {
      it.fullName.lowercase().contains(q) ||
        it.userId.lowercase().contains(q) ||
        it.bio.lowercase().contains(q)
    }
  } else {
    emptyList()
  }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // 1. HOME HEADER: [Catchy Logo] Catchy                         ?   🔔   ☰
      item {
        Spacer(modifier = Modifier.height(4.dp))
        CatchyHomeHeader(
          unreadCount = unreadNotifsCount,
          onHelpClick = { viewModel.openHelpCenter() },
          onNotificationsClick = { viewModel.openNotifications() },
          onMenuClick = { viewModel.openCatchyMenu() }
        )
      }

      // 2. SEARCH AREA: 🔍 Search Catchy
      item {
        CatchySearchBar(
          query = searchQuery,
          onQueryChange = { viewModel.onHomeSearchQueryChange(it) },
          onClear = { viewModel.clearHomeSearchQuery() }
        )
      }

      // 3. CATCHY GO: Cinematic video experience entry point
      item {
        Spacer(modifier = Modifier.height(2.dp))
        CatchyGoButton(
          onClick = { viewModel.selectTab(CatchyNavTab.REELS) }
        )
        Spacer(modifier = Modifier.height(2.dp))
      }

      // If actively searching, show search results view
      if (isSearching) {
        if (filteredUsers.isNotEmpty()) {
          item {
            Text(
              text = "People Matching \"$searchQuery\"",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan,
              modifier = Modifier.padding(top = 4.dp)
            )
          }

          items(filteredUsers, key = { "search_user_${it.id}" }) { user ->
            SearchUserCard(
              user = user,
              onProfileClick = { viewModel.openUserProfile(user) },
              onMessageClick = { viewModel.openChatWithUser(user) }
            )
          }
        }

        item {
          Text(
            text = "Posts Matching \"$searchQuery\"",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = CatchyCyan,
            modifier = Modifier.padding(top = 8.dp)
          )
        }

        if (filteredPosts.isEmpty() && filteredUsers.isEmpty()) {
          item {
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Icon(
                  imageVector = Icons.Default.Search,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                  modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = "No results found for \"$searchQuery\"",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                TextButton(onClick = { viewModel.clearHomeSearchQuery() }) {
                  Text("Clear Search", color = CatchyCyan)
                }
              }
            }
          }
        } else {
          items(filteredPosts, key = { "search_post_${it.id}" }) { post ->
            FeedPostCard(
              post = post,
              isLiked = likedPostIds.contains(post.id),
              isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
              onAuthorClick = {
                val matchingUser = otherUsers.find { it.userId == post.authorUserId }
                if (matchingUser != null) {
                  viewModel.openUserProfile(matchingUser)
                } else if (currentUser != null && post.authorUserId == currentUser!!.userId) {
                  viewModel.selectTab(CatchyNavTab.PROFILE)
                }
              },
              onLikeClick = { viewModel.togglePostLike(post.id) },
              onCommentClick = { viewModel.openComments(post) },
              onShareClick = {
                Toast.makeText(context, "Post shared to clipboard", Toast.LENGTH_SHORT).show()
              },
              onEditClick = { viewModel.startEditPost(post) },
              onDeleteClick = { viewModel.requestDeletePost(post) },
              onHashtagClick = { tag -> viewModel.selectTrendingTag(tag) }
            )
          }
        }
      } else {
        // Standard Home Feed Content (When not searching)

        // 1. POST COMPOSER: "What's on your mind?" with Photo, Video, Help, Post
        item {
          CatchyPostComposer(
            currentUser = currentUser,
            inputText = newPostInput,
            onInputChange = { viewModel.onNewPostInputChange(it) },
            attachmentType = postAttachmentType,
            attachmentLabel = postAttachmentLabel,
            onClearAttachment = { viewModel.clearPostAttachment() },
            onPhotoClick = { showPhotoPicker = true },
            onVideoClick = { showVideoPicker = true },
            onHelpClick = { viewModel.openHelpCenter() },
            onPublish = { viewModel.publishPost() }
          )
        }

        // 2. STORIES SECTION (Compact carousel)
        item {
          CatchyStoriesSection(
            currentUser = currentUser,
            stories = stories,
            onAddStoryClick = { viewModel.openAddStory() },
            onStoryClick = { viewModel.openStory(it) }
          )
        }

        // 3. TRENDING SECTION (Compact topic chips)
        item {
          CatchyTrendingSection(
            trendingTopics = trendingTopics,
            selectedTag = selectedTrendingTag,
            onTagClick = { viewModel.selectTrendingTag(it) },
            onOpenTrendingPage = { viewModel.openTrendingPage() }
          )
        }

        // 4. CATCHY COMMUNITY (Compact member pills)
        if (otherUsers.isNotEmpty()) {
          item {
            CommunityMembersSection(
              users = otherUsers,
              onUserClick = { viewModel.openUserProfile(it) }
            )
          }
        }

        // Filter Header if trending tag active
        if (selectedTrendingTag != null) {
          item {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = CatchyIndigo.copy(alpha = 0.15f),
              border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.35f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Tag,
                    contentDescription = null,
                    tint = CatchyCyan,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "Showing posts for $selectedTrendingTag",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = CatchyCyan
                  )
                }

                TextButton(
                  onClick = { viewModel.selectTrendingTag(selectedTrendingTag!!) }
                ) {
                  Text("Show All", color = CatchyCyan, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }

        // 5. MAIN SOCIAL FEED POSTS LIST
        val postsList = filteredPosts
        if (postsList.isEmpty()) {
          item(key = "empty_feed_help") {
            CatchyHelpSection(
              helpPosts = helpPosts,
              onHelpPostClick = { viewModel.openHelpDetail(it) },
              onCreateHelpPostClick = { viewModel.openCreateHelpPost() },
              onSeeAllClick = { viewModel.openHelpCenter() }
            )
          }
        } else {
          postsList.forEachIndexed { index, post ->
            // Catchy Help appears inline as a community card between posts
            if (index == 2) {
              item(key = "inline_help_section") {
                CatchyHelpSection(
                  helpPosts = helpPosts,
                  onHelpPostClick = { viewModel.openHelpDetail(it) },
                  onCreateHelpPostClick = { viewModel.openCreateHelpPost() },
                  onSeeAllClick = { viewModel.openHelpCenter() }
                )
              }
            }

            item(key = post.id) {
              FeedPostCard(
                post = post,
                isLiked = likedPostIds.contains(post.id),
                isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
                onAuthorClick = {
                  val matchingUser = otherUsers.find { it.userId == post.authorUserId }
                  if (matchingUser != null) {
                    viewModel.openUserProfile(matchingUser)
                  } else if (currentUser != null && post.authorUserId == currentUser!!.userId) {
                    viewModel.selectTab(CatchyNavTab.PROFILE)
                  }
                },
                onLikeClick = { viewModel.togglePostLike(post.id) },
                onCommentClick = { viewModel.openComments(post) },
                onShareClick = {
                  Toast.makeText(context, "Post shared to clipboard", Toast.LENGTH_SHORT).show()
                },
                onEditClick = { viewModel.startEditPost(post) },
                onDeleteClick = { viewModel.requestDeletePost(post) },
                onHashtagClick = { tag -> viewModel.selectTrendingTag(tag) }
              )
            }
          }

          if (postsList.size < 2) {
            item(key = "inline_help_section_end") {
              CatchyHelpSection(
                helpPosts = helpPosts,
                onHelpPostClick = { viewModel.openHelpDetail(it) },
                onCreateHelpPostClick = { viewModel.openCreateHelpPost() },
                onSeeAllClick = { viewModel.openHelpCenter() }
              )
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(84.dp))
      }
    }

    // Modal / Sheet Overlays
    if (showNotificationsSheet) {
      CatchyNotificationsDialog(
        notifications = notifications,
        onDismiss = { viewModel.closeNotifications() },
        onMarkAllRead = { viewModel.markAllNotificationsRead() }
      )
    }

    if (showCatchyMenuSheet) {
      CatchyMenuSheet(
        currentUser = currentUser,
        onDismiss = { viewModel.closeCatchyMenu() },
        onSelectTab = { tab ->
          viewModel.closeCatchyMenu()
          viewModel.selectTab(tab)
        },
        onFriendsClick = {
          viewModel.closeCatchyMenu()
          viewModel.openFriends()
        },
        onCommunityClick = {
          viewModel.closeCatchyMenu()
          viewModel.openCommunityCenter()
        },
        onJobsClick = {
          viewModel.closeCatchyMenu()
          viewModel.openJobsCenter()
        },
        onInvestmentClick = {
          viewModel.closeCatchyMenu()
          viewModel.openInvestmentCenter()
        },
        onBusinessClick = {
          viewModel.closeCatchyMenu()
          viewModel.openBusinessCenter()
        },
        onAdsClick = {
          viewModel.closeCatchyMenu()
          viewModel.onArticleSearchQueryChange("ads")
          viewModel.openHelpCenter(HelpCenterTab.ARTICLES)
        },
        onReachClick = {
          viewModel.closeCatchyMenu()
          viewModel.onArticleSearchQueryChange("Catchy Reach")
          viewModel.openHelpCenter(HelpCenterTab.ARTICLES)
        },
        onMonetizationClick = {
          viewModel.closeCatchyMenu()
          viewModel.onArticleSearchQueryChange("monetization")
          viewModel.openHelpCenter(HelpCenterTab.ARTICLES)
        },
        onNotificationsClick = {
          viewModel.closeCatchyMenu()
          viewModel.openNotifications()
        },
        onHelpClick = {
          viewModel.closeCatchyMenu()
          viewModel.openHelpCenter()
        },
        onLogout = {
          viewModel.closeCatchyMenu()
          viewModel.signOut()
        }
      )
    }

    if (showFriendsSheet) {
      CatchyFriendsDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeFriends() }
      )
    }

    if (showHelpCenter || showHelpDialog) {
      CatchyHelpCenterDialog(
        viewModel = viewModel,
        onDismiss = {
          viewModel.closeHelpCenter()
          viewModel.closeHelpDialog()
        }
      )
    }

    if (showJobsScreen) {
      CatchyJobsDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeJobsCenter() }
      )
    }

    if (showInvestmentScreen) {
      CatchyInvestmentDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeInvestmentCenter() }
      )
    }

    if (showBusinessScreen) {
      CatchyBusinessDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeBusinessCenter() }
      )
    }

    if (showCommunityScreen) {
      CatchyCommunityDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeCommunityCenter() }
      )
    }

    if (showPhotoPicker) {
      PhotoAttachmentDialog(
        onDismiss = { showPhotoPicker = false },
        onPhotoSelected = { label ->
          viewModel.setPostAttachment(type = "photo", label = label)
          showPhotoPicker = false
        }
      )
    }

    if (showVideoPicker) {
      VideoAttachmentDialog(
        onDismiss = { showVideoPicker = false },
        onVideoSelected = { label ->
          viewModel.setPostAttachment(type = "video", label = label)
          showVideoPicker = false
        }
      )
    }

    // Story Dialogs
    if (activeStory != null) {
      CatchyStoryViewerDialog(
        story = activeStory!!,
        onDismiss = { viewModel.closeStory() }
      )
    }

    if (isAddingStory) {
      CatchyAddStoryDialog(
        inputText = storyTextInput,
        onInputChange = { viewModel.onStoryTextChange(it) },
        selectedGradient = selectedGradientIndex,
        onSelectGradient = { viewModel.setStoryGradient(it) },
        onPublish = { viewModel.publishStory() },
        onDismiss = { viewModel.closeAddStory() }
      )
    }

    // Trending Full Page Dialog
    if (showFullTrending) {
      CatchyTrendingDialog(
        trendingTopics = trendingTopics,
        selectedTag = selectedTrendingTag,
        onTagSelected = { viewModel.selectTrendingTag(it) },
        onDismiss = { viewModel.closeTrendingPage() }
      )
    }

    // Help Dialogs
    if (activeHelpPost != null) {
      CatchyHelpDetailDialog(
        helpPost = activeHelpPost!!,
        answers = activeHelpAnswers,
        answerInput = helpAnswerInput,
        onAnswerInputChange = { viewModel.onHelpAnswerInputChange(it) },
        onSubmitAnswer = { viewModel.submitHelpAnswer() },
        onDismiss = { viewModel.closeHelpDetail() }
      )
    }

    if (isCreatingHelpPost) {
      CatchyCreateHelpDialog(
        titleInput = helpPostTitleInput,
        onTitleChange = { viewModel.onHelpTitleChange(it) },
        descInput = helpPostDescInput,
        onDescChange = { viewModel.onHelpDescChange(it) },
        locationInput = helpPostLocationInput,
        onLocationChange = { viewModel.onHelpLocationChange(it) },
        onPublish = { viewModel.publishHelpPost() },
        onDismiss = { viewModel.closeCreateHelpPost() }
      )
    }

    // Post Comments Dialog
    if (activeCommentPost != null) {
      CatchyCommentsDialog(
        post = activeCommentPost!!,
        comments = activePostComments,
        commentInput = commentInput,
        onCommentInputChange = { viewModel.onCommentInputChange(it) },
        onSubmitComment = { viewModel.submitComment() },
        onDismiss = { viewModel.closeComments() }
      )
    }

    // Post Edit Dialog
    if (editingPost != null) {
      CatchyEditPostDialog(
        post = editingPost!!,
        editInput = editPostInput,
        onInputChange = { viewModel.onEditPostInputChange(it) },
        onSave = { viewModel.saveEditPost() },
        onCancel = { viewModel.cancelEditPost() }
      )
    }

    // Post Delete Confirmation Dialog
    if (postDeleteTarget != null) {
      CatchyDeletePostConfirmDialog(
        post = postDeleteTarget!!,
        onConfirm = { viewModel.confirmDeletePost() },
        onCancel = { viewModel.cancelDeletePost() }
      )
    }
  }
}

/**
 * Clean Home Header:
 * [Official Catchy Logo] Catchy                         ?   🔔   ☰
 * The "?" icon is a clean, premium Help icon opening Catchy Help & Community Support.
 */
@Composable
private fun CatchyHomeHeader(
  unreadCount: Int,
  onHelpClick: () -> Unit,
  onNotificationsClick: () -> Unit,
  onMenuClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    // Left: Catchy Logo and brand name
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.testTag("home_header_branding")
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(
            Brush.linearGradient(
              colors = listOf(CatchyIndigo, CatchyViolet, CatchyCyan)
            )
          )
          .padding(1.5.dp)
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(9.dp))
            .background(MaterialTheme.colorScheme.surface),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_catchy_logo),
            contentDescription = "Catchy Logo",
            modifier = Modifier
              .size(28.dp)
              .clip(RoundedCornerShape(7.dp))
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Text(
        text = "Catchy",
        style = MaterialTheme.typography.titleLarge.copy(
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 0.5.sp
        ),
        color = MaterialTheme.colorScheme.onBackground
      )

      Box(
        modifier = Modifier
          .padding(start = 6.dp)
          .size(6.dp)
          .clip(CircleShape)
          .background(CatchyCyan)
      )
    }

    // Right: ?   🔔   ☰
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      // ? Clean Premium Help Icon
      IconButton(
        onClick = onHelpClick,
        modifier = Modifier
          .size(42.dp)
          .testTag("home_help_button")
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(1.dp, CatchyCyan.copy(alpha = 0.4f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.HelpOutline,
            contentDescription = "Help & Community Support",
            tint = CatchyCyan,
            modifier = Modifier.size(19.dp)
          )
        }
      }

      // Notification Icon 🔔
      Box {
        IconButton(
          onClick = onNotificationsClick,
          modifier = Modifier
            .size(42.dp)
            .testTag("home_notification_button")
        ) {
          Icon(
            imageVector = Icons.Default.Notifications,
            contentDescription = "Notifications",
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.size(24.dp)
          )
        }

        if (unreadCount > 0) {
          Box(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(top = 6.dp, end = 6.dp)
              .size(9.dp)
              .clip(CircleShape)
              .background(CatchyCyan)
              .border(1.5.dp, MaterialTheme.colorScheme.background, CircleShape)
          )
        }
      }

      // Menu Icon ☰
      IconButton(
        onClick = onMenuClick,
        modifier = Modifier
          .size(42.dp)
          .testTag("home_menu_button")
      ) {
        Icon(
          imageVector = Icons.Default.Menu,
          contentDescription = "Catchy Menu",
          tint = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.size(24.dp)
        )
      }
    }
  }
}

/**
 * Clean Search Bar:
 * 🔍 Search Catchy
 */
@Composable
private fun CatchySearchBar(
  query: String,
  onQueryChange: (String) -> Unit,
  onClear: () -> Unit
) {
  OutlinedTextField(
    value = query,
    onValueChange = onQueryChange,
    modifier = Modifier
      .fillMaxWidth()
      .testTag("search_catchy_bar"),
    placeholder = {
      Text(
        text = "Search Catchy",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
      )
    },
    leadingIcon = {
      Icon(
        imageVector = Icons.Default.Search,
        contentDescription = "Search Catchy",
        tint = if (query.isNotBlank()) CatchyCyan else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(20.dp)
      )
    },
    trailingIcon = {
      if (query.isNotBlank()) {
        IconButton(onClick = onClear) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Clear search",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    },
    shape = RoundedCornerShape(16.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedBorderColor = CatchyCyan,
      unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
      focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
      unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
    ),
    singleLine = true
  )
}

/**
 * Community Members Discovery Carousel
 */
@Composable
private fun CommunityMembersSection(
  users: List<UserAccount>,
  onUserClick: (UserAccount) -> Unit
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(end = 8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.PeopleOutline,
          contentDescription = null,
          tint = CatchyIndigoLight,
          modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Community",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        items(users, key = { it.id }) { user ->
          CommunityMemberBubble(
            user = user,
            onClick = { onUserClick(user) }
          )
        }
      }
    }
  }
}

/**
 * Clean Post Composer:
 * "What's on your mind?"
 * Primary actions:
 * 📷 Photo
 * 🎥 Video
 * 🆘 Help
 * "Help" connects directly to Catchy Help without creating a bottom nav tab.
 */
@Composable
private fun CatchyPostComposer(
  currentUser: UserAccount?,
  inputText: String,
  onInputChange: (String) -> Unit,
  attachmentType: String?,
  attachmentLabel: String?,
  onClearAttachment: () -> Unit,
  onPhotoClick: () -> Unit,
  onVideoClick: () -> Unit,
  onHelpClick: () -> Unit,
  onPublish: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("post_composer_card")
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      // Top row: Author avatar + "What's on your mind?" field
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        val initials = currentUser?.fullName?.take(2)?.uppercase() ?: "CU"
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = initials,
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        OutlinedTextField(
          value = inputText,
          onValueChange = onInputChange,
          placeholder = {
            Text(
              text = "What's on your mind?",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
          },
          modifier = Modifier
            .weight(1f)
            .testTag("composer_input_field"),
          minLines = 1,
          maxLines = 3,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CatchyCyan,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
          )
        )
      }

      // Attachment preview chip (Photo or Video)
      if (attachmentType != null) {
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = CatchyCyan.copy(alpha = 0.12f),
          border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.35f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (attachmentType == "photo") Icons.Default.PhotoCamera else Icons.Default.Videocam,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${if (attachmentType == "photo") "Photo" else "Video"}: ${attachmentLabel ?: "Attached"}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
              )
            }

            IconButton(
              onClick = onClearAttachment,
              modifier = Modifier.size(22.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove attachment",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(14.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Bottom Actions: Photo, Video, Help, and Share/Post button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Actions Group: Photo, Video, Help
        Row(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Photo action
          ActionChip(
            icon = Icons.Default.PhotoCamera,
            label = "Photo",
            testTag = "composer_action_photo",
            tint = CatchyIndigoLight,
            onClick = onPhotoClick
          )

          // Video action
          ActionChip(
            icon = Icons.Default.Videocam,
            label = "Video",
            testTag = "composer_action_video",
            tint = CatchyCyan,
            onClick = onVideoClick
          )

          // Help action (connects to Catchy Help feature)
          ActionChip(
            icon = Icons.Default.HelpOutline,
            label = "Help",
            testTag = "composer_action_help",
            tint = Color(0xFFF59E0B),
            onClick = onHelpClick
          )
        }

        val isPostEnabled = inputText.isNotBlank() || attachmentType != null

        // Post / Share Button
        Button(
          onClick = onPublish,
          enabled = isPostEnabled,
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = CatchyIndigo,
            contentColor = Color.White,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
          ),
          elevation = if (isPostEnabled) {
            ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 4.dp)
          } else {
            ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
          },
          border = if (isPostEnabled) {
            BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.5f))
          } else {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          },
          modifier = Modifier.testTag("composer_share_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = null,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Post",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
      }
    }
  }
}

@Composable
private fun ActionChip(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  tint: Color,
  testTag: String,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = tint.copy(alpha = 0.1f),
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .clickable { onClick() }
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = tint,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

/**
 * Community Member Avatar Bubble
 */
@Composable
private fun CommunityMemberBubble(
  user: UserAccount,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
    border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.25f)),
    modifier = Modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable { onClick() }
      .testTag("member_bubble_${user.userId}")
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
      Box(
        modifier = Modifier
          .size(22.dp)
          .clip(CircleShape)
          .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = user.fullName.take(2).uppercase(),
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 9.sp
          )
        )
      }
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = user.fullName.split(" ").firstOrNull() ?: user.fullName,
        style = MaterialTheme.typography.labelSmall.copy(
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.sp
        ),
        color = MaterialTheme.colorScheme.onBackground
      )
    }
  }
}

/**
 * Post Card with support for attachments (photo / video), likes, and comments
 */
@Composable
private fun FeedPostCard(
  post: CatchyPost,
  isLiked: Boolean,
  isOwner: Boolean,
  onAuthorClick: () -> Unit,
  onLikeClick: () -> Unit,
  onCommentClick: () -> Unit,
  onShareClick: () -> Unit,
  onEditClick: () -> Unit,
  onDeleteClick: () -> Unit,
  onHashtagClick: (String) -> Unit
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("feed_post_${post.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Author header + Owner actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          modifier = Modifier
            .weight(1f)
            .clickable { onAuthorClick() },
          verticalAlignment = Alignment.CenterVertically
        ) {
          val avatarBg = when (post.authorAvatar) {
            "avatar_1" -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
            "avatar_2" -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
            "avatar_3" -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
            else -> listOf(Color(0xFF10B981), Color(0xFF059669))
          }

          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(avatarBg)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = post.authorName.take(2).uppercase(),
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = post.authorName,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = "Verified",
                tint = CatchyCyan,
                modifier = Modifier.size(14.dp)
              )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "@${post.authorUserId}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = CatchyCyan
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "•",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.width(6.dp))
              val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(post.timestamp))
              Text(
                text = dateStr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Owner controls (Edit / Delete)
        if (isOwner) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onEditClick,
              modifier = Modifier
                .size(32.dp)
                .testTag("edit_post_button_${post.id}")
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit Post",
                tint = CatchyCyan,
                modifier = Modifier.size(16.dp)
              )
            }
            IconButton(
              onClick = onDeleteClick,
              modifier = Modifier
                .size(32.dp)
                .testTag("delete_post_button_${post.id}")
            ) {
              Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete Post",
                tint = Color(0xFFEF4444).copy(alpha = 0.85f),
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }

      // Location tag if available
      if (!post.location.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = post.location,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            color = CatchyCyan
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Content text
      Text(
        text = post.content,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface
      )

      // Hashtag chips
      if (!post.hashtags.isNullOrBlank()) {
        val tags = post.hashtags.split(" ").filter { it.startsWith("#") }
        if (tags.isNotEmpty()) {
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            tags.forEach { tag ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = CatchyCyan.copy(alpha = 0.12f),
                border = BorderStroke(0.5.dp, CatchyCyan.copy(alpha = 0.3f)),
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .clickable { onHashtagClick(tag) }
              ) {
                Text(
                  text = tag,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  ),
                  color = CatchyCyan,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      }

      // Attached Media View
      if (!post.attachmentType.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        PostAttachmentCard(
          type = post.attachmentType,
          label = post.attachmentLabel ?: "Catchy Media"
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Action row: Like, Comment, Share
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Like Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onLikeClick() }
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .testTag("post_like_${post.id}")
        ) {
          Icon(
            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Like",
            tint = if (isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = post.likesCount.toString(),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = if (isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Comment Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onCommentClick() }
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .testTag("post_comment_${post.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ModeComment,
            contentDescription = "Comment",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(17.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = post.commentsCount.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Share Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onShareClick() }
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .testTag("post_share_${post.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(17.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Share",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

/**
 * Visual presentation for photo or video attachments in posts
 */
@Composable
private fun PostAttachmentCard(
  type: String,
  label: String
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(160.dp)
        .background(
          brush = Brush.verticalGradient(
            if (type == "photo") listOf(CatchyIndigoDark.copy(alpha = 0.8f), CatchyDarkSurface)
            else listOf(Color(0xFF1E1B4B), CatchyDarkSurface)
          )
        ),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(if (type == "photo") CatchyCyan.copy(alpha = 0.2f) else CatchyIndigo.copy(alpha = 0.3f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (type == "photo") Icons.Default.PhotoCamera else Icons.Default.PlayArrow,
            contentDescription = null,
            tint = if (type == "photo") CatchyCyan else Color.White,
            modifier = Modifier.size(28.dp)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = label,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          color = Color.White
        )
        Text(
          text = if (type == "photo") "Catchy Photo Asset" else "Catchy Reel Clip",
          style = MaterialTheme.typography.labelSmall,
          color = CatchyCyan
        )
      }
    }
  }
}

/**
 * User card in search results
 */
@Composable
private fun SearchUserCard(
  user: UserAccount,
  onProfileClick: () -> Unit,
  onMessageClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("search_user_result_${user.userId}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .weight(1f)
          .clickable { onProfileClick() }
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = user.fullName.take(2).uppercase(),
            style = MaterialTheme.typography.bodyLarge.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = user.fullName,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
          Text(
            text = "@${user.userId}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
            color = CatchyCyan
          )
          if (user.bio.isNotBlank()) {
            Text(
              text = user.bio,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
          onClick = onProfileClick,
          shape = RoundedCornerShape(8.dp),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Text("Profile", style = MaterialTheme.typography.labelSmall)
        }

        Button(
          onClick = onMessageClick,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Text("Chat", style = MaterialTheme.typography.labelSmall)
        }
      }
    }
  }
}

/**
 * Catchy Help Center Dialog / Modal
 * Connected via the "Help" action in the post composer and header menu.
 * Strictly without adding any extra bottom navigation tab!
 */
@Composable
private fun CatchyHelpDialog(onDismiss: () -> Unit) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.4f)),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("catchy_help_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(22.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFFF59E0B).copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.HelpOutline,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Catchy Help Center",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
              Text(
                text = "Guides, safety & support",
                style = MaterialTheme.typography.labelSmall,
                color = CatchyCyan
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close Help",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        Spacer(modifier = Modifier.height(14.dp))

        // Help Topics
        HelpTopicRow(
          title = "Unique User IDs (@CTY-XXXXXX)",
          description = "Each Catchy account has an immutable unique User ID. Use this ID to find friends, search profiles, and initiate direct chats."
        )

        Spacer(modifier = Modifier.height(12.dp))

        HelpTopicRow(
          title = "Creating Posts & Media",
          description = "Share authentic updates using the Post Composer. Attach photos or short videos and share directly with your Catchy network."
        )

        Spacer(modifier = Modifier.height(12.dp))

        HelpTopicRow(
          title = "Authentic & Safe Community",
          description = "Catchy is a respectful, authentic platform. Harassment, impersonation, or deceptive behavior are strictly prohibited."
        )

        Spacer(modifier = Modifier.height(12.dp))

        HelpTopicRow(
          title = "Need Direct Support?",
          description = "Reach out to the Catchy team anytime at catchyappbd@gmail.com for account or safety inquiries."
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Got It")
        }
      }
    }
  }
}

@Composable
private fun HelpTopicRow(
  title: String,
  description: String
) {
  Column {
    Text(
      text = title,
      style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onBackground
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = description,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

/**
 * Catchy Notifications Dialog / Modal
 * Opened by tapping the notification bell icon (🔔) in the Home header.
 */
@Composable
private fun CatchyNotificationsDialog(
  notifications: List<CatchyNotificationItem>,
  onDismiss: () -> Unit,
  onMarkAllRead: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("catchy_notifications_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Notifications",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${notifications.size} updates",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          TextButton(onClick = onMarkAllRead) {
            Text(
              text = "Mark all read",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan
            )
          }
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(280.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(notifications, key = { it.id }) { notif ->
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (notif.isRead) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
              } else {
                CatchyCyan.copy(alpha = 0.12f)
              },
              border = BorderStroke(
                1.dp,
                if (notif.isRead) MaterialTheme.colorScheme.outline.copy(alpha = 0.2f) else CatchyCyan.copy(alpha = 0.3f)
              ),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.Top
              ) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (notif.isRead) Color.Transparent else CatchyCyan)
                    .padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = notif.title,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = notif.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Close")
        }
      }
    }
  }
}

/**
 * Catchy Menu Dialog / Sheet
 * Opened by tapping the menu icon (☰) in the Home header.
 */
@Composable
private fun CatchyMenuSheet(
  currentUser: UserAccount?,
  onDismiss: () -> Unit,
  onSelectTab: (CatchyNavTab) -> Unit,
  onFriendsClick: () -> Unit,
  onCommunityClick: () -> Unit,
  onJobsClick: () -> Unit,
  onInvestmentClick: () -> Unit,
  onBusinessClick: () -> Unit,
  onAdsClick: () -> Unit,
  onReachClick: () -> Unit,
  onMonetizationClick: () -> Unit,
  onNotificationsClick: () -> Unit,
  onHelpClick: () -> Unit,
  onLogout: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("catchy_menu_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Catchy Menu",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close Menu",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Current User Profile Banner in Menu
        if (currentUser != null) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = currentUser.fullName.take(2).uppercase(),
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
              }

              Spacer(modifier = Modifier.width(10.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = currentUser.fullName,
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                  text = "@${currentUser.userId}",
                  style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                  color = CatchyCyan
                )
              }

              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(8.dp))

        // Navigation Menu Items
        CatchyMenuItem(
          icon = Icons.Default.Person,
          label = "My Profile",
          onClick = { onSelectTab(CatchyNavTab.PROFILE) }
        )

        CatchyMenuItem(
          icon = Icons.Default.People,
          label = "Friends & Following",
          onClick = onFriendsClick
        )

        CatchyMenuItem(
          icon = Icons.Default.ChatBubble,
          label = "Direct Messages",
          onClick = { onSelectTab(CatchyNavTab.CHAT) }
        )

        CatchyMenuItem(
          icon = Icons.Default.PlayArrow,
          label = "Reels & Videos",
          onClick = { onSelectTab(CatchyNavTab.REELS) }
        )

        CatchyMenuItem(
          icon = Icons.Default.Groups,
          label = "Community",
          onClick = onCommunityClick
        )

        CatchyMenuItem(
          icon = Icons.Default.Work,
          label = "Jobs",
          onClick = onJobsClick
        )

        CatchyMenuItem(
          icon = Icons.Default.TrendingUp,
          label = "Investment Network",
          onClick = onInvestmentClick
        )

        CatchyMenuItem(
          icon = Icons.Default.Business,
          label = "Business / Business Page",
          onClick = onBusinessClick
        )

        CatchyMenuItem(
          icon = Icons.Default.Campaign,
          label = "Ads / Advertising",
          onClick = onAdsClick
        )

        CatchyMenuItem(
          icon = Icons.Default.RocketLaunch,
          label = "Catchy Reach",
          onClick = onReachClick
        )

        CatchyMenuItem(
          icon = Icons.Default.MonetizationOn,
          label = "Monetization",
          onClick = onMonetizationClick
        )

        CatchyMenuItem(
          icon = Icons.Default.Notifications,
          label = "Notifications",
          onClick = onNotificationsClick
        )

        CatchyMenuItem(
          icon = Icons.Default.HelpOutline,
          label = "Catchy Help & Support",
          onClick = onHelpClick
        )

        CatchyMenuItem(
          icon = Icons.Default.Info,
          label = "About Catchy (concern of kichaan)",
          onClick = onHelpClick
        )

        Spacer(modifier = Modifier.height(10.dp))
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(8.dp))

        // Logout action
        CatchyMenuItem(
          icon = Icons.AutoMirrored.Filled.Logout,
          label = "Sign Out",
          textColor = MaterialTheme.colorScheme.error,
          onClick = onLogout
        )
      }
    }
  }
}

@Composable
private fun CatchyMenuItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  textColor: Color = MaterialTheme.colorScheme.onBackground,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .clickable { onClick() }
      .padding(horizontal = 12.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = textColor,
      modifier = Modifier.size(20.dp)
    )
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
      color = textColor
    )
  }
}

/**
 * Photo Attachment Dialog
 */
@Composable
private fun PhotoAttachmentDialog(
  onDismiss: () -> Unit,
  onPhotoSelected: (String) -> Unit
) {
  var customTitle by remember { mutableStateOf("") }
  val options = listOf(
    "Catchy Moments Snapshot",
    "Creative Design Visual",
    "Modern Workspace Setup",
    "City & Nature View"
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.PhotoCamera,
          contentDescription = null,
          tint = CatchyIndigoLight
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text("Attach Photo")
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Select a photo preset or type a custom photo label:",
          style = MaterialTheme.typography.bodyMedium
        )
        OutlinedTextField(
          value = customTitle,
          onValueChange = { customTitle = it },
          placeholder = { Text("Custom photo description...") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
        if (customTitle.isNotBlank()) {
          Button(
            onClick = { onPhotoSelected(customTitle.trim()) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
          ) {
            Text("Use Custom Label", color = Color.White)
          }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Or choose a preset:",
          style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        options.forEach { option ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onPhotoSelected(option) }
              .padding(vertical = 2.dp)
          ) {
            Text(
              text = option,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

/**
 * Video Attachment Dialog
 */
@Composable
private fun VideoAttachmentDialog(
  onDismiss: () -> Unit,
  onVideoSelected: (String) -> Unit
) {
  var customTitle by remember { mutableStateOf("") }
  val options = listOf(
    "Catchy Short Clip",
    "Tech & Design Reel",
    "Quick Story Video",
    "Community Feature Showcase"
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Videocam,
          contentDescription = null,
          tint = CatchyCyan
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text("Attach Video")
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Select a video preset or type a custom video label:",
          style = MaterialTheme.typography.bodyMedium
        )
        OutlinedTextField(
          value = customTitle,
          onValueChange = { customTitle = it },
          placeholder = { Text("Custom video description...") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
        if (customTitle.isNotBlank()) {
          Button(
            onClick = { onVideoSelected(customTitle.trim()) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
          ) {
            Text("Use Custom Label", color = Color.White)
          }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Or choose a preset:",
          style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        options.forEach { option ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onVideoSelected(option) }
              .padding(vertical = 2.dp)
          ) {
            Text(
              text = option,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
