package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.outlined.WorkOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyEmployerProfile
import com.example.data.model.CatchyJobApplication
import com.example.data.model.CatchyJobPosting
import com.example.data.model.CatchyJobSeekerProfile
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyCyanGlow
import com.example.ui.theme.CatchyDarkBg
import com.example.ui.theme.CatchyDarkBorder
import com.example.ui.theme.CatchyDarkSurface
import com.example.ui.theme.CatchyDarkSurfaceVariant
import com.example.ui.theme.CatchyError
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchySuccess
import com.example.ui.theme.CatchyTextMutedDark
import com.example.ui.theme.CatchyTextPrimaryDark
import com.example.ui.theme.CatchyTextSecondaryDark
import com.example.ui.theme.CatchyViolet
import com.example.ui.theme.CatchyWarning
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyJobsTab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Catchy Jobs & Career Portal Dialog.
 * Full featured jobs marketplace connecting job seekers and employers with real Room persistence.
 */
@Composable
fun CatchyJobsDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentTab by viewModel.jobsTab.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val filteredJobs by viewModel.filteredJobs.collectAsState()
  val myJobPostings by viewModel.myJobPostings.collectAsState()
  val myApplications by viewModel.myApplications.collectAsState()
  val seekerProfile by viewModel.jobSeekerProfile.collectAsState()
  val employerProfile by viewModel.employerProfile.collectAsState()

  val selectedJob by viewModel.selectedJob.collectAsState()
  val applyingToJob by viewModel.applyingToJob.collectAsState()
  val managingJob by viewModel.managingJob.collectAsState()
  val isJobPostDialogVisible by viewModel.isJobPostDialogVisible.collectAsState()
  val feedbackMessage by viewModel.applicationFeedbackMessage.collectAsState()

  val context = LocalContext.current

  LaunchedEffect(feedbackMessage) {
    feedbackMessage?.let {
      Toast.makeText(context, it, Toast.LENGTH_LONG).show()
      viewModel.clearApplicationFeedback()
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("catchy_jobs_screen"),
      color = CatchyDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // 1. Top Header Bar
        JobsTopBar(
          onDismiss = onDismiss,
          onPostJobClick = { viewModel.openCreateJobDialog() }
        )

        // 2. Navigation Tabs
        JobsNavigationTabs(
          currentTab = currentTab,
          activeJobsCount = filteredJobs.size,
          applicationsCount = myApplications.size,
          postingsCount = myJobPostings.size,
          onSelectTab = { viewModel.setJobsTab(it) }
        )

        // 3. Tab Content
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          when (currentTab) {
            CatchyJobsTab.EXPLORE -> {
              ExploreJobsView(
                viewModel = viewModel,
                jobs = filteredJobs,
                currentUserId = currentUser?.userId,
                onJobClick = { viewModel.selectJob(it) },
                onApplyClick = { viewModel.openApplyDialog(it) },
                onManageClick = { viewModel.openManageApplicants(it) },
                onEditClick = { viewModel.openEditJobDialog(it) },
                onPostJobClick = { viewModel.openCreateJobDialog() }
              )
            }
            CatchyJobsTab.APPLICATIONS -> {
              MyApplicationsView(
                applications = myApplications,
                onMessageEmployer = { employerId, companyName ->
                  viewModel.messageJobContact(
                    targetUserId = employerId,
                    targetUserName = companyName,
                    initialContextMessage = "Hello! I am following up on my job application with $companyName on Catchy Career."
                  )
                },
                onExploreClick = { viewModel.setJobsTab(CatchyJobsTab.EXPLORE) }
              )
            }
            CatchyJobsTab.MY_POSTINGS -> {
              MyJobPostingsView(
                postings = myJobPostings,
                onManageApplicants = { viewModel.openManageApplicants(it) },
                onEditJob = { viewModel.openEditJobDialog(it) },
                onCloseJob = { viewModel.closeJobPosting(it.jobId) },
                onDeleteJob = { viewModel.deleteJobPosting(it.jobId) },
                onPostJobClick = { viewModel.openCreateJobDialog() }
              )
            }
            CatchyJobsTab.PROFILES -> {
              CareerProfilesView(
                seekerProfile = seekerProfile,
                employerProfile = employerProfile,
                currentUser = currentUser,
                onSaveSeeker = { headline, goal, skills, expYears, expSummary, edu, loc, cv, preferredTypes, available ->
                  viewModel.saveJobSeekerProfile(headline, goal, skills, expYears, expSummary, edu, loc, cv, preferredTypes, available)
                  Toast.makeText(context, "Seeker Profile Saved Successfully!", Toast.LENGTH_SHORT).show()
                },
                onSaveEmployer = { compName, ind, web, loc, size, bio, verified ->
                  viewModel.saveEmployerProfile(compName, ind, web, loc, size, bio, verified)
                  Toast.makeText(context, "Employer Profile Saved Successfully!", Toast.LENGTH_SHORT).show()
                }
              )
            }
          }
        }
      }
    }
  }

  // --- Sub-Modals ---

  // 1. Job Details Modal
  if (selectedJob != null) {
    JobDetailsDialog(
      job = selectedJob!!,
      currentUserId = currentUser?.userId,
      myApplications = myApplications,
      onDismiss = { viewModel.selectJob(null) },
      onApply = {
        val target = selectedJob!!
        viewModel.selectJob(null)
        viewModel.openApplyDialog(target)
      },
      onManageApplicants = {
        val target = selectedJob!!
        viewModel.selectJob(null)
        viewModel.openManageApplicants(target)
      },
      onEdit = {
        val target = selectedJob!!
        viewModel.selectJob(null)
        viewModel.openEditJobDialog(target)
      },
      onMessageEmployer = {
        val job = selectedJob!!
        viewModel.selectJob(null)
        viewModel.messageJobContact(
          targetUserId = job.employerId,
          targetUserName = job.companyName,
          initialContextMessage = "Hi! I saw your '${job.title}' opening on Catchy Career and would love to learn more."
        )
      }
    )
  }

  // 2. Apply Flow Modal
  if (applyingToJob != null) {
    JobApplicationDialog(
      job = applyingToJob!!,
      currentUser = currentUser,
      seekerProfile = seekerProfile,
      isSubmitting = viewModel.isSubmittingApplication.collectAsState().value,
      onDismiss = { viewModel.closeApplyDialog() },
      onSubmit = { cover, resume, skills, exp, loc ->
        viewModel.submitJobApplication(cover, resume, skills, exp, loc)
      }
    )
  }

  // 3. Post / Edit Job Modal
  if (isJobPostDialogVisible) {
    JobPostEditorDialog(
      editingJob = viewModel.editingJobPosting.collectAsState().value,
      isSaving = viewModel.isSavingJobPosting.collectAsState().value,
      errorMessage = viewModel.jobPostingFormError.collectAsState().value,
      onDismiss = { viewModel.closeJobPostDialog() },
      onSave = { title, comp, desc, cat, skills, loc, remote, type, expLvl, salary, instructions, status ->
        viewModel.saveJobPosting(title, comp, desc, cat, skills, loc, remote, type, expLvl, salary, instructions, status)
      }
    )
  }

  // 4. Manage Applicants Modal
  if (managingJob != null) {
    val applicants by viewModel.managingJobApplicants.collectAsState()
    ManageApplicantsDialog(
      job = managingJob!!,
      applicants = applicants,
      onDismiss = { viewModel.closeManageApplicants() },
      onUpdateStatus = { appId, newStatus ->
        viewModel.updateApplicantStatus(appId, newStatus)
      },
      onMessageCandidate = { applicantId, applicantName ->
        viewModel.messageJobContact(
          targetUserId = applicantId,
          targetUserName = applicantName,
          initialContextMessage = "Hello $applicantName, regarding your application for '${managingJob?.title}' at ${managingJob?.companyName} on Catchy Career:"
        )
      }
    )
  }
}

// ==========================================
// TOP BAR & NAVIGATION
// ==========================================

@Composable
private fun JobsTopBar(
  onDismiss: () -> Unit,
  onPostJobClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(CatchyDarkSurface)
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    IconButton(
      onClick = onDismiss,
      modifier = Modifier.testTag("jobs_back_button")
    ) {
      Icon(
        imageVector = Icons.Default.ArrowBack,
        contentDescription = "Back",
        tint = CatchyTextPrimaryDark
      )
    }

    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Work,
          contentDescription = null,
          tint = CatchyCyan,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Catchy Career",
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp,
          color = CatchyTextPrimaryDark
        )
      }
      Text(
        text = "Opportunities • Network • Hire Talent",
        fontSize = 12.sp,
        color = CatchyTextSecondaryDark
      )
    }

    Button(
      onClick = onPostJobClick,
      shape = RoundedCornerShape(20.dp),
      colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
      modifier = Modifier.testTag("post_job_top_button")
    ) {
      Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(4.dp))
      Text("Post Job", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
private fun JobsNavigationTabs(
  currentTab: CatchyJobsTab,
  activeJobsCount: Int,
  applicationsCount: Int,
  postingsCount: Int,
  onSelectTab: (CatchyJobsTab) -> Unit
) {
  val tabs = listOf(
    CatchyJobsTab.EXPLORE to "Explore ($activeJobsCount)",
    CatchyJobsTab.APPLICATIONS to "Applied ($applicationsCount)",
    CatchyJobsTab.MY_POSTINGS to "My Postings ($postingsCount)",
    CatchyJobsTab.PROFILES to "Profiles"
  )

  TabRow(
    selectedTabIndex = currentTab.ordinal,
    containerColor = CatchyDarkSurfaceVariant,
    contentColor = CatchyTextPrimaryDark,
    indicator = { tabPositions ->
      TabRowDefaults.SecondaryIndicator(
        modifier = Modifier.tabIndicatorOffset(tabPositions[currentTab.ordinal]),
        color = CatchyCyan,
        height = 3.dp
      )
    }
  ) {
    tabs.forEach { (tab, label) ->
      Tab(
        selected = currentTab == tab,
        onClick = { onSelectTab(tab) },
        text = {
          Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (currentTab == tab) FontWeight.Bold else FontWeight.Medium,
            color = if (currentTab == tab) CatchyCyan else CatchyTextSecondaryDark,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        },
        modifier = Modifier.testTag("jobs_tab_${tab.name.lowercase()}")
      )
    }
  }
}

// ==========================================
// TAB 1: EXPLORE JOBS (SEARCH & FILTERS)
// ==========================================

@Composable
private fun ExploreJobsView(
  viewModel: AccountViewModel,
  jobs: List<CatchyJobPosting>,
  currentUserId: String?,
  onJobClick: (CatchyJobPosting) -> Unit,
  onApplyClick: (CatchyJobPosting) -> Unit,
  onManageClick: (CatchyJobPosting) -> Unit,
  onEditClick: (CatchyJobPosting) -> Unit,
  onPostJobClick: () -> Unit
) {
  val query by viewModel.jobsSearchQuery.collectAsState()
  val selectedCategory by viewModel.selectedJobCategory.collectAsState()
  val selectedEmploymentType by viewModel.selectedEmploymentType.collectAsState()
  val onlyRemote by viewModel.onlyRemote.collectAsState()

  val categories = listOf(
    "All",
    "Engineering & Tech",
    "Design & Creative",
    "Marketing & Growth",
    "Sales & Ops",
    "Content & Media",
    "Other"
  )

  val employmentTypes = listOf(
    "All",
    "Full-time",
    "Part-time",
    "Internship",
    "Apprenticeship",
    "Freelance",
    "Remote"
  )

  Column(modifier = Modifier.fillMaxSize()) {
    // Search Bar
    OutlinedTextField(
      value = query,
      onValueChange = { viewModel.setJobsSearchQuery(it) },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .testTag("jobs_search_input"),
      placeholder = { Text("Search by title, skills, company, location...", color = CatchyTextMutedDark, fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CatchyCyan) },
      trailingIcon = {
        if (query.isNotEmpty()) {
          IconButton(onClick = { viewModel.setJobsSearchQuery("") }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", tint = CatchyTextSecondaryDark)
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CatchyCyan,
        unfocusedBorderColor = CatchyDarkBorder,
        focusedContainerColor = CatchyDarkSurface,
        unfocusedContainerColor = CatchyDarkSurface,
        focusedTextColor = CatchyTextPrimaryDark,
        unfocusedTextColor = CatchyTextPrimaryDark
      )
    )

    // Filter Chips: Categories
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      categories.forEach { cat ->
        FilterChip(
          selected = selectedCategory == cat,
          onClick = { viewModel.setSelectedJobCategory(cat) },
          label = { Text(cat, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CatchyIndigo,
            selectedLabelColor = Color.White,
            containerColor = CatchyDarkSurface,
            labelColor = CatchyTextSecondaryDark
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selectedCategory == cat,
            borderColor = if (selectedCategory == cat) CatchyIndigoLight else CatchyDarkBorder
          )
        )
      }
    }

    // Filter Chips: Employment Types + Remote Toggle
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Remote Only quick switch
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (onlyRemote) CatchyCyan.copy(alpha = 0.2f) else CatchyDarkSurface,
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (onlyRemote) CatchyCyan else CatchyDarkBorder
        ),
        modifier = Modifier.clickable { viewModel.setOnlyRemote(!onlyRemote) }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "🌍 Remote Only",
            fontSize = 12.sp,
            fontWeight = if (onlyRemote) FontWeight.Bold else FontWeight.Normal,
            color = if (onlyRemote) CatchyCyan else CatchyTextSecondaryDark
          )
        }
      }

      employmentTypes.forEach { type ->
        FilterChip(
          selected = selectedEmploymentType == type,
          onClick = { viewModel.setSelectedEmploymentType(type) },
          label = { Text(type, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CatchyViolet,
            selectedLabelColor = Color.White,
            containerColor = CatchyDarkSurface,
            labelColor = CatchyTextSecondaryDark
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selectedEmploymentType == type,
            borderColor = if (selectedEmploymentType == type) CatchyViolet else CatchyDarkBorder
          )
        )
      }
    }

    HorizontalDivider(
      color = CatchyDarkBorder,
      thickness = 1.dp,
      modifier = Modifier.padding(vertical = 4.dp)
    )

    // Job List
    if (jobs.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Outlined.WorkOutline,
            contentDescription = null,
            tint = CatchyTextMutedDark,
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "No job postings found",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = CatchyTextPrimaryDark
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = if (query.isNotBlank() || selectedCategory != "All" || selectedEmploymentType != "All") {
              "No active postings match your selected filters. Try broadening your criteria."
            } else {
              "Be the first to create an opportunity! Post real job vacancies, internships, or freelance gigs."
            },
            fontSize = 13.sp,
            color = CatchyTextSecondaryDark,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(20.dp))
          Button(
            onClick = onPostJobClick,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Create First Job Post")
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }
        items(jobs, key = { it.jobId }) { job ->
          val isOwner = currentUserId != null && currentUserId == job.employerId
          JobCardItem(
            job = job,
            isOwner = isOwner,
            onCardClick = { onJobClick(job) },
            onApplyClick = { onApplyClick(job) },
            onManageClick = { onManageClick(job) },
            onEditClick = { onEditClick(job) }
          )
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun JobCardItem(
  job: CatchyJobPosting,
  isOwner: Boolean,
  onCardClick: () -> Unit,
  onApplyClick: () -> Unit,
  onManageClick: () -> Unit,
  onEditClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onCardClick)
      .testTag("job_card_${job.jobId}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Top row: Company name, Verified badge, Date
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Icon(
            imageVector = Icons.Default.Business,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = job.companyName,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = CatchyCyan,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Text(
          text = formatRelativeTime(job.createdAt),
          fontSize = 11.sp,
          color = CatchyTextMutedDark
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Job Title
      Text(
        text = job.title,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = CatchyTextPrimaryDark
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Tag chips: Employment Type, Remote, Category, Experience
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        JobBadge(text = job.employmentType, backgroundColor = CatchyIndigo.copy(alpha = 0.25f), textColor = CatchyIndigoLight)
        if (job.isRemote) {
          JobBadge(text = "🌍 Remote", backgroundColor = CatchySuccess.copy(alpha = 0.2f), textColor = CatchySuccess)
        }
        JobBadge(text = job.category, backgroundColor = CatchyViolet.copy(alpha = 0.2f), textColor = CatchyViolet)
        if (job.experienceLevel.isNotBlank()) {
          JobBadge(text = job.experienceLevel, backgroundColor = CatchyDarkSurfaceVariant, textColor = CatchyTextSecondaryDark)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Location & Salary
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LocationOn, contentDescription = null, tint = CatchyTextMutedDark, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = job.location.ifBlank { if (job.isRemote) "Remote" else "Not specified" },
            fontSize = 12.sp,
            color = CatchyTextSecondaryDark,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.AttachMoney, contentDescription = null, tint = CatchySuccess, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(2.dp))
          Text(
            text = job.salaryRange,
            fontSize = 12.sp,
            color = CatchySuccess,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Skills Required Snippet
      if (job.skillsRequired.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Skills: ${job.skillsRequired}",
          fontSize = 12.sp,
          color = CatchyTextMutedDark,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(12.dp))
      HorizontalDivider(color = CatchyDarkBorder, thickness = 0.5.dp)
      Spacer(modifier = Modifier.height(10.dp))

      // Actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (isOwner) {
          OutlinedButton(
            onClick = onEditClick,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.padding(end = 8.dp)
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Edit", fontSize = 12.sp)
          }

          Button(
            onClick = onManageClick,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
          ) {
            Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Applicants", fontSize = 12.sp)
          }
        } else {
          OutlinedButton(
            onClick = onCardClick,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.padding(end = 8.dp)
          ) {
            Text("Details", fontSize = 12.sp)
          }

          Button(
            onClick = onApplyClick,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
          ) {
            Text("Apply Now", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
          }
        }
      }
    }
  }
}

@Composable
private fun JobBadge(text: String, backgroundColor: Color, textColor: Color) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(backgroundColor)
      .padding(horizontal = 8.dp, vertical = 4.dp)
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium
    )
  }
}

// ==========================================
// TAB 2: MY APPLICATIONS VIEW
// ==========================================

@Composable
private fun MyApplicationsView(
  applications: List<CatchyJobApplication>,
  onMessageEmployer: (employerId: String, companyName: String) -> Unit,
  onExploreClick: () -> Unit
) {
  if (applications.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Icon(
          imageVector = Icons.Default.Description,
          contentDescription = null,
          tint = CatchyTextMutedDark,
          modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = "No Applications Submitted Yet",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = CatchyTextPrimaryDark
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Explore active openings, internships, and freelance projects to apply and build your career on Catchy.",
          fontSize = 13.sp,
          color = CatchyTextSecondaryDark,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onExploreClick,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
        ) {
          Text("Explore Jobs", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(applications, key = { it.applicationId }) { app ->
        ApplicationCardItem(
          application = app,
          onMessageEmployer = { onMessageEmployer(app.employerId, app.companyName) }
        )
      }
    }
  }
}

@Composable
private fun ApplicationCardItem(
  application: CatchyJobApplication,
  onMessageEmployer: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = application.jobTitle,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = CatchyTextPrimaryDark
          )
          Text(
            text = application.companyName,
            fontSize = 13.sp,
            color = CatchyCyan
          )
        }

        // Status Badge
        val (badgeBg, badgeColor) = when (application.status) {
          "SHORTLISTED" -> CatchySuccess.copy(alpha = 0.2f) to CatchySuccess
          "ACCEPTED" -> CatchyCyan.copy(alpha = 0.2f) to CatchyCyan
          "REJECTED" -> CatchyError.copy(alpha = 0.2f) to CatchyError
          "REVIEWED" -> CatchyViolet.copy(alpha = 0.2f) to CatchyViolet
          else -> CatchyWarning.copy(alpha = 0.2f) to CatchyWarning
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(badgeBg)
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = application.status,
            color = badgeColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "Applied on ${SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(application.appliedAt))}",
        fontSize = 12.sp,
        color = CatchyTextMutedDark
      )

      if (application.coverNote.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Cover Note: \"${application.coverNote}\"",
          fontSize = 12.sp,
          color = CatchyTextSecondaryDark,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      if (application.resumeOrPortfolioLink.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Resume: ${application.resumeOrPortfolioLink}",
          fontSize = 12.sp,
          color = CatchyCyanGlow,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(12.dp))
      HorizontalDivider(color = CatchyDarkBorder, thickness = 0.5.dp)
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        Button(
          onClick = onMessageEmployer,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
        ) {
          Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Message Employer", fontSize = 12.sp)
        }
      }
    }
  }
}

// ==========================================
// TAB 3: MY JOB POSTINGS (EMPLOYER DASHBOARD)
// ==========================================

@Composable
private fun MyJobPostingsView(
  postings: List<CatchyJobPosting>,
  onManageApplicants: (CatchyJobPosting) -> Unit,
  onEditJob: (CatchyJobPosting) -> Unit,
  onCloseJob: (CatchyJobPosting) -> Unit,
  onDeleteJob: (CatchyJobPosting) -> Unit,
  onPostJobClick: () -> Unit
) {
  if (postings.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Icon(
          imageVector = Icons.Default.Business,
          contentDescription = null,
          tint = CatchyTextMutedDark,
          modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = "No Job Postings Yet",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = CatchyTextPrimaryDark
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Hire talented developers, creators, apprentices, and professionals across Bangladesh and globally.",
          fontSize = 13.sp,
          color = CatchyTextSecondaryDark,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onPostJobClick,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Post Your First Job")
        }
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(postings, key = { it.jobId }) { job ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = job.title,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = CatchyTextPrimaryDark
                )
                Text(
                  text = "${job.companyName} • ${job.employmentType}",
                  fontSize = 13.sp,
                  color = CatchyTextSecondaryDark
                )
              }

              val (statusBg, statusColor) = if (job.status == "ACTIVE") {
                CatchySuccess.copy(alpha = 0.2f) to CatchySuccess
              } else {
                CatchyDarkSurfaceVariant to CatchyTextMutedDark
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(statusBg)
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(job.status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Posted on ${SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(job.createdAt))}",
              fontSize = 12.sp,
              color = CatchyTextMutedDark
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = CatchyDarkBorder, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row {
                IconButton(onClick = { onDeleteJob(job) }) {
                  Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CatchyError)
                }
                if (job.status == "ACTIVE") {
                  OutlinedButton(
                    onClick = { onCloseJob(job) },
                    shape = RoundedCornerShape(8.dp)
                  ) {
                    Text("Close Job", fontSize = 12.sp)
                  }
                }
              }

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = { onEditJob(job) },
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Edit", fontSize = 12.sp)
                }

                Button(
                  onClick = { onManageApplicants(job) },
                  shape = RoundedCornerShape(8.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
                ) {
                  Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Applicants", fontSize = 12.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// TAB 4: CAREER & EMPLOYER PROFILES
// ==========================================

@Composable
private fun CareerProfilesView(
  seekerProfile: CatchyJobSeekerProfile?,
  employerProfile: CatchyEmployerProfile?,
  currentUser: com.example.data.model.UserAccount?,
  onSaveSeeker: (
    headline: String,
    goal: String,
    skills: String,
    expYears: String,
    expSummary: String,
    edu: String,
    loc: String,
    cv: String,
    preferredTypes: String,
    available: Boolean
  ) -> Unit,
  onSaveEmployer: (
    compName: String,
    ind: String,
    web: String,
    loc: String,
    size: String,
    bio: String,
    verified: Boolean
  ) -> Unit
) {
  var activeProfileTab by remember { mutableStateOf(0) } // 0: Job Seeker, 1: Employer / Business

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
  ) {
    // Switcher Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(CatchyDarkSurface)
        .padding(4.dp)
    ) {
      Button(
        onClick = { activeProfileTab = 0 },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (activeProfileTab == 0) CatchyIndigo else Color.Transparent
        ),
        shape = RoundedCornerShape(8.dp)
      ) {
        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Job Seeker Profile", fontSize = 12.sp)
      }

      Button(
        onClick = { activeProfileTab = 1 },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (activeProfileTab == 1) CatchyCyan else Color.Transparent
        ),
        shape = RoundedCornerShape(8.dp)
      ) {
        Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (activeProfileTab == 1) Color.Black else Color.White)
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          "Employer Profile",
          fontSize = 12.sp,
          color = if (activeProfileTab == 1) Color.Black else Color.White
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (activeProfileTab == 0) {
      // Job Seeker Profile Form
      JobSeekerProfileForm(
        seekerProfile = seekerProfile,
        currentUser = currentUser,
        onSave = onSaveSeeker
      )
    } else {
      // Employer Profile Form
      EmployerProfileForm(
        employerProfile = employerProfile,
        currentUser = currentUser,
        onSave = onSaveEmployer
      )
    }
  }
}

@Composable
private fun JobSeekerProfileForm(
  seekerProfile: CatchyJobSeekerProfile?,
  currentUser: com.example.data.model.UserAccount?,
  onSave: (
    headline: String,
    goal: String,
    skills: String,
    expYears: String,
    expSummary: String,
    edu: String,
    loc: String,
    cv: String,
    preferredTypes: String,
    available: Boolean
  ) -> Unit
) {
  var headline by remember(seekerProfile) { mutableStateOf(seekerProfile?.headline ?: "") }
  var careerGoal by remember(seekerProfile) { mutableStateOf(seekerProfile?.careerGoal ?: "") }
  var skills by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.skills ?: currentUser?.skills ?: "")
  }
  var expYears by remember(seekerProfile) { mutableStateOf(seekerProfile?.experienceYears ?: "") }
  var expSummary by remember(seekerProfile) { mutableStateOf(seekerProfile?.experienceSummary ?: "") }
  var education by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.education ?: currentUser?.educationStatus ?: "")
  }
  var location by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.location ?: currentUser?.addressLocation ?: "")
  }
  var cvUrl by remember(seekerProfile) { mutableStateOf(seekerProfile?.cvSummaryOrUrl ?: "") }
  var preferredTypes by remember(seekerProfile) {
    mutableStateOf(seekerProfile?.preferredJobTypes ?: "Full-time, Remote, Freelance")
  }
  var isAvailable by remember(seekerProfile) {
    mutableStateOf(seekerProfile?.isAvailableForHire ?: true)
  }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "Professional Job Seeker Profile",
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        color = CatchyTextPrimaryDark
      )
      Text(
        text = "This information helps employers discover and shortlist you for exciting roles.",
        fontSize = 12.sp,
        color = CatchyTextSecondaryDark
      )

      Spacer(modifier = Modifier.height(16.dp))

      ProfileTextField(label = "Professional Headline", value = headline, onValueChange = { headline = it }, placeholder = "e.g. Senior Android Engineer / UI Designer")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Career Goal", value = careerGoal, onValueChange = { careerGoal = it }, placeholder = "e.g. Looking for high-impact Kotlin / Compose roles")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Primary Skills", value = skills, onValueChange = { skills = it }, placeholder = "Kotlin, Compose, Coroutines, Room, MVVM")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Years of Experience", value = expYears, onValueChange = { expYears = it }, placeholder = "e.g. 4 years, Fresh Graduate, Senior")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Experience Summary", value = expSummary, onValueChange = { expSummary = it }, placeholder = "Describe previous positions, impact, and projects...", maxLines = 3)
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Education", value = education, onValueChange = { education = it }, placeholder = "e.g. B.Sc. in Computer Science")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Location", value = location, onValueChange = { location = it }, placeholder = "e.g. Dhaka, Bangladesh (or Remote)")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "CV / Portfolio / LinkedIn Link", value = cvUrl, onValueChange = { cvUrl = it }, placeholder = "https://linkedin.com/in/... or Google Drive link")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Preferred Job Types", value = preferredTypes, onValueChange = { preferredTypes = it }, placeholder = "Full-time, Internship, Freelance, Remote")

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Open to Work / Available for Hire", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = CatchyTextPrimaryDark)
          Text("Signal employers that you are actively seeking opportunities", fontSize = 11.sp, color = CatchyTextMutedDark)
        }
        Switch(
          checked = isAvailable,
          onCheckedChange = { isAvailable = it },
          colors = SwitchDefaults.colors(checkedThumbColor = CatchyCyan, checkedTrackColor = CatchyCyan.copy(alpha = 0.5f))
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Button(
        onClick = {
          onSave(headline, careerGoal, skills, expYears, expSummary, education, location, cvUrl, preferredTypes, isAvailable)
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
      ) {
        Text("Save Seeker Profile", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }
    }
  }
}

@Composable
private fun EmployerProfileForm(
  employerProfile: CatchyEmployerProfile?,
  currentUser: com.example.data.model.UserAccount?,
  onSave: (
    compName: String,
    ind: String,
    web: String,
    loc: String,
    size: String,
    bio: String,
    verified: Boolean
  ) -> Unit
) {
  var compName by remember(employerProfile, currentUser) {
    mutableStateOf(employerProfile?.companyName ?: currentUser?.fullName ?: "")
  }
  var industry by remember(employerProfile) { mutableStateOf(employerProfile?.industry ?: "Technology & Software") }
  var website by remember(employerProfile) { mutableStateOf(employerProfile?.companyWebsite ?: "") }
  var location by remember(employerProfile, currentUser) {
    mutableStateOf(employerProfile?.companyLocation ?: currentUser?.addressLocation ?: "")
  }
  var size by remember(employerProfile) { mutableStateOf(employerProfile?.companySize ?: "1-10 employees") }
  var bio by remember(employerProfile) { mutableStateOf(employerProfile?.companyBio ?: "") }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "Employer & Business Profile",
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        color = CatchyTextPrimaryDark
      )
      Text(
        text = "Showcase your company brand to attract top talent on Catchy.",
        fontSize = 12.sp,
        color = CatchyTextSecondaryDark
      )

      Spacer(modifier = Modifier.height(16.dp))

      ProfileTextField(label = "Company / Business Name", value = compName, onValueChange = { compName = it }, placeholder = "e.g. Catchy Media Ltd.")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Industry", value = industry, onValueChange = { industry = it }, placeholder = "e.g. Software, E-Commerce, Media, FinTech")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Company Website", value = website, onValueChange = { website = it }, placeholder = "https://example.com")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Headquarters / Location", value = location, onValueChange = { location = it }, placeholder = "e.g. Dhaka, Bangladesh")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "Company Size", value = size, onValueChange = { size = it }, placeholder = "e.g. 1-10, 11-50, 50-200 employees")
      Spacer(modifier = Modifier.height(10.dp))
      ProfileTextField(label = "About Company / Mission", value = bio, onValueChange = { bio = it }, placeholder = "Describe your company, culture, and what you build...", maxLines = 4)

      Spacer(modifier = Modifier.height(20.dp))

      Button(
        onClick = {
          onSave(compName, industry, website, location, size, bio, true)
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
      ) {
        Text("Save Employer Profile", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
      }
    }
  }
}

@Composable
private fun ProfileTextField(
  label: String,
  value: String,
  onValueChange: (String) -> Unit,
  placeholder: String,
  maxLines: Int = 1
) {
  Column {
    Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CatchyTextSecondaryDark)
    Spacer(modifier = Modifier.height(4.dp))
    OutlinedTextField(
      value = value,
      onValueChange = onValueChange,
      placeholder = { Text(placeholder, fontSize = 12.sp, color = CatchyTextMutedDark) },
      modifier = Modifier.fillMaxWidth(),
      maxLines = maxLines,
      singleLine = maxLines == 1,
      shape = RoundedCornerShape(10.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CatchyCyan,
        unfocusedBorderColor = CatchyDarkBorder,
        focusedContainerColor = CatchyDarkSurfaceVariant,
        unfocusedContainerColor = CatchyDarkSurfaceVariant,
        focusedTextColor = CatchyTextPrimaryDark,
        unfocusedTextColor = CatchyTextPrimaryDark
      )
    )
  }
}

// ==========================================
// MODAL: JOB DETAILS DIALOG
// ==========================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun JobDetailsDialog(
  job: CatchyJobPosting,
  currentUserId: String?,
  myApplications: List<CatchyJobApplication>,
  onDismiss: () -> Unit,
  onApply: () -> Unit,
  onManageApplicants: () -> Unit,
  onEdit: () -> Unit,
  onMessageEmployer: () -> Unit
) {
  val isOwner = currentUserId != null && currentUserId == job.employerId
  val existingApplication = myApplications.find { it.jobId == job.jobId }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("job_details_dialog"),
      color = CatchyDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(CatchyDarkSurface)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Close", tint = CatchyTextPrimaryDark)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Job Opportunity",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = CatchyTextPrimaryDark
          )
        }

        // Details Content
        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
        ) {
          // Company & Title
          Text(text = job.companyName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = CatchyCyan)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = job.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
          Spacer(modifier = Modifier.height(10.dp))

          // Badges
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            JobBadge(text = job.employmentType, backgroundColor = CatchyIndigo.copy(alpha = 0.25f), textColor = CatchyIndigoLight)
            if (job.isRemote) {
              JobBadge(text = "🌍 Remote", backgroundColor = CatchySuccess.copy(alpha = 0.2f), textColor = CatchySuccess)
            }
            JobBadge(text = job.category, backgroundColor = CatchyViolet.copy(alpha = 0.2f), textColor = CatchyViolet)
            JobBadge(text = job.experienceLevel, backgroundColor = CatchyDarkSurfaceVariant, textColor = CatchyTextSecondaryDark)
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Key Highlights Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = CatchyCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Location: ${job.location.ifBlank { if (job.isRemote) "Remote" else "Worldwide" }}", fontSize = 13.sp, color = CatchyTextPrimaryDark)
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = CatchySuccess, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Salary / Compensation: ${job.salaryRange}", fontSize = 13.sp, color = CatchyTextPrimaryDark)
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.School, contentDescription = null, tint = CatchyViolet, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Experience Level: ${job.experienceLevel}", fontSize = 13.sp, color = CatchyTextPrimaryDark)
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Description
          Text("Job Description & Requirements", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = job.description, fontSize = 14.sp, color = CatchyTextSecondaryDark, lineHeight = 20.sp)

          // Skills Required
          if (job.skillsRequired.isNotBlank()) {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Required Skills", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              job.skillsRequired.split(",", "•", ";").map { it.trim() }.filter { it.isNotEmpty() }.forEach { skill ->
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(CatchyDarkSurfaceVariant)
                    .border(1.dp, CatchyDarkBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                  Text(skill, color = CatchyTextPrimaryDark, fontSize = 12.sp)
                }
              }
            }
          }

          // Application Instructions
          if (job.applicationInstructions.isNotBlank()) {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Application Instructions", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = job.applicationInstructions, fontSize = 13.sp, color = CatchyTextSecondaryDark)
          }

          Spacer(modifier = Modifier.height(24.dp))

          // Employer contact button (if not owner)
          if (!isOwner) {
            OutlinedButton(
              onClick = onMessageEmployer,
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Message Employer via Catchy Chat")
            }
          }
        }

        // Bottom CTA Bar
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = CatchyDarkSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            if (isOwner) {
              OutlinedButton(
                onClick = onEdit,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
              ) {
                Text("Edit Posting")
              }
              Button(
                onClick = onManageApplicants,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
              ) {
                Text("View Applicants")
              }
            } else {
              if (existingApplication != null) {
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = CatchySuccess.copy(alpha = 0.2f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, CatchySuccess)
                ) {
                  Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CatchySuccess, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "Applied on ${SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(existingApplication.appliedAt))} • Status: ${existingApplication.status}",
                      color = CatchySuccess,
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp
                    )
                  }
                }
              } else if (job.status != "ACTIVE") {
                Button(
                  onClick = {},
                  enabled = false,
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp)
                ) {
                  Text("Position Closed")
                }
              } else {
                Button(
                  onClick = onApply,
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
                ) {
                  Text("Apply for this Position", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// MODAL: APPLY DIALOG
// ==========================================

@Composable
private fun JobApplicationDialog(
  job: CatchyJobPosting,
  currentUser: com.example.data.model.UserAccount?,
  seekerProfile: CatchyJobSeekerProfile?,
  isSubmitting: Boolean,
  onDismiss: () -> Unit,
  onSubmit: (
    coverNote: String,
    resumeLink: String,
    skills: String,
    experience: String,
    location: String
  ) -> Unit
) {
  var coverNote by remember { mutableStateOf("") }
  var resumeLink by remember(seekerProfile) { mutableStateOf(seekerProfile?.cvSummaryOrUrl ?: "") }
  var skills by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.skills ?: currentUser?.skills ?: "")
  }
  var experience by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.experienceYears ?: currentUser?.occupationStatus ?: "")
  }
  var location by remember(seekerProfile, currentUser) {
    mutableStateOf(seekerProfile?.location ?: currentUser?.addressLocation ?: "")
  }
  var validationError by remember { mutableStateOf<String?>(null) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("job_application_dialog"),
      color = CatchyDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(CatchyDarkSurface)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = CatchyTextPrimaryDark)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text("Submit Application", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
            Text("${job.title} • ${job.companyName}", fontSize = 12.sp, color = CatchyCyan)
          }
        }

        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Applicant identity badge
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(CatchyIndigo),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = (currentUser?.fullName ?: "U").take(1).uppercase(),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 18.sp
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(text = currentUser?.fullName ?: "Applicant", fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark, fontSize = 15.sp)
                Text(text = currentUser?.email ?: "", fontSize = 12.sp, color = CatchyTextSecondaryDark)
              }
            }
          }

          if (validationError != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = CatchyError.copy(alpha = 0.2f),
              border = androidx.compose.foundation.BorderStroke(1.dp, CatchyError)
            ) {
              Text(
                text = validationError!!,
                color = CatchyError,
                fontSize = 12.sp,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          ProfileTextField(
            label = "Cover Note / Introduction *",
            value = coverNote,
            onValueChange = { coverNote = it },
            placeholder = "Tell the employer why you are a great fit for this position...",
            maxLines = 5
          )

          ProfileTextField(
            label = "Resume / Portfolio URL (LinkedIn, GitHub, Drive) *",
            value = resumeLink,
            onValueChange = { resumeLink = it },
            placeholder = "https://linkedin.com/in/... or portfolio link"
          )

          ProfileTextField(
            label = "Relevant Skills Highlight",
            value = skills,
            onValueChange = { skills = it },
            placeholder = "e.g. Kotlin, Jetpack Compose, REST APIs"
          )

          ProfileTextField(
            label = "Years of Experience / Background",
            value = experience,
            onValueChange = { experience = it },
            placeholder = "e.g. 3 years in mobile app engineering"
          )

          ProfileTextField(
            label = "Your Location",
            value = location,
            onValueChange = { location = it },
            placeholder = "e.g. Dhaka, Bangladesh"
          )

          Spacer(modifier = Modifier.height(10.dp))
        }

        // Submit Bar
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = CatchyDarkSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            OutlinedButton(
              onClick = onDismiss,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("Cancel")
            }

            Button(
              onClick = {
                if (coverNote.isBlank()) {
                  validationError = "Please provide a brief cover note or introduction."
                  return@Button
                }
                if (resumeLink.isBlank()) {
                  validationError = "Please provide a resume, CV or portfolio link."
                  return@Button
                }
                validationError = null
                onSubmit(coverNote, resumeLink, skills, experience, location)
              },
              enabled = !isSubmitting,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
            ) {
              if (isSubmitting) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
              } else {
                Text("Submit Application", color = Color.Black, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// MODAL: CREATE / EDIT JOB POSTING
// ==========================================

@Composable
private fun JobPostEditorDialog(
  editingJob: CatchyJobPosting?,
  isSaving: Boolean,
  errorMessage: String?,
  onDismiss: () -> Unit,
  onSave: (
    title: String,
    company: String,
    desc: String,
    cat: String,
    skills: String,
    loc: String,
    remote: Boolean,
    empType: String,
    expLevel: String,
    salary: String,
    instructions: String,
    status: String
  ) -> Unit
) {
  var title by remember(editingJob) { mutableStateOf(editingJob?.title ?: "") }
  var company by remember(editingJob) { mutableStateOf(editingJob?.companyName ?: "") }
  var description by remember(editingJob) { mutableStateOf(editingJob?.description ?: "") }
  var category by remember(editingJob) { mutableStateOf(editingJob?.category ?: "Engineering & Tech") }
  var skills by remember(editingJob) { mutableStateOf(editingJob?.skillsRequired ?: "") }
  var location by remember(editingJob) { mutableStateOf(editingJob?.location ?: "Dhaka, Bangladesh") }
  var isRemote by remember(editingJob) { mutableStateOf(editingJob?.isRemote ?: false) }
  var empType by remember(editingJob) { mutableStateOf(editingJob?.employmentType ?: "Full-time") }
  var expLevel by remember(editingJob) { mutableStateOf(editingJob?.experienceLevel ?: "Mid-Level") }
  var salary by remember(editingJob) { mutableStateOf(editingJob?.salaryRange ?: "Negotiable") }
  var instructions by remember(editingJob) { mutableStateOf(editingJob?.applicationInstructions ?: "") }
  var status by remember(editingJob) { mutableStateOf(editingJob?.status ?: "ACTIVE") }

  var validationError by remember { mutableStateOf<String?>(null) }

  val categories = listOf("Engineering & Tech", "Design & Creative", "Marketing & Growth", "Sales & Ops", "Content & Media", "Other")
  val employmentTypes = listOf("Full-time", "Part-time", "Internship", "Apprenticeship", "Freelance", "Remote")
  val experienceLevels = listOf("Entry / Junior", "Mid-Level", "Senior", "Lead / Director", "Any")

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("job_post_editor_dialog"),
      color = CatchyDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(CatchyDarkSurface)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = CatchyTextPrimaryDark)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (editingJob != null) "Edit Job Posting" else "Create Job Posting",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = CatchyTextPrimaryDark
          )
        }

        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          if (errorMessage != null || validationError != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = CatchyError.copy(alpha = 0.2f),
              border = androidx.compose.foundation.BorderStroke(1.dp, CatchyError)
            ) {
              Text(
                text = errorMessage ?: validationError!!,
                color = CatchyError,
                fontSize = 12.sp,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          ProfileTextField(label = "Job Title *", value = title, onValueChange = { title = it }, placeholder = "e.g. Senior Android Engineer")
          ProfileTextField(label = "Company / Business Name *", value = company, onValueChange = { company = it }, placeholder = "e.g. Catchy Inc.")

          // Category Selector
          Text("Category", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CatchyTextSecondaryDark)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            categories.forEach { cat ->
              FilterChip(
                selected = category == cat,
                onClick = { category = cat },
                label = { Text(cat, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = CatchyIndigo,
                  selectedLabelColor = Color.White
                )
              )
            }
          }

          // Employment Type Selector
          Text("Opportunity Type", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CatchyTextSecondaryDark)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            employmentTypes.forEach { type ->
              FilterChip(
                selected = empType == type,
                onClick = { empType = type },
                label = { Text(type, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = CatchyViolet,
                  selectedLabelColor = Color.White
                )
              )
            }
          }

          // Remote Switch
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("Remote Opportunity", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = CatchyTextPrimaryDark)
              Text("Check if candidates can work from anywhere", fontSize = 11.sp, color = CatchyTextMutedDark)
            }
            Switch(
              checked = isRemote,
              onCheckedChange = { isRemote = it },
              colors = SwitchDefaults.colors(checkedThumbColor = CatchyCyan, checkedTrackColor = CatchyCyan.copy(alpha = 0.5f))
            )
          }

          ProfileTextField(label = "Location", value = location, onValueChange = { location = it }, placeholder = "e.g. Dhaka, Bangladesh or Worldwide")

          // Experience Level
          Text("Experience Level", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CatchyTextSecondaryDark)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            experienceLevels.forEach { exp ->
              FilterChip(
                selected = expLevel == exp,
                onClick = { expLevel = exp },
                label = { Text(exp, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = CatchyIndigo,
                  selectedLabelColor = Color.White
                )
              )
            }
          }

          ProfileTextField(label = "Salary Range / Budget", value = salary, onValueChange = { salary = it }, placeholder = "e.g. $60k - $80k / yr, ৳80k / mo, or Negotiable")
          ProfileTextField(label = "Required Skills (comma-separated)", value = skills, onValueChange = { skills = it }, placeholder = "Kotlin, Compose, Room, MVVM")
          ProfileTextField(label = "Detailed Description & Requirements *", value = description, onValueChange = { description = it }, placeholder = "Describe roles, responsibilities, team, and stack...", maxLines = 6)
          ProfileTextField(label = "Application Instructions", value = instructions, onValueChange = { instructions = it }, placeholder = "e.g. Please include links to recent projects")

          Spacer(modifier = Modifier.height(10.dp))
        }

        // Save Bar
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = CatchyDarkSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            OutlinedButton(
              onClick = onDismiss,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("Cancel")
            }

            Button(
              onClick = {
                if (title.isBlank()) {
                  validationError = "Job title is required."
                  return@Button
                }
                if (company.isBlank()) {
                  validationError = "Company name is required."
                  return@Button
                }
                if (description.isBlank()) {
                  validationError = "Job description is required."
                  return@Button
                }
                validationError = null
                onSave(title, company, description, category, skills, location, isRemote, empType, expLevel, salary, instructions, status)
              },
              enabled = !isSaving,
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
            ) {
              if (isSaving) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
              } else {
                Text("Save Job Post", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// MODAL: MANAGE APPLICANTS (EMPLOYER VIEW)
// ==========================================

@Composable
private fun ManageApplicantsDialog(
  job: CatchyJobPosting,
  applicants: List<CatchyJobApplication>,
  onDismiss: () -> Unit,
  onUpdateStatus: (applicationId: String, newStatus: String) -> Unit,
  onMessageCandidate: (applicantId: String, applicantName: String) -> Unit
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("manage_applicants_dialog"),
      color = CatchyDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(CatchyDarkSurface)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Close", tint = CatchyTextPrimaryDark)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text("Applicants for ${job.title}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = CatchyTextPrimaryDark)
            Text("${applicants.size} candidate(s) applied", fontSize = 12.sp, color = CatchyCyan)
          }
        }

        if (applicants.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.People, contentDescription = null, tint = CatchyTextMutedDark, modifier = Modifier.size(64.dp))
              Spacer(modifier = Modifier.height(16.dp))
              Text("No Applications Yet", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = CatchyTextPrimaryDark)
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                "When job seekers apply to this position, their credentials and cover notes will appear here.",
                fontSize = 13.sp,
                color = CatchyTextSecondaryDark,
                textAlign = TextAlign.Center
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            items(applicants, key = { it.applicationId }) { app ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CatchyDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CatchyDarkBorder)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      modifier = Modifier.weight(1f)
                    ) {
                      Box(
                        modifier = Modifier
                          .size(40.dp)
                          .clip(CircleShape)
                          .background(CatchyIndigo),
                        contentAlignment = Alignment.Center
                      ) {
                        Text(
                          text = app.applicantName.take(1).uppercase(),
                          color = Color.White,
                          fontWeight = FontWeight.Bold
                        )
                      }
                      Spacer(modifier = Modifier.width(10.dp))
                      Column {
                        Text(text = app.applicantName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CatchyTextPrimaryDark)
                        Text(text = "${app.applicantEmail} • ${app.applicantLocation}", fontSize = 12.sp, color = CatchyTextSecondaryDark)
                      }
                    }

                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CatchyDarkSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(app.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CatchyCyan)
                    }
                  }

                  Spacer(modifier = Modifier.height(10.dp))

                  if (app.coverNote.isNotBlank()) {
                    Text(
                      text = "Cover Note: \"${app.coverNote}\"",
                      fontSize = 13.sp,
                      color = CatchyTextSecondaryDark
                    )
                  }

                  if (app.resumeOrPortfolioLink.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = "Portfolio / CV: ${app.resumeOrPortfolioLink}",
                      fontSize = 12.sp,
                      color = CatchyCyanGlow
                    )
                  }

                  if (app.applicantSkills.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = "Skills: ${app.applicantSkills}",
                      fontSize = 12.sp,
                      color = CatchyTextMutedDark
                    )
                  }

                  Spacer(modifier = Modifier.height(12.dp))
                  HorizontalDivider(color = CatchyDarkBorder, thickness = 0.5.dp)
                  Spacer(modifier = Modifier.height(10.dp))

                  // Status actions & Chat candidate
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Button(
                      onClick = { onMessageCandidate(app.applicantId, app.applicantName) },
                      shape = RoundedCornerShape(8.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
                    ) {
                      Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                      Spacer(modifier = Modifier.width(4.dp))
                      Text("Chat Candidate", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                      if (app.status != "SHORTLISTED") {
                        OutlinedButton(
                          onClick = { onUpdateStatus(app.applicationId, "SHORTLISTED") },
                          shape = RoundedCornerShape(8.dp)
                        ) {
                          Text("Shortlist", fontSize = 11.sp)
                        }
                      }

                      if (app.status != "ACCEPTED") {
                        Button(
                          onClick = { onUpdateStatus(app.applicationId, "ACCEPTED") },
                          shape = RoundedCornerShape(8.dp),
                          colors = ButtonDefaults.buttonColors(containerColor = CatchySuccess)
                        ) {
                          Text("Accept", fontSize = 11.sp)
                        }
                      }

                      if (app.status != "REJECTED") {
                        OutlinedButton(
                          onClick = { onUpdateStatus(app.applicationId, "REJECTED") },
                          shape = RoundedCornerShape(8.dp)
                        ) {
                          Text("Reject", fontSize = 11.sp, color = CatchyError)
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// UTILITY
// ==========================================

private fun formatRelativeTime(timestamp: Long): String {
  val diff = System.currentTimeMillis() - timestamp
  val seconds = diff / 1000
  val minutes = seconds / 60
  val hours = minutes / 60
  val days = hours / 24

  return when {
    seconds < 60 -> "Just now"
    minutes < 60 -> "${minutes}m ago"
    hours < 24 -> "${hours}h ago"
    days < 7 -> "${days}d ago"
    else -> SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(timestamp))
  }
}
