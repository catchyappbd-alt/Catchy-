package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyCommunity
import com.example.data.model.CatchyCommunityCategories
import com.example.data.model.CatchyCommunityMember
import com.example.data.model.CatchyCommunityPost
import com.example.data.model.CatchyCommunityPostComment
import com.example.data.model.CatchyCommunityTab
import com.example.data.model.CommunityDetailTab
import com.example.ui.viewmodel.AccountViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Catchy Community Palette
private val CommDarkBg = Color(0xFF0C0D14)
private val CommCardBg = Color(0xFF151824)
private val CommBorder = Color(0xFF23283B)
private val CommPrimary = Color(0xFF6C5CE7)
private val CommPrimaryLight = Color(0xFF8C7AE6)
private val CommAccent = Color(0xFF00E5FF)
private val CommPink = Color(0xFFFF2A6D)
private val CommEmerald = Color(0xFF00E676)
private val CommGold = Color(0xFFFFD166)

private val CoverGradients = listOf(
  Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF3F51B5))),
  Brush.linearGradient(listOf(Color(0xFFFF2A6D), Color(0xFF9C27B0))),
  Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF009688))),
  Brush.linearGradient(listOf(Color(0xFFFFD166), Color(0xFFFF5722))),
  Brush.linearGradient(listOf(Color(0xFF00E676), Color(0xFF1B5E20))),
  Brush.linearGradient(listOf(Color(0xFF2C3E50), Color(0xFF000000)))
)

@Composable
fun CatchyCommunityDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentTab by viewModel.communityTab.collectAsState()
  val selectedCommunity by viewModel.selectedCommunity.collectAsState()
  val isEditorOpen by viewModel.isCommunityEditorVisible.collectAsState()
  val isPostEditorOpen by viewModel.isCommunityPostEditorVisible.collectAsState()
  val feedbackMsg by viewModel.communityFeedbackMessage.collectAsState()
  val reportingItem by viewModel.reportingCommunityItem.collectAsState()

  val context = LocalContext.current
  LaunchedEffect(feedbackMsg) {
    feedbackMsg?.let { msg ->
      Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
      viewModel.clearCommunityFeedbackMessage()
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("catchy_community_dialog"),
      color = CommDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Header
        CommunityHeader(
          onClose = onDismiss,
          onCreateCommunity = { viewModel.showCreateCommunityDialog() }
        )

        // Main Navigation Tabs
        CommunityTabRow(
          currentTab = currentTab,
          onSelectTab = { viewModel.setCommunityTab(it) }
        )

        // Content Area
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          when (currentTab) {
            CatchyCommunityTab.EXPLORE -> ExploreCommunitiesView(viewModel = viewModel)
            CatchyCommunityTab.MY_COMMUNITIES -> MyCommunitiesView(viewModel = viewModel)
          }
        }
      }

      // Modals & Dialogs
      if (selectedCommunity != null) {
        CommunityDetailsDialog(
          community = selectedCommunity!!,
          viewModel = viewModel,
          onDismiss = { viewModel.selectCommunity(null) }
        )
      }

      if (isEditorOpen) {
        CommunityEditorDialog(
          viewModel = viewModel,
          onDismiss = { viewModel.hideCommunityEditor() }
        )
      }

      if (isPostEditorOpen) {
        CommunityPostEditorDialog(
          viewModel = viewModel,
          onDismiss = { viewModel.hideCommunityPostEditor() }
        )
      }

      if (reportingItem != null) {
        CommunityReportDialog(
          viewModel = viewModel,
          onDismiss = { viewModel.closeCommunityReportDialog() }
        )
      }
    }
  }
}

@Composable
private fun CommunityHeader(
  onClose: () -> Unit,
  onCreateCommunity: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(CommCardBg)
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onClose,
        modifier = Modifier.testTag("close_community_button")
      ) {
        Icon(
          imageVector = Icons.Default.ArrowBack,
          contentDescription = "Back",
          tint = Color.White
        )
      }
      Spacer(modifier = Modifier.width(6.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Catchy",
            style = MaterialThemeTypography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = CommAccent
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Community",
            style = MaterialThemeTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }
        Text(
          text = "Real Connections & Shared Passions",
          style = MaterialThemeTypography.bodySmall,
          color = Color.Gray
        )
      }
    }

    Button(
      onClick = onCreateCommunity,
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
      modifier = Modifier.testTag("create_community_button")
    ) {
      Icon(
        imageVector = Icons.Default.Add,
        contentDescription = null,
        modifier = Modifier.size(16.dp),
        tint = Color.White
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "Create",
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White
      )
    }
  }
}

@Composable
private fun CommunityTabRow(
  currentTab: CatchyCommunityTab,
  onSelectTab: (CatchyCommunityTab) -> Unit
) {
  TabRow(
    selectedTabIndex = currentTab.ordinal,
    containerColor = CommCardBg,
    contentColor = Color.White,
    indicator = { tabPositions ->
      TabRowDefaults.SecondaryIndicator(
        modifier = Modifier.tabIndicatorOffset(tabPositions[currentTab.ordinal]),
        color = CommPrimary
      )
    }
  ) {
    Tab(
      selected = currentTab == CatchyCommunityTab.EXPLORE,
      onClick = { onSelectTab(CatchyCommunityTab.EXPLORE) },
      modifier = Modifier.testTag("community_tab_explore"),
      text = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Public,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = if (currentTab == CatchyCommunityTab.EXPLORE) CommPrimaryLight else Color.Gray
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Explore",
            fontWeight = if (currentTab == CatchyCommunityTab.EXPLORE) FontWeight.Bold else FontWeight.Normal,
            color = if (currentTab == CatchyCommunityTab.EXPLORE) Color.White else Color.Gray
          )
        }
      }
    )

    Tab(
      selected = currentTab == CatchyCommunityTab.MY_COMMUNITIES,
      onClick = { onSelectTab(CatchyCommunityTab.MY_COMMUNITIES) },
      modifier = Modifier.testTag("community_tab_my_communities"),
      text = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Groups,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = if (currentTab == CatchyCommunityTab.MY_COMMUNITIES) CommPrimaryLight else Color.Gray
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "My Communities",
            fontWeight = if (currentTab == CatchyCommunityTab.MY_COMMUNITIES) FontWeight.Bold else FontWeight.Normal,
            color = if (currentTab == CatchyCommunityTab.MY_COMMUNITIES) Color.White else Color.Gray
          )
        }
      }
    )
  }
}

@Composable
private fun ExploreCommunitiesView(viewModel: AccountViewModel) {
  val communities by viewModel.filteredCommunities.collectAsState()
  val searchQuery by viewModel.communitySearchQuery.collectAsState()
  val selectedCategory by viewModel.selectedCommunityCategory.collectAsState()

  Column(modifier = Modifier.fillMaxSize()) {
    // Search Bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { viewModel.setCommunitySearchQuery(it) },
      placeholder = { Text("Search communities by name, topic, or creator...", color = Color.Gray) },
      leadingIcon = {
        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = CommAccent)
      },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { viewModel.setCommunitySearchQuery("") }) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CommPrimary,
        unfocusedBorderColor = CommBorder,
        focusedContainerColor = CommCardBg,
        unfocusedContainerColor = CommCardBg,
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      ),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("community_search_field")
    )

    // Category Filter Chips
    val categories = listOf("All") + CatchyCommunityCategories.ALL
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      categories.forEach { category ->
        val isSelected = selectedCategory == category
        FilterChip(
          selected = isSelected,
          onClick = { viewModel.setSelectedCommunityCategory(category) },
          label = { Text(category, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CommPrimary,
            selectedLabelColor = Color.White,
            containerColor = CommCardBg,
            labelColor = Color.LightGray
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = isSelected,
            borderColor = if (isSelected) CommPrimary else CommBorder
          ),
          shape = RoundedCornerShape(20.dp)
        )
      }
    }

    // Communities List
    if (communities.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Groups,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = Color.Gray.copy(alpha = 0.5f)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "No communities found",
            style = MaterialThemeTypography.titleMedium,
            color = Color.White
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = if (searchQuery.isNotBlank() || selectedCategory != "All") "Try adjusting your filters or search terms." else "Be the first to create a community on Catchy!",
            style = MaterialThemeTypography.bodyMedium,
            color = Color.Gray,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = { viewModel.showCreateCommunityDialog() },
            colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("Create Community", color = Color.White)
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(communities, key = { it.id }) { comm ->
          CommunityCard(
            community = comm,
            onClick = { viewModel.selectCommunity(comm) }
          )
        }
      }
    }
  }
}

@Composable
private fun MyCommunitiesView(viewModel: AccountViewModel) {
  val myCommunities by viewModel.myJoinedCommunities.collectAsState()

  if (myCommunities.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          imageVector = Icons.Default.Groups,
          contentDescription = null,
          modifier = Modifier.size(64.dp),
          tint = CommPrimaryLight.copy(alpha = 0.5f)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "You haven't joined any communities yet",
          style = MaterialThemeTypography.titleMedium,
          color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Explore passionate communities or start your own to share ideas, photos, and videos with like-minded members.",
          style = MaterialThemeTypography.bodyMedium,
          color = Color.Gray,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = { viewModel.setCommunityTab(CatchyCommunityTab.EXPLORE) },
            colors = ButtonDefaults.buttonColors(containerColor = CommCardBg),
            shape = RoundedCornerShape(12.dp),
            border = ButtonDefaults.outlinedButtonBorder
          ) {
            Text("Explore Communities", color = Color.White)
          }
          Button(
            onClick = { viewModel.showCreateCommunityDialog() },
            colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("Create Community", color = Color.White)
          }
        }
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        Text(
          text = "Communities you belong to (${myCommunities.size})",
          style = MaterialThemeTypography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = CommAccent,
          modifier = Modifier.padding(bottom = 4.dp)
        )
      }
      items(myCommunities, key = { it.id }) { comm ->
        CommunityCard(
          community = comm,
          onClick = { viewModel.selectCommunity(comm) }
        )
      }
    }
  }
}

@Composable
private fun CommunityCard(
  community: CatchyCommunity,
  onClick: () -> Unit
) {
  val gradientIndex = (community.coverGradientIndex).coerceIn(0, CoverGradients.size - 1)
  val gradient = CoverGradients[gradientIndex]

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, CommBorder, RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("community_card_${community.id}"),
    colors = CardDefaults.cardColors(containerColor = CommCardBg)
  ) {
    Column {
      // Banner / Header Preview
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(84.dp)
          .background(gradient)
          .padding(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          // Category Pill
          Box(
            modifier = Modifier
              .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = community.category,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          // Privacy Pill
          Box(
            modifier = Modifier
              .background(
                if (community.isPrivate) CommPink.copy(alpha = 0.8f) else CommEmerald.copy(alpha = 0.8f),
                RoundedCornerShape(12.dp)
              )
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (community.isPrivate) Icons.Default.Lock else Icons.Default.Public,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = Color.White
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (community.isPrivate) "Private" else "Public",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }

      // Community Body Info
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Avatar
          Box(
            modifier = Modifier
              .size(44.dp)
              .background(CommDarkBg, CircleShape)
              .border(2.dp, CommPrimary, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = community.name.take(1).uppercase(),
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold,
              color = CommAccent
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = community.name,
              style = MaterialThemeTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = "By ${community.creatorName}",
              style = MaterialThemeTypography.bodySmall,
              color = Color.LightGray
            )
          }
          // Members counter
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Groups,
              contentDescription = null,
              tint = CommPrimaryLight,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${community.memberCount}",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = Color.White
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = community.description,
          style = MaterialThemeTypography.bodyMedium,
          color = Color.LightGray,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

// =========================================================================
// COMMUNITY DETAILS DIALOG & TABS
// =========================================================================
@Composable
private fun CommunityDetailsDialog(
  community: CatchyCommunity,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val detailTab by viewModel.communityDetailTab.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val isMember by viewModel.isCurrentUserCommunityMember.collectAsState()
  val userRole by viewModel.currentUserRoleInSelectedCommunity.collectAsState()
  val isOwner = currentUser?.userId == community.creatorUserId

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("community_details_dialog"),
      color = CommDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Immersive Banner Header
        val gradientIndex = (community.coverGradientIndex).coerceIn(0, CoverGradients.size - 1)
        val gradient = CoverGradients[gradientIndex]

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(gradient)
        ) {
          // Top Buttons
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                .size(38.dp)
            ) {
              Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (isOwner) {
                IconButton(
                  onClick = { viewModel.showEditCommunityDialog(community) },
                  modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .size(38.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Settings",
                    tint = Color.White
                  )
                }
              }
              IconButton(
                onClick = { viewModel.openCommunityReportDialog("COMMUNITY", community.id) },
                modifier = Modifier
                  .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                  .size(38.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Flag,
                  contentDescription = "Report",
                  tint = Color.White
                )
              }
            }
          }

          // Bottom category & privacy pills
          Row(
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = community.category,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }

            Box(
              modifier = Modifier
                .background(
                  if (community.isPrivate) CommPink.copy(alpha = 0.8f) else CommEmerald.copy(alpha = 0.8f),
                  RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = if (community.isPrivate) "Private" else "Public",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }

        // Community Quick Actions & Title Row
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(CommCardBg)
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = community.name,
                style = MaterialThemeTypography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "${community.memberCount} members • Created by ${community.creatorName}",
                style = MaterialThemeTypography.bodySmall,
                color = Color.Gray
              )
            }

            // Membership Button
            if (isOwner) {
              Box(
                modifier = Modifier
                  .background(CommGold.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                  .border(1.dp, CommGold, RoundedCornerShape(12.dp))
                  .padding(horizontal = 12.dp, vertical = 6.dp)
              ) {
                Text(
                  text = "OWNER",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = CommGold
                )
              }
            } else if (isMember) {
              OutlinedButton(
                onClick = { viewModel.leaveCommunity(community.id) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CommPink),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(CommPink, CommPink))),
                modifier = Modifier.testTag("leave_community_button")
              ) {
                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Leave", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            } else {
              Button(
                onClick = { viewModel.joinCommunity(community.id) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
                modifier = Modifier.testTag("join_community_button")
              ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Join", fontWeight = FontWeight.Bold, color = Color.White)
              }
            }
          }
        }

        // Details Tabs (POSTS, MEMBERS, ABOUT)
        TabRow(
          selectedTabIndex = detailTab.ordinal,
          containerColor = CommCardBg,
          contentColor = Color.White,
          indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
              modifier = Modifier.tabIndicatorOffset(tabPositions[detailTab.ordinal]),
              color = CommAccent
            )
          }
        ) {
          CommunityDetailTab.values().forEach { tab ->
            val isSelected = detailTab == tab
            Tab(
              selected = isSelected,
              onClick = { viewModel.setCommunityDetailTab(tab) },
              modifier = Modifier.testTag("community_detail_tab_${tab.name.lowercase()}"),
              text = {
                Text(
                  text = when (tab) {
                    CommunityDetailTab.POSTS -> "Discussions"
                    CommunityDetailTab.MEMBERS -> "Members (${community.memberCount})"
                    CommunityDetailTab.ABOUT -> "About & Rules"
                  },
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) Color.White else Color.Gray
                )
              }
            )
          }
        }

        // Tab Content
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          when (detailTab) {
            CommunityDetailTab.POSTS -> CommunityPostsTabView(
              community = community,
              viewModel = viewModel,
              isMember = isMember || isOwner
            )
            CommunityDetailTab.MEMBERS -> CommunityMembersTabView(
              community = community,
              viewModel = viewModel,
              currentUserRole = userRole
            )
            CommunityDetailTab.ABOUT -> CommunityAboutTabView(
              community = community,
              viewModel = viewModel,
              isOwner = isOwner
            )
          }
        }
      }
    }
  }
}

// =========================================================================
// TAB 1: DISCUSSIONS / POSTS
// =========================================================================
@Composable
private fun CommunityPostsTabView(
  community: CatchyCommunity,
  viewModel: AccountViewModel,
  isMember: Boolean
) {
  val posts by viewModel.communityPosts.collectAsState()
  val activeCommentsPostId by viewModel.activeCommunityPostCommentsId.collectAsState()

  Column(modifier = Modifier.fillMaxSize()) {
    // Create Post Box (if member or owner)
    if (isMember) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
          .clip(RoundedCornerShape(14.dp))
          .border(1.dp, CommBorder, RoundedCornerShape(14.dp))
          .clickable { viewModel.showCreateCommunityPostDialog() }
          .testTag("create_community_post_card"),
        colors = CardDefaults.cardColors(containerColor = CommCardBg)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(CommPrimary.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = null,
              tint = CommPrimaryLight,
              modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Share text, photo, or video with community...",
            color = Color.Gray,
            fontSize = 13.sp,
            modifier = Modifier.weight(1f)
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(imageVector = Icons.Default.Image, contentDescription = "Photo", tint = CommAccent, modifier = Modifier.size(20.dp))
            Icon(imageVector = Icons.Default.Videocam, contentDescription = "Video", tint = CommPink, modifier = Modifier.size(20.dp))
          }
        }
      }
    } else {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        colors = CardDefaults.cardColors(containerColor = CommCardBg)
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Lock, contentDescription = null, tint = CommGold, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Join this community to share posts, photos, and videos with members.",
            color = Color.LightGray,
            fontSize = 13.sp
          )
        }
      }
    }

    // Posts Feed
    if (posts.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.ModeComment,
            contentDescription = null,
            modifier = Modifier.size(54.dp),
            tint = Color.Gray.copy(alpha = 0.5f)
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "No discussions yet",
            style = MaterialThemeTypography.titleMedium,
            color = Color.White
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (isMember) "Be the first to post something!" else "Join now to start the first conversation.",
            style = MaterialThemeTypography.bodyMedium,
            color = Color.Gray
          )
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(posts, key = { it.postId }) { post ->
          CommunityPostItem(
            post = post,
            viewModel = viewModel,
            isCommentsExpanded = activeCommentsPostId == post.postId
          )
        }
        item {
          Spacer(modifier = Modifier.height(20.dp))
        }
      }
    }
  }
}

@Composable
private fun CommunityPostItem(
  post: CatchyCommunityPost,
  viewModel: AccountViewModel,
  isCommentsExpanded: Boolean
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val userRole by viewModel.currentUserRoleInSelectedCommunity.collectAsState()
  val isAuthor = currentUser?.userId == post.authorUserId
  val canModerate = isAuthor || userRole == "OWNER" || userRole == "ADMIN"
  var showMenu by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .border(1.dp, CommBorder, RoundedCornerShape(14.dp))
      .testTag("community_post_${post.postId}"),
    colors = CardDefaults.cardColors(containerColor = CommCardBg)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Author and header
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clickable {
            viewModel.openCommunityMemberProfile(post.authorUserId, post.authorName, post.authorAvatar)
          }
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .background(CommPrimary.copy(alpha = 0.3f), CircleShape)
              .border(1.dp, CommPrimaryLight, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = post.authorName.take(1).uppercase(),
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = post.authorName,
                style = MaterialThemeTypography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              if (post.isPinned) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .background(CommGold.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PushPin, contentDescription = null, tint = CommGold, modifier = Modifier.size(10.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("PINNED", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = CommGold)
                  }
                }
              }
            }
            val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(post.createdAt))
            Text(text = dateStr, style = MaterialThemeTypography.bodySmall, color = Color.Gray)
          }
        }

        // Actions Menu
        Box {
          IconButton(onClick = { showMenu = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = Color.Gray)
          }
          DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false },
            modifier = Modifier.background(CommCardBg)
          ) {
            if (isAuthor) {
              DropdownMenuItem(
                text = { Text("Edit Post", color = Color.White) },
                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = CommAccent) },
                onClick = {
                  showMenu = false
                  viewModel.showEditCommunityPostDialog(post)
                }
              )
            }
            if (userRole == "OWNER" || userRole == "ADMIN") {
              DropdownMenuItem(
                text = { Text(if (post.isPinned) "Unpin Post" else "Pin to Top", color = Color.White) },
                leadingIcon = { Icon(Icons.Default.PushPin, contentDescription = null, tint = CommGold) },
                onClick = {
                  showMenu = false
                  viewModel.toggleCommunityPostPin(post.postId)
                }
              )
            }
            if (canModerate) {
              DropdownMenuItem(
                text = { Text("Delete Post", color = CommPink) },
                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = CommPink) },
                onClick = {
                  showMenu = false
                  viewModel.deleteCommunityPost(post.postId)
                }
              )
            }
            DropdownMenuItem(
              text = { Text("Report Post", color = Color.LightGray) },
              leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null, tint = Color.LightGray) },
              onClick = {
                showMenu = false
                viewModel.openCommunityReportDialog("POST", post.postId)
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Content
      if (post.content.isNotBlank()) {
        Text(
          text = post.content,
          style = MaterialThemeTypography.bodyLarge,
          color = Color.White,
          lineHeight = 22.sp
        )
      }

      // Media Preview if attached
      if (!post.mediaType.isNullOrBlank() || !post.mediaLabel.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(10.dp))
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, CommBorder, RoundedCornerShape(10.dp)),
          colors = CardDefaults.cardColors(
            containerColor = if (post.mediaType == "video") Color(0xFF1E1026) else Color(0xFF101C26)
          )
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = if (post.mediaType == "video") Icons.Default.Videocam else Icons.Default.Image,
              contentDescription = null,
              tint = if (post.mediaType == "video") CommPink else CommAccent,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = post.mediaLabel ?: (if (post.mediaType == "video") "Video Attachment" else "Photo Attachment"),
                style = MaterialThemeTypography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = if (post.mediaType == "video") "Ready for stream playback" else "Full resolution photo",
                style = MaterialThemeTypography.bodySmall,
                color = Color.Gray
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      HorizontalDivider(color = CommBorder)
      Spacer(modifier = Modifier.height(8.dp))

      // Interaction Row: Like, Comment, Share
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Like Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { viewModel.toggleCommunityPostLike(post.postId) }
            .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(
            imageVector = if (post.likesCount > 0) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Like",
            tint = if (post.likesCount > 0) CommPink else Color.Gray,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${post.likesCount}",
            fontSize = 13.sp,
            color = if (post.likesCount > 0) CommPink else Color.Gray,
            fontWeight = FontWeight.Bold
          )
        }

        // Comment Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable {
              if (isCommentsExpanded) viewModel.closeCommunityPostComments()
              else viewModel.openCommunityPostComments(post.postId)
            }
            .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ModeComment,
            contentDescription = "Comments",
            tint = if (isCommentsExpanded) CommAccent else Color.Gray,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${post.commentsCount}",
            fontSize = 13.sp,
            color = if (isCommentsExpanded) CommAccent else Color.Gray,
            fontWeight = FontWeight.Bold
          )
        }

        // Share Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { viewModel.shareCommunityPost(post) }
            .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            tint = Color.Gray,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${post.sharesCount}",
            fontSize = 13.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // Comments Section (Animated expansion)
      AnimatedVisibility(visible = isCommentsExpanded) {
        CommunityPostCommentsSection(
          postId = post.postId,
          viewModel = viewModel
        )
      }
    }
  }
}

@Composable
private fun CommunityPostCommentsSection(
  postId: String,
  viewModel: AccountViewModel
) {
  val comments by viewModel.activeCommunityPostComments.collectAsState()
  var newCommentText by remember { mutableStateOf("") }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(top = 10.dp)
      .background(CommDarkBg.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
      .padding(10.dp)
  ) {
    Text(
      text = "Comments (${comments.size})",
      style = MaterialThemeTypography.bodySmall.copy(fontWeight = FontWeight.Bold),
      color = CommAccent
    )

    Spacer(modifier = Modifier.height(8.dp))

    if (comments.isEmpty()) {
      Text(
        text = "No comments yet. Start the conversation!",
        fontSize = 12.sp,
        color = Color.Gray,
        modifier = Modifier.padding(vertical = 4.dp)
      )
    } else {
      for (comment in comments) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          verticalAlignment = Alignment.Top
        ) {
          Box(
            modifier = Modifier
              .size(26.dp)
              .background(CommPrimary.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = comment.authorName.take(1).uppercase(),
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = comment.authorName,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Text(
              text = comment.content,
              fontSize = 13.sp,
              color = Color.LightGray
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Add Comment input row
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = newCommentText,
        onValueChange = { newCommentText = it },
        placeholder = { Text("Write a comment...", fontSize = 12.sp, color = Color.Gray) },
        singleLine = true,
        shape = RoundedCornerShape(20.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = CommCardBg,
          unfocusedContainerColor = CommCardBg,
          focusedBorderColor = CommPrimary,
          unfocusedBorderColor = CommBorder,
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White
        ),
        modifier = Modifier
          .weight(1f)
          .height(48.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      IconButton(
        onClick = {
          if (newCommentText.isNotBlank()) {
            viewModel.addCommunityPostComment(postId, newCommentText.trim())
            newCommentText = ""
          }
        },
        enabled = newCommentText.isNotBlank()
      ) {
        Icon(
          imageVector = Icons.Default.Send,
          contentDescription = "Send",
          tint = if (newCommentText.isNotBlank()) CommAccent else Color.Gray
        )
      }
    }
  }
}

// =========================================================================
// TAB 2: MEMBERS
// =========================================================================
@Composable
private fun CommunityMembersTabView(
  community: CatchyCommunity,
  viewModel: AccountViewModel,
  currentUserRole: String?
) {
  val members by viewModel.communityMembers.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val isOwner = currentUserRole == "OWNER"

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(14.dp)
  ) {
    Text(
      text = "Community Members (${members.size})",
      style = MaterialThemeTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
      color = Color.White
    )
    Spacer(modifier = Modifier.height(10.dp))

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(members, key = { it.userId }) { member ->
        val isCurrentMember = member.userId == currentUser?.userId
        var showMemberMenu by remember { mutableStateOf(false) }

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, CommBorder, RoundedCornerShape(12.dp)),
          colors = CardDefaults.cardColors(containerColor = CommCardBg)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .weight(1f)
                .clickable {
                  viewModel.openCommunityMemberProfile(member.userId, member.userName, member.userAvatar)
                }
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .background(CommPrimary.copy(alpha = 0.3f), CircleShape)
                  .border(1.dp, CommPrimaryLight, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = member.userName.take(1).uppercase(),
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = member.userName,
                    style = MaterialThemeTypography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  val roleColor = when (member.role) {
                    "OWNER" -> CommGold
                    "ADMIN" -> CommAccent
                    else -> Color.Gray
                  }
                  Box(
                    modifier = Modifier
                      .background(roleColor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = member.role,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = roleColor
                    )
                  }
                }
                val joinedDate = SimpleDateFormat("Joined MMM yyyy", Locale.getDefault()).format(Date(member.joinedAt))
                Text(
                  text = joinedDate,
                  style = MaterialThemeTypography.bodySmall,
                  color = Color.Gray
                )
              }
            }

            // Quick Actions: Direct Chat and Owner Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
              if (!isCurrentMember) {
                IconButton(
                  onClick = {
                    viewModel.openChatWithCommunityMember(
                      targetUserId = member.userId,
                      targetUserName = member.userName,
                      targetAvatar = member.userAvatar,
                      initialContextMessage = "Hi ${member.userName}! Connected from Catchy Community: ${community.name}."
                    )
                  }
                ) {
                  Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = "Message",
                    tint = CommAccent
                  )
                }
              }

              // Owner member management controls
              if (isOwner && !isCurrentMember) {
                Box {
                  IconButton(onClick = { showMemberMenu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Manage Member", tint = Color.Gray)
                  }
                  DropdownMenu(
                    expanded = showMemberMenu,
                    onDismissRequest = { showMemberMenu = false },
                    modifier = Modifier.background(CommCardBg)
                  ) {
                    if (member.role != "ADMIN") {
                      DropdownMenuItem(
                        text = { Text("Promote to Admin", color = CommAccent) },
                        leadingIcon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = CommAccent) },
                        onClick = {
                          showMemberMenu = false
                          viewModel.updateMemberRole(member.userId, "ADMIN")
                        }
                      )
                    } else {
                      DropdownMenuItem(
                        text = { Text("Demote to Member", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = Color.White) },
                        onClick = {
                          showMemberMenu = false
                          viewModel.updateMemberRole(member.userId, "MEMBER")
                        }
                      )
                    }
                    DropdownMenuItem(
                      text = { Text("Remove from Community", color = CommPink) },
                      leadingIcon = { Icon(Icons.Default.PersonRemove, contentDescription = null, tint = CommPink) },
                      onClick = {
                        showMemberMenu = false
                        viewModel.removeCommunityMember(member.userId)
                      }
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// TAB 3: ABOUT & RULES
// =========================================================================
@Composable
private fun CommunityAboutTabView(
  community: CatchyCommunity,
  viewModel: AccountViewModel,
  isOwner: Boolean
) {
  var showDeleteConfirm by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Description Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CommBorder, RoundedCornerShape(14.dp)),
      colors = CardDefaults.cardColors(containerColor = CommCardBg)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "About Community",
          style = MaterialThemeTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = CommAccent
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = community.description,
          style = MaterialThemeTypography.bodyMedium,
          color = Color.White,
          lineHeight = 22.sp
        )
      }
    }

    // Guidelines & Rules Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CommBorder, RoundedCornerShape(14.dp)),
      colors = CardDefaults.cardColors(containerColor = CommCardBg)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Shield, contentDescription = null, tint = CommEmerald, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Community Rules & Safety",
            style = MaterialThemeTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = community.rules,
          style = MaterialThemeTypography.bodyMedium,
          color = Color.LightGray,
          lineHeight = 20.sp
        )
      }
    }

    // Metadata details
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CommBorder, RoundedCornerShape(14.dp)),
      colors = CardDefaults.cardColors(containerColor = CommCardBg)
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Category", color = Color.Gray, fontSize = 13.sp)
          Text(community.category, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        HorizontalDivider(color = CommBorder)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Privacy", color = Color.Gray, fontSize = 13.sp)
          Text(if (community.isPrivate) "Private (Members only)" else "Public (Open to all)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        HorizontalDivider(color = CommBorder)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Creator", color = Color.Gray, fontSize = 13.sp)
          Text(community.creatorName, color = CommPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        HorizontalDivider(color = CommBorder)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          val dateStr = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date(community.createdAt))
          Text("Established", color = Color.Gray, fontSize = 13.sp)
          Text(dateStr, color = Color.White, fontSize = 13.sp)
        }
      }
    }

    // Owner Danger Zone
    if (isOwner) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CommPink.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = CommDarkBg)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Owner Controls",
            style = MaterialThemeTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = CommPink
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "As the creator, you have full administrative ownership. You can edit community details or delete the community permanently.",
            style = MaterialThemeTypography.bodySmall,
            color = Color.Gray
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = { viewModel.showEditCommunityDialog(community) },
              colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Edit Details")
            }
            OutlinedButton(
              onClick = { showDeleteConfirm = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = CommPink),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(CommPink, CommPink)))
            ) {
              Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Delete Community")
            }
          }
        }
      }
    }

    if (showDeleteConfirm) {
      AlertDialog(
        onDismissRequest = { showDeleteConfirm = false },
        containerColor = CommCardBg,
        titleContentColor = Color.White,
        textContentColor = Color.LightGray,
        title = { Text("Delete Community?") },
        text = { Text("Are you sure you want to permanently delete '${community.name}'? All posts and memberships will be erased.") },
        confirmButton = {
          Button(
            onClick = {
              showDeleteConfirm = false
              viewModel.deleteCommunity(community.id)
            },
            colors = ButtonDefaults.buttonColors(containerColor = CommPink)
          ) {
            Text("Confirm Delete", color = Color.White)
          }
        },
        dismissButton = {
          TextButton(onClick = { showDeleteConfirm = false }) {
            Text("Cancel", color = Color.White)
          }
        }
      )
    }
  }
}

// =========================================================================
// DIALOG: CREATE / EDIT COMMUNITY
// =========================================================================
@Composable
private fun CommunityEditorDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val editingCommunity by viewModel.editingCommunity.collectAsState()
  val isSaving by viewModel.isSavingCommunity.collectAsState()
  val formError by viewModel.communityFormError.collectAsState()

  var name by remember(editingCommunity) { mutableStateOf(editingCommunity?.name ?: "") }
  var description by remember(editingCommunity) { mutableStateOf(editingCommunity?.description ?: "") }
  var category by remember(editingCommunity) { mutableStateOf(editingCommunity?.category ?: "Technology & AI") }
  var isPrivate by remember(editingCommunity) { mutableStateOf(editingCommunity?.isPrivate ?: false) }
  var gradientIndex by remember(editingCommunity) { mutableStateOf(editingCommunity?.coverGradientIndex ?: 0) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("community_editor_dialog"),
      color = CommDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
          Text(
            text = if (editingCommunity == null) "Create Community" else "Edit Community",
            style = MaterialThemeTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
          Spacer(modifier = Modifier.width(48.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (formError != null) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CommPink.copy(alpha = 0.2f))
          ) {
            Text(
              text = formError!!,
              color = CommPink,
              style = MaterialThemeTypography.bodySmall,
              modifier = Modifier.padding(12.dp)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
        }

        // Community Name
        Text("Community Name", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          placeholder = { Text("e.g. AI Pioneers Bangladesh, Android Builders...", color = Color.Gray) },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CommCardBg,
            unfocusedContainerColor = CommCardBg,
            focusedBorderColor = CommPrimary,
            unfocusedBorderColor = CommBorder,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          modifier = Modifier.fillMaxWidth().testTag("community_name_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Community Description
        Text("Description & Purpose", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          placeholder = { Text("Describe what members share, learn, and collaborate on...", color = Color.Gray) },
          minLines = 3,
          maxLines = 5,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CommCardBg,
            unfocusedContainerColor = CommCardBg,
            focusedBorderColor = CommPrimary,
            unfocusedBorderColor = CommBorder,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          modifier = Modifier.fillMaxWidth().testTag("community_desc_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Category Selector
        Text("Category", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          CatchyCommunityCategories.ALL.forEach { cat ->
            val isSelected = category == cat
            FilterChip(
              selected = isSelected,
              onClick = { category = cat },
              label = { Text(cat, fontSize = 12.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = CommPrimary,
                selectedLabelColor = Color.White,
                containerColor = CommCardBg,
                labelColor = Color.LightGray
              ),
              border = FilterChipDefaults.filterChipBorder(
                enabled = true,
                selected = isSelected,
                borderColor = if (isSelected) CommPrimary else CommBorder
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cover Gradient Picker
        Text("Banner Style", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          CoverGradients.forEachIndexed { index, grad ->
            val isSelected = gradientIndex == index
            Box(
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(grad)
                .border(if (isSelected) 2.dp else 0.dp, if (isSelected) Color.White else Color.Transparent, RoundedCornerShape(8.dp))
                .clickable { gradientIndex = index },
              contentAlignment = Alignment.Center
            ) {
              if (isSelected) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy Setting
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CommBorder, RoundedCornerShape(12.dp)),
          colors = CardDefaults.cardColors(containerColor = CommCardBg)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isPrivate) "Private Community" else "Public Community",
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = if (isPrivate) "Only approved members can see discussions and posts." else "Anyone can search, discover, and join this community.",
                style = MaterialThemeTypography.bodySmall,
                color = Color.Gray
              )
            }
            Switch(
              checked = isPrivate,
              onCheckedChange = { isPrivate = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = CommPink,
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = CommDarkBg
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Submit Button
        Button(
          onClick = {
            viewModel.saveCommunity(
              name = name,
              description = description,
              photo = "",
              category = category,
              isPrivate = isPrivate,
              coverGradientIndex = gradientIndex
            )
          },
          enabled = !isSaving && name.isNotBlank() && description.isNotBlank(),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("save_community_button"),
          colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
          shape = RoundedCornerShape(12.dp)
        ) {
          if (isSaving) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Text(
              text = if (editingCommunity == null) "Create Community" else "Save Changes",
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = Color.White
            )
          }
        }
      }
    }
  }
}

// =========================================================================
// DIALOG: CREATE / EDIT COMMUNITY POST
// =========================================================================
@Composable
private fun CommunityPostEditorDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val editingPost by viewModel.editingCommunityPost.collectAsState()
  val isSaving by viewModel.isSavingCommunityPost.collectAsState()
  val formError by viewModel.communityPostFormError.collectAsState()

  var content by remember(editingPost) { mutableStateOf(editingPost?.content ?: "") }
  var mediaType by remember(editingPost) { mutableStateOf(editingPost?.mediaType) }
  var mediaLabel by remember(editingPost) { mutableStateOf(editingPost?.mediaLabel) }

  var showPhotoPresets by remember { mutableStateOf(false) }
  var showVideoPresets by remember { mutableStateOf(false) }

  val photoPresets = listOf("Creative Snapshot", "Community Moments", "Infographic & Guide", "Modern Workspace")
  val videoPresets = listOf("Short Video Reel", "Community Showcase", "Video Tutorial", "Behind the Scenes")

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("community_post_editor_dialog"),
      color = CommDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
          Text(
            text = if (editingPost == null) "Create Post" else "Edit Post",
            style = MaterialThemeTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
          Button(
            onClick = {
              viewModel.saveCommunityPost(
                content = content,
                mediaUrl = "",
                mediaType = mediaType,
                mediaLabel = mediaLabel
              )
            },
            enabled = !isSaving && (content.isNotBlank() || mediaType != null),
            colors = ButtonDefaults.buttonColors(containerColor = CommPrimary),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.testTag("publish_community_post_button")
          ) {
            if (isSaving) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
              Text("Publish", fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (formError != null) {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CommPink.copy(alpha = 0.2f))
          ) {
            Text(
              text = formError!!,
              color = CommPink,
              style = MaterialThemeTypography.bodySmall,
              modifier = Modifier.padding(12.dp)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
        }

        // Post Input Area
        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          placeholder = { Text("What's on your mind? Share an insight, question, or story...", color = Color.Gray) },
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .testTag("community_post_content_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CommCardBg,
            unfocusedContainerColor = CommCardBg,
            focusedBorderColor = CommBorder,
            unfocusedBorderColor = CommBorder,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          shape = RoundedCornerShape(14.dp)
        )

        // Attached Media Preview
        if (mediaType != null) {
          Spacer(modifier = Modifier.height(12.dp))
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, CommBorder, RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(
              containerColor = if (mediaType == "video") Color(0xFF1E1026) else Color(0xFF101C26)
            )
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (mediaType == "video") Icons.Default.Videocam else Icons.Default.Image,
                  contentDescription = null,
                  tint = if (mediaType == "video") CommPink else CommAccent
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = mediaLabel ?: "Attached Media",
                    style = MaterialThemeTypography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Text(
                    text = if (mediaType == "video") "Video will be uploaded & attached" else "Photo will be attached",
                    style = MaterialThemeTypography.bodySmall,
                    color = Color.Gray
                  )
                }
              }
              IconButton(onClick = {
                mediaType = null
                mediaLabel = null
              }) {
                Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Gray)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Attachments Toolbar
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CommBorder, RoundedCornerShape(12.dp)),
          colors = CardDefaults.cardColors(containerColor = CommCardBg)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "Add to your post:",
              style = MaterialThemeTypography.bodySmall.copy(fontWeight = FontWeight.Bold),
              color = Color.LightGray
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { showPhotoPresets = true },
                colors = ButtonDefaults.buttonColors(containerColor = CommAccent.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.Image, contentDescription = null, tint = CommAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Photo", color = CommAccent, fontSize = 12.sp)
              }

              Button(
                onClick = { showVideoPresets = true },
                colors = ButtonDefaults.buttonColors(containerColor = CommPink.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.Videocam, contentDescription = null, tint = CommPink, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Video", color = CommPink, fontSize = 12.sp)
              }
            }
          }
        }

        // Preset dialogs
        if (showPhotoPresets) {
          Dialog(onDismissRequest = { showPhotoPresets = false }) {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              colors = CardDefaults.cardColors(containerColor = CommCardBg),
              shape = RoundedCornerShape(16.dp),
              border = CardDefaults.outlinedCardBorder()
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Text(
                  text = "Select Photo Preset",
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp
                )
                for (preset in photoPresets) {
                  Card(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable {
                        mediaType = "photo"
                        mediaLabel = preset
                        showPhotoPresets = false
                      },
                    colors = CardDefaults.cardColors(containerColor = CommDarkBg)
                  ) {
                    Text(
                      text = preset,
                      color = Color.White,
                      modifier = Modifier.padding(12.dp)
                    )
                  }
                }
                TextButton(
                  onClick = { showPhotoPresets = false },
                  modifier = Modifier.align(Alignment.End)
                ) {
                  Text("Cancel", color = Color.White)
                }
              }
            }
          }
        }

        if (showVideoPresets) {
          Dialog(onDismissRequest = { showVideoPresets = false }) {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              colors = CardDefaults.cardColors(containerColor = CommCardBg),
              shape = RoundedCornerShape(16.dp),
              border = CardDefaults.outlinedCardBorder()
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Text(
                  text = "Select Video Preset",
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp
                )
                for (preset in videoPresets) {
                  Card(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable {
                        mediaType = "video"
                        mediaLabel = preset
                        showVideoPresets = false
                      },
                    colors = CardDefaults.cardColors(containerColor = CommDarkBg)
                  ) {
                    Text(
                      text = preset,
                      color = Color.White,
                      modifier = Modifier.padding(12.dp)
                    )
                  }
                }
                TextButton(
                  onClick = { showVideoPresets = false },
                  modifier = Modifier.align(Alignment.End)
                ) {
                  Text("Cancel", color = Color.White)
                }
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// DIALOG: SAFETY REPORT
// =========================================================================
@Composable
private fun CommunityReportDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val reason by viewModel.communityReportReason.collectAsState()
  val reportReasons = listOf(
    "Spam, scams, or misleading advertising",
    "Harassment, hate speech, or abuse",
    "Inappropriate or graphic content",
    "Impersonation or false community identity",
    "Violation of Catchy community safety rules"
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      colors = CardDefaults.cardColors(containerColor = CommCardBg),
      shape = RoundedCornerShape(16.dp),
      border = CardDefaults.outlinedCardBorder()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Flag, contentDescription = null, tint = CommPink)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Report Community Item",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
        }

        Text(
          text = "Please select a reason for reporting to help Catchy moderators:",
          fontSize = 13.sp,
          color = Color.LightGray
        )

        for (r in reportReasons) {
          val isSelected = reason == r
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(
                1.dp,
                if (isSelected) CommPink else CommBorder,
                RoundedCornerShape(8.dp)
              )
              .clickable { viewModel.setCommunityReportReason(r) },
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) CommPink.copy(alpha = 0.2f) else CommDarkBg
            )
          ) {
            Text(
              text = r,
              color = Color.White,
              fontSize = 12.sp,
              modifier = Modifier.padding(10.dp)
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text("Cancel", color = Color.White)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = { viewModel.submitCommunityReport() },
            enabled = reason.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = CommPink),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text("Submit Report", color = Color.White)
          }
        }
      }
    }
  }
}

// Typography alias for consistency
private val MaterialThemeTypography
  @Composable get() = androidx.compose.material3.MaterialTheme.typography
