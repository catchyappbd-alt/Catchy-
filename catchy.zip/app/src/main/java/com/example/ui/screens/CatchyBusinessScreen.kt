package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyBusinessInquiry
import com.example.data.model.CatchyBusinessPage
import com.example.data.model.CatchyBusinessPost
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyBusinessTab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val BusinessDarkBg = Color(0xFF0D0E15)
private val BusinessCardBg = Color(0xFF171924)
private val BusinessBorder = Color(0xFF26293A)
private val BusinessPrimary = Color(0xFFFF2A6D)
private val BusinessCyan = Color(0xFF00E5FF)
private val BusinessGold = Color(0xFFFFD166)
private val BusinessEmerald = Color(0xFF00E676)

@Composable
fun CatchyBusinessDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentTab by viewModel.businessTab.collectAsState()
  val selectedPage by viewModel.selectedBusinessPage.collectAsState()
  val isEditorOpen by viewModel.isPageEditorVisible.collectAsState()
  val editingPage by viewModel.editingPage.collectAsState()
  val inquiryTarget by viewModel.inquiryTargetPage.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("catchy_business_dialog"),
      color = BusinessDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        BusinessHeader(
          onClose = onDismiss,
          onCreatePage = { viewModel.openCreateBusinessPageDialog() }
        )

        // Tab Navigation
        BusinessTabRow(
          currentTab = currentTab,
          onSelectTab = { viewModel.setBusinessTab(it) }
        )

        // Content
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          when (currentTab) {
            CatchyBusinessTab.EXPLORE -> ExploreBusinessesView(viewModel = viewModel)
            CatchyBusinessTab.MY_PAGES -> MyBusinessPagesView(viewModel = viewModel)
            CatchyBusinessTab.INQUIRIES -> BusinessInquiriesView(viewModel = viewModel)
          }
        }
      }

      // Modals
      if (selectedPage != null) {
        BusinessPageDetailsDialog(
          page = selectedPage!!,
          viewModel = viewModel,
          onDismiss = { viewModel.selectBusinessPage(null) }
        )
      }

      if (isEditorOpen) {
        CreateEditBusinessPageDialog(
          existing = editingPage,
          viewModel = viewModel,
          onDismiss = { viewModel.closeBusinessPageEditorDialog() }
        )
      }

      if (inquiryTarget != null) {
        SendBusinessInquiryDialog(
          targetPage = inquiryTarget!!,
          viewModel = viewModel,
          onDismiss = { viewModel.closeSendInquiryDialog() }
        )
      }
    }
  }
}

@Composable
private fun BusinessHeader(
  onClose: () -> Unit,
  onCreatePage: () -> Unit
) {
  Surface(
    color = Color(0xFF13141E),
    tonalElevation = 4.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        IconButton(
          onClick = onClose,
          modifier = Modifier.testTag("business_back_button")
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Back",
            tint = Color.White
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Catchy Business",
              color = Color.White,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.Default.Storefront,
              contentDescription = null,
              tint = BusinessCyan,
              modifier = Modifier.size(18.dp)
            )
          }
          Text(
            text = "Pages • Brands • Enterprises",
            color = Color(0xFF9E9EB8),
            fontSize = 12.sp
          )
        }
      }

      Button(
        onClick = onCreatePage,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = BusinessPrimary,
          contentColor = Color.White
        ),
        modifier = Modifier.testTag("create_business_page_button")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Create Page", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

@Composable
private fun BusinessTabRow(
  currentTab: CatchyBusinessTab,
  onSelectTab: (CatchyBusinessTab) -> Unit
) {
  val tabs = listOf(
    CatchyBusinessTab.EXPLORE to "Explore Pages",
    CatchyBusinessTab.MY_PAGES to "My Pages",
    CatchyBusinessTab.INQUIRIES to "Customer Inquiries"
  )
  val selectedIndex = tabs.indexOfFirst { it.first == currentTab }

  TabRow(
    selectedTabIndex = if (selectedIndex >= 0) selectedIndex else 0,
    containerColor = Color(0xFF13141E),
    contentColor = Color.White,
    indicator = { tabPositions ->
      if (selectedIndex in tabPositions.indices) {
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
          color = BusinessCyan,
          height = 3.dp
        )
      }
    }
  ) {
    tabs.forEachIndexed { _, (tab, label) ->
      val isSelected = tab == currentTab
      Tab(
        selected = isSelected,
        onClick = { onSelectTab(tab) },
        text = {
          Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) BusinessCyan else Color(0xFF9E9EB8)
          )
        }
      )
    }
  }
}

// -------------------------------------------------------------
// TAB 1: EXPLORE BUSINESS PAGES
// -------------------------------------------------------------
@Composable
private fun ExploreBusinessesView(viewModel: AccountViewModel) {
  val searchQuery by viewModel.businessSearchQuery.collectAsState()
  val selectedCategory by viewModel.selectedBusinessCategory.collectAsState()
  val pages by viewModel.filteredBusinessPages.collectAsState()

  val categories = listOf(
    "All",
    "Technology & Software",
    "Retail & E-commerce",
    "Food & Restaurant",
    "Media & Agency",
    "Education & Training",
    "Healthcare",
    "Consulting & Services",
    "Creative & Design",
    "Other"
  )

  Column(modifier = Modifier.fillMaxSize()) {
    // Search
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { viewModel.setBusinessSearchQuery(it) },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("business_search_input"),
      placeholder = { Text("Search businesses, brands, handles, categories...", color = Color.Gray, fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { viewModel.setBusinessSearchQuery("") }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = BusinessCardBg,
        unfocusedContainerColor = BusinessCardBg,
        focusedBorderColor = BusinessCyan,
        unfocusedBorderColor = BusinessBorder,
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      )
    )

    // Category Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      categories.forEach { cat ->
        val selected = cat == selectedCategory
        FilterChip(
          selected = selected,
          onClick = { viewModel.setSelectedBusinessCategory(cat) },
          label = { Text(cat, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = BusinessCyan.copy(alpha = 0.2f),
            selectedLabelColor = BusinessCyan,
            containerColor = BusinessCardBg,
            labelColor = Color(0xFFCCCED9)
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = BusinessBorder,
            selectedBorderColor = BusinessCyan
          )
        )
      }
    }

    if (pages.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Storefront,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(56.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "No Business Pages Found",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Create your brand page today or try a different search filter.",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = { viewModel.openCreateBusinessPageDialog() },
            colors = ButtonDefaults.buttonColors(containerColor = BusinessPrimary)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Create First Page", fontWeight = FontWeight.SemiBold)
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(pages, key = { it.pageId }) { page ->
          BusinessPageCard(
            page = page,
            onClick = { viewModel.selectBusinessPage(page) },
            onFollowToggle = { viewModel.toggleFollowPage(page.pageId) }
          )
        }
      }
    }
  }
}

@Composable
private fun BusinessPageCard(
  page: CatchyBusinessPage,
  onClick: () -> Unit,
  onFollowToggle: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, BusinessBorder, RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("business_card_${page.pageId}"),
    colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Avatar placeholder
      Box(
        modifier = Modifier
          .size(52.dp)
          .clip(CircleShape)
          .background(Color(0xFF222536))
          .border(1.dp, BusinessCyan.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = page.name.take(1).uppercase(),
          color = BusinessCyan,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 22.sp
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = page.name,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          if (page.isVerified) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.Verified,
              contentDescription = "Verified",
              tint = BusinessCyan,
              modifier = Modifier.size(16.dp)
            )
          }
        }

        Text(
          text = page.handle,
          color = BusinessCyan,
          fontSize = 12.sp
        )

        if (page.tagline.isNotBlank()) {
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = page.tagline,
            color = Color(0xFFB4B7C5),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = page.category,
            color = BusinessGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "•",
            color = Color.Gray,
            fontSize = 11.sp
          )
          Text(
            text = "${page.followersCount} followers",
            color = Color(0xFFCCCED9),
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      OutlinedButton(
        onClick = onFollowToggle,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.outlinedButtonColors(
          contentColor = Color.White
        ),
        modifier = Modifier.testTag("follow_page_btn_${page.pageId}")
      ) {
        Text("View", fontSize = 12.sp)
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 2: MY BUSINESS PAGES
// -------------------------------------------------------------
@Composable
private fun MyBusinessPagesView(viewModel: AccountViewModel) {
  val myPages by viewModel.myBusinessPages.collectAsState()

  if (myPages.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          imageVector = Icons.Default.Business,
          contentDescription = null,
          tint = Color.Gray,
          modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "You don't have any Business Pages yet",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Create a verified business page to build an audience, post updates, and receive customer leads on Catchy.",
          color = Color.Gray,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
          onClick = { viewModel.openCreateBusinessPageDialog() },
          colors = ButtonDefaults.buttonColors(containerColor = BusinessPrimary)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Create Business Page", fontWeight = FontWeight.SemiBold)
        }
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(myPages, key = { it.pageId }) { page ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BusinessBorder, RoundedCornerShape(16.dp))
            .clickable { viewModel.selectBusinessPage(page) },
          colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = page.name,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified",
                    tint = BusinessCyan,
                    modifier = Modifier.size(16.dp)
                  )
                }
                Text(
                  text = page.handle,
                  color = BusinessCyan,
                  fontSize = 12.sp
                )
                if (page.tagline.isNotBlank()) {
                  Text(
                    text = page.tagline,
                    color = Color.Gray,
                    fontSize = 12.sp
                  )
                }
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(BusinessEmerald.copy(alpha = 0.15f))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "${page.followersCount} Followers",
                  color = BusinessEmerald,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedButton(
                onClick = { viewModel.selectBusinessPage(page) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(end = 8.dp)
              ) {
                Text("View & Post", color = Color.White, fontSize = 12.sp)
              }

              OutlinedButton(
                onClick = { viewModel.openEditBusinessPageDialog(page) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(end = 8.dp)
              ) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Edit", color = Color.White, fontSize = 12.sp)
              }

              IconButton(
                onClick = { viewModel.deleteBusinessPage(page.pageId) }
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252))
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 3: CUSTOMER INQUIRIES & LEADS
// -------------------------------------------------------------
@Composable
private fun BusinessInquiriesView(viewModel: AccountViewModel) {
  val inquiries by viewModel.myReceivedInquiries.collectAsState()

  if (inquiries.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          imageVector = Icons.Default.Mail,
          contentDescription = null,
          tint = Color.Gray,
          modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "No Customer Inquiries Yet",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "When visitors send an inquiry to your business pages, they will appear here.",
          color = Color.Gray,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(inquiries, key = { it.inquiryId }) { inq ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, BusinessBorder, RoundedCornerShape(14.dp)),
          colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = inq.pageName,
                  color = BusinessCyan,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                Text(
                  text = "From: ${inq.senderName} (${inq.senderEmail})",
                  color = Color.White,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (inq.status == "NEW") BusinessPrimary.copy(alpha = 0.2f) else Color(0xFF222536))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = inq.status,
                  color = if (inq.status == "NEW") BusinessPrimary else Color(0xFFCCCED9),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Subject: ${inq.subject}",
              color = BusinessGold,
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = inq.message,
              color = Color(0xFFCCCED9),
              fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Button(
                onClick = {
                  viewModel.messageBusinessContact(
                    targetUserId = inq.senderUserId,
                    targetUserName = inq.senderName,
                    initialContextMessage = "Hi ${inq.senderName}, replying regarding your inquiry about ${inq.subject} for ${inq.pageName}..."
                  )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Chat", fontSize = 12.sp, color = Color.White)
              }

              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (inq.status != "REPLIED") {
                  Button(
                    onClick = { viewModel.updateInquiryStatus(inq.inquiryId, "REPLIED") },
                    colors = ButtonDefaults.buttonColors(containerColor = BusinessEmerald),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Text("Mark Replied", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                  }
                }
                IconButton(onClick = { viewModel.deleteInquiry(inq.inquiryId) }) {
                  Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 1: BUSINESS PAGE DETAILS & FEED
// -------------------------------------------------------------
@Composable
private fun BusinessPageDetailsDialog(
  page: CatchyBusinessPage,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val isOwner = currentUser?.userId == page.ownerUserId
  val isFollowing by viewModel.isFollowingSelectedPage.collectAsState()
  val posts by viewModel.pagePosts.collectAsState()

  var newPostText by remember { mutableStateOf("") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("business_details_dialog"),
      color = BusinessDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // App Bar
        Surface(color = Color(0xFF141520)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text(page.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (!isOwner) {
              Button(
                onClick = { viewModel.openSendInquiryDialog(page) },
                colors = ButtonDefaults.buttonColors(containerColor = BusinessCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(16.dp)
              ) {
                Text("Inquire", fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
            }
          }
        }

        // Body
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          // Hero Page Profile Header
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .border(1.dp, BusinessBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF25283B))
                    .border(2.dp, BusinessCyan, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Text(page.name.take(1).uppercase(), color = BusinessCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(page.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    if (page.isVerified) {
                      Spacer(modifier = Modifier.width(4.dp))
                      Icon(Icons.Default.Verified, contentDescription = "Verified", tint = BusinessCyan, modifier = Modifier.size(18.dp))
                    }
                  }
                  Text(page.handle, color = BusinessCyan, fontSize = 13.sp)
                  Text("${page.followersCount} Followers • ${page.category}", color = Color.Gray, fontSize = 12.sp)
                }
              }

              if (page.tagline.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(page.tagline, color = Color(0xFFCCCED9), fontSize = 13.sp)
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Action buttons
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                if (!isOwner) {
                  Button(
                    onClick = { viewModel.toggleFollowPage(page.pageId) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                      containerColor = if (isFollowing) Color(0xFF282A3A) else BusinessPrimary,
                      contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                  ) {
                    Text(if (isFollowing) "Following" else "Follow Page", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  }

                  Button(
                    onClick = {
                      onDismiss()
                      viewModel.messageBusinessContact(
                        targetUserId = page.ownerUserId,
                        targetUserName = "${page.name} Support",
                        initialContextMessage = "Hi, I have a customer inquiry about ${page.name}."
                      )
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
                    modifier = Modifier.weight(1f)
                  ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Direct Chat", color = Color.White, fontSize = 13.sp)
                  }
                } else {
                  Button(
                    onClick = { viewModel.openEditBusinessPageDialog(page) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Page Information", color = Color.White, fontSize = 13.sp)
                  }
                }
              }
            }
          }

          // About / Description
          if (page.description.isNotBlank()) {
            Column {
              Text("About", color = BusinessGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(page.description, color = Color(0xFFD6D8E4), fontSize = 13.sp, lineHeight = 18.sp)
            }
          }

          // Business Details Card (Contact info)
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .border(1.dp, BusinessBorder, RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text("Contact & Operations", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              if (page.email.isNotBlank()) {
                InfoIconRow(icon = Icons.Default.Email, text = page.email)
              }
              if (page.phone.isNotBlank()) {
                InfoIconRow(icon = Icons.Default.Phone, text = page.phone)
              }
              if (page.website.isNotBlank()) {
                InfoIconRow(icon = Icons.Default.Language, text = page.website)
              }
              if (page.location.isNotBlank()) {
                InfoIconRow(icon = Icons.Default.LocationOn, text = page.location)
              }
              if (page.operatingHours.isNotBlank()) {
                InfoIconRow(icon = Icons.Default.Schedule, text = page.operatingHours)
              }
            }
          }

          // Posts & Updates Section
          Text("Updates & Announcements", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)

          // Owner Create Post Box
          if (isOwner) {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, BusinessBorder, RoundedCornerShape(12.dp)),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF191B28))
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                OutlinedTextField(
                  value = newPostText,
                  onValueChange = { newPostText = it },
                  placeholder = { Text("Publish an announcement or offer to your followers...", color = Color.Gray, fontSize = 13.sp) },
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(10.dp),
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = BusinessCardBg,
                    unfocusedContainerColor = BusinessCardBg,
                    focusedBorderColor = BusinessCyan,
                    unfocusedBorderColor = BusinessBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                  )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                  Button(
                    onClick = {
                      if (newPostText.isNotBlank()) {
                        viewModel.createBusinessPost(page.pageId, newPostText)
                        newPostText = ""
                      }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BusinessCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Publish Update", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  }
                }
              }
            }
          }

          if (posts.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("No updates posted yet.", color = Color.Gray, fontSize = 13.sp)
            }
          } else {
            posts.forEach { post ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, BusinessBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = BusinessCardBg)
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date(post.createdAt)),
                      color = Color.Gray,
                      fontSize = 11.sp
                    )
                    if (isOwner) {
                      IconButton(onClick = { viewModel.deleteBusinessPost(page.pageId, post.postId) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                      }
                    }
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(post.content, color = Color.White, fontSize = 13.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 2: CREATE / EDIT BUSINESS PAGE DIALOG
// -------------------------------------------------------------
@Composable
private fun CreateEditBusinessPageDialog(
  existing: CatchyBusinessPage?,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  var name by remember { mutableStateOf(existing?.name ?: "") }
  var handle by remember { mutableStateOf(existing?.handle ?: "") }
  var category by remember { mutableStateOf(existing?.category ?: "Technology & Software") }
  var tagline by remember { mutableStateOf(existing?.tagline ?: "") }
  var description by remember { mutableStateOf(existing?.description ?: "") }
  var email by remember { mutableStateOf(existing?.email ?: "") }
  var phone by remember { mutableStateOf(existing?.phone ?: "") }
  var website by remember { mutableStateOf(existing?.website ?: "") }
  var location by remember { mutableStateOf(existing?.location ?: "Dhaka, Bangladesh") }
  var operatingHours by remember { mutableStateOf(existing?.operatingHours ?: "9:00 AM - 6:00 PM (Sun - Thu)") }

  val isSaving by viewModel.isSavingBusinessPage.collectAsState()
  val formError by viewModel.businessFormError.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("create_edit_page_dialog"),
      color = BusinessDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (existing != null) "Edit Business Page" else "Create Business Page",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        if (formError != null) {
          Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3E1E28))) {
            Text(formError!!, color = Color(0xFFFF8080), fontSize = 12.sp, modifier = Modifier.padding(10.dp))
          }
        }

        BusinessTextField(value = name, onValueChange = { name = it }, label = "Business / Brand Name *")
        BusinessTextField(value = handle, onValueChange = { handle = it }, label = "Handle / Username (e.g. @techspire)")
        BusinessTextField(value = category, onValueChange = { category = it }, label = "Category (Technology, Retail, Food, Services...) *")
        BusinessTextField(value = tagline, onValueChange = { tagline = it }, label = "One-line Tagline")
        BusinessTextField(value = description, onValueChange = { description = it }, label = "About / Description", singleLine = false)
        BusinessTextField(value = email, onValueChange = { email = it }, label = "Business Email", keyboardType = KeyboardType.Email)
        BusinessTextField(value = phone, onValueChange = { phone = it }, label = "Phone / WhatsApp", keyboardType = KeyboardType.Phone)
        BusinessTextField(value = website, onValueChange = { website = it }, label = "Website URL")
        BusinessTextField(value = location, onValueChange = { location = it }, label = "Address / City")
        BusinessTextField(value = operatingHours, onValueChange = { operatingHours = it }, label = "Operating Hours")

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = {
            if (name.isNotBlank()) {
              viewModel.saveBusinessPage(
                name = name,
                handle = handle,
                category = category,
                tagline = tagline,
                description = description,
                email = email,
                phone = phone,
                website = website,
                location = location,
                operatingHours = operatingHours
              )
            }
          },
          enabled = !isSaving && name.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = BusinessPrimary),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("save_business_page_btn")
        ) {
          if (isSaving) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
          } else {
            Text(if (existing != null) "Save Changes" else "Publish Business Page", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 3: SEND BUSINESS INQUIRY DIALOG
// -------------------------------------------------------------
@Composable
private fun SendBusinessInquiryDialog(
  targetPage: CatchyBusinessPage,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  var subject by remember { mutableStateOf("") }
  var message by remember { mutableStateOf("") }
  val feedbackMessage by viewModel.businessFeedbackMessage.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("send_inquiry_dialog"),
      color = BusinessDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Send Business Inquiry", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("To: ${targetPage.name}", color = BusinessCyan, fontSize = 13.sp)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        if (feedbackMessage != null) {
          Card(
            colors = CardDefaults.cardColors(
              containerColor = if (feedbackMessage!!.contains("success", ignoreCase = true)) Color(0xFF1B382B) else Color(0xFF3E1E28)
            )
          ) {
            Text(feedbackMessage!!, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
          }
        }

        Text(
          text = "Submit a direct lead, product inquiry, or proposal. The page administrators will receive your inquiry and contact information.",
          color = Color(0xFFCCCED9),
          fontSize = 13.sp
        )

        BusinessTextField(value = subject, onValueChange = { subject = it }, label = "Inquiry Subject / Purpose *")
        BusinessTextField(value = message, onValueChange = { message = it }, label = "Message / Details *", singleLine = false)

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = {
            if (subject.isNotBlank() && message.isNotBlank()) {
              viewModel.submitBusinessInquiry(subject, message)
            }
          },
          enabled = subject.isNotBlank() && message.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = BusinessCyan, contentColor = Color.Black),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("submit_inquiry_btn")
        ) {
          Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Send Inquiry", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }
    }
  }
}

// -------------------------------------------------------------
// HELPER COMPONENTS
// -------------------------------------------------------------
@Composable
private fun InfoIconRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(icon, contentDescription = null, tint = BusinessCyan, modifier = Modifier.size(16.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(text, color = Color(0xFFCCCED9), fontSize = 13.sp)
  }
}

@Composable
private fun BusinessTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  singleLine: Boolean = true,
  keyboardType: KeyboardType = KeyboardType.Text
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label, color = Color.Gray, fontSize = 12.sp) },
    singleLine = singleLine,
    keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedContainerColor = BusinessCardBg,
      unfocusedContainerColor = BusinessCardBg,
      focusedBorderColor = BusinessCyan,
      unfocusedBorderColor = BusinessBorder,
      focusedTextColor = Color.White,
      unfocusedTextColor = Color.White
    )
  )
}
