package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CatchyBrandHeader
import com.example.ui.components.CatchyButton
import com.example.ui.components.CatchyPasswordField
import com.example.ui.components.CatchySelectDropdown
import com.example.ui.components.CatchyTextField
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchyViolet
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyScreen

@Composable
fun SignUpScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val signUpState by viewModel.signUpState.collectAsState()
  val scrollState = rememberScrollState()

  val genderOptions = listOf("Male", "Female", "Non-Binary", "Prefer not to say")
  val educationOptions = listOf("Student", "Undergraduate", "Graduate", "High School", "Non-Student")
  val occupationOptions = listOf("Employed", "Self-Employed", "Freelancer", "Job Seeker", "Other")
  val maritalOptions = listOf("Single", "Married", "In a Relationship", "Prefer not to say")

  // Avatar presets for easy selection
  val avatarPresets = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      CatchyBrandHeader(
        title = stringResource(R.string.signup_title),
        subtitle = stringResource(R.string.signup_subtitle)
      )

      Spacer(modifier = Modifier.height(24.dp))

      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {

          // Profile Photo Selector (Optional during registration)
          Text(
            text = "Profile Photo (Optional)",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            avatarPresets.forEachIndexed { index, avatarId ->
              val isSelected = signUpState.profilePhotoUri == avatarId
              val bgColors = when (index) {
                0 -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
                1 -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
                2 -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
                else -> listOf(Color(0xFF10B981), Color(0xFF059669))
              }

              Box(
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Brush.linearGradient(bgColors))
                  .border(
                    width = if (isSelected) 3.dp else 1.dp,
                    color = if (isSelected) CatchyCyan else Color.Transparent,
                    shape = CircleShape
                  )
                  .clickable {
                    viewModel.updateSignUpField {
                      it.copy(profilePhotoUri = if (isSelected) null else avatarId)
                    }
                  }
                  .testTag("avatar_preset_$index"),
                contentAlignment = Alignment.Center
              ) {
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected Avatar",
                    tint = Color.White
                  )
                } else {
                  Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Avatar $index",
                    tint = Color.White.copy(alpha = 0.85f)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Full Name
          CatchyTextField(
            value = signUpState.fullName,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(fullName = value) } },
            label = stringResource(R.string.full_name_label),
            placeholder = "e.g. Rahim Ahmed",
            leadingIcon = Icons.Default.Person,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            testTag = "signup_fullname_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Email Address
          CatchyTextField(
            value = signUpState.email,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(email = value) } },
            label = stringResource(R.string.email_label),
            placeholder = "e.g. rahim@gmail.com",
            leadingIcon = Icons.Default.Email,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            testTag = "signup_email_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Date of Birth
          CatchyTextField(
            value = signUpState.dateOfBirth,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(dateOfBirth = value) } },
            label = stringResource(R.string.dob_label),
            placeholder = "YYYY-MM-DD (e.g. 1998-05-14)",
            leadingIcon = Icons.Default.CalendarMonth,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            testTag = "signup_dob_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Gender Selector
          CatchySelectDropdown(
            selectedOption = signUpState.gender,
            options = genderOptions,
            onOptionSelected = { value -> viewModel.updateSignUpField { it.copy(gender = value) } },
            label = stringResource(R.string.gender_label),
            testTag = "signup_gender_dropdown"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Address / Location
          CatchyTextField(
            value = signUpState.addressLocation,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(addressLocation = value) } },
            label = stringResource(R.string.address_label),
            placeholder = "City, Country (e.g. Dhaka, Bangladesh)",
            leadingIcon = Icons.Default.Home,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            testTag = "signup_address_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Student / Education Status
          CatchySelectDropdown(
            selectedOption = signUpState.educationStatus,
            options = educationOptions,
            onOptionSelected = { value -> viewModel.updateSignUpField { it.copy(educationStatus = value) } },
            label = stringResource(R.string.education_status_label),
            testTag = "signup_education_dropdown"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Occupation / Job Status
          CatchySelectDropdown(
            selectedOption = signUpState.occupationStatus,
            options = occupationOptions,
            onOptionSelected = { value -> viewModel.updateSignUpField { it.copy(occupationStatus = value) } },
            label = stringResource(R.string.occupation_status_label),
            testTag = "signup_occupation_dropdown"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Skills
          CatchyTextField(
            value = signUpState.skills,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(skills = value) } },
            label = stringResource(R.string.skills_label),
            placeholder = "e.g. Kotlin, Compose, Photography, Design",
            leadingIcon = Icons.Default.Work,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            testTag = "signup_skills_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Marital Status
          CatchySelectDropdown(
            selectedOption = signUpState.maritalStatus,
            options = maritalOptions,
            onOptionSelected = { value -> viewModel.updateSignUpField { it.copy(maritalStatus = value) } },
            label = stringResource(R.string.marital_status_label),
            testTag = "signup_marital_dropdown"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Password
          CatchyPasswordField(
            value = signUpState.password,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(password = value) } },
            label = stringResource(R.string.password_label),
            placeholder = "At least 6 characters",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
            testTag = "signup_password_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Confirm Password
          CatchyPasswordField(
            value = signUpState.confirmPassword,
            onValueChange = { value -> viewModel.updateSignUpField { it.copy(confirmPassword = value) } },
            label = stringResource(R.string.confirm_password_label),
            placeholder = "Re-enter password",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            testTag = "signup_confirm_password_input"
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Terms & Privacy Checkbox
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                viewModel.updateSignUpField { it.copy(termsAccepted = !it.termsAccepted) }
              }
              .testTag("signup_terms_checkbox")
          ) {
            Checkbox(
              checked = signUpState.termsAccepted,
              onCheckedChange = { checked ->
                viewModel.updateSignUpField { it.copy(termsAccepted = checked) }
              },
              colors = CheckboxDefaults.colors(
                checkedColor = CatchyIndigo,
                checkmarkColor = Color.White
              )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.terms_agreement),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          // Error banner
          if (!signUpState.errorMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(14.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.error.copy(alpha = 0.15f))
                .padding(12.dp)
            ) {
              Text(
                text = signUpState.errorMessage ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Create Account Button
          CatchyButton(
            text = stringResource(R.string.create_account_button),
            onClick = { viewModel.signUp() },
            isLoading = signUpState.isLoading,
            testTag = "signup_submit_button"
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Switch back to Login
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = stringResource(R.string.already_have_account),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(
          onClick = { viewModel.navigateTo(CatchyScreen.LOGIN) },
          modifier = Modifier.testTag("navigate_login_button")
        ) {
          Text(
            text = stringResource(R.string.sign_in_button),
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.3.sp
            ),
            color = CatchyIndigoLight
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
