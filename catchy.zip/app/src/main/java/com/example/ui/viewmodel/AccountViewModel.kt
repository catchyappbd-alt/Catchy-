package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CatchyDatabase
import com.example.data.model.BlockedUser
import com.example.data.model.CatchyBusinessInquiry
import com.example.data.model.CatchyBusinessPage
import com.example.data.model.CatchyBusinessPageFollow
import com.example.data.model.CatchyBusinessPost
import com.example.data.model.CatchyCommunity
import com.example.data.model.CatchyCommunityGuidelines
import com.example.data.model.CatchyCommunityMember
import com.example.data.model.CatchyCommunityPost
import com.example.data.model.CatchyCommunityPostComment
import com.example.data.model.CatchyCommunityPostLike
import com.example.data.model.CatchyCommunityReport
import com.example.data.model.CatchyCommunityTab
import com.example.data.model.CommunityDetailTab
import com.example.data.model.CatchyDirectMessage
import com.example.data.model.CatchyEmployerProfile
import com.example.data.model.CatchyFounderProfile
import com.example.data.model.CatchyGoUploadedVideo
import com.example.data.model.CatchyGoVideo
import com.example.data.storage.UploadProgress
import com.example.data.model.CatchyHelpAnswer
import com.example.data.model.CatchyHelpArticles
import com.example.data.model.CatchyHelpCategories
import com.example.data.model.CatchyHelpPost
import com.example.data.model.CatchyInvestmentOpportunity
import com.example.data.model.CatchyInvestmentRequest
import com.example.data.model.CatchyInvestorProfile
import com.example.data.model.CatchyJobApplication
import com.example.data.model.CatchyJobPosting
import com.example.data.model.CatchyJobSeekerProfile
import com.example.data.model.CatchyPost
import com.example.data.model.CatchyPostComment
import com.example.data.model.CatchyStory
import com.example.data.model.HelpCategory
import com.example.data.model.HelpCenterArticle
import com.example.data.model.HelpPostReport
import com.example.data.model.SavedHelpPost
import com.example.data.model.SupportTicket
import com.example.data.model.TrendingTopic
import com.example.data.model.UserAccount
import com.example.data.repository.AccountRepository
import com.example.data.repository.AuthResult
import com.example.data.repository.PasswordResetDispatch
import com.example.data.repository.VerificationDispatch
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HelpCenterTab {
  COMMUNITY_FEED,
  MY_HELP,
  SAVED,
  CATEGORIES,
  NEARBY,
  SUPPORT_TICKETS,
  ARTICLES,
  GUIDELINES
}

data class HelpFilterCriteria(
  val query: String,
  val category: String,
  val status: String,
  val sortOrder: String,
  val blockedUserIds: Set<String>
)

enum class CatchyScreen {
  LOGIN,
  SIGN_UP,
  FORGOT_PASSWORD,
  RESET_PASSWORD,
  ACCOUNT_IDENTITY
}

enum class CatchyNavTab {
  HOME,
  CHAT,
  REELS,
  PROFILE
}

enum class CatchyJobsTab {
  EXPLORE,
  APPLICATIONS,
  MY_POSTINGS,
  PROFILES
}

enum class CatchyInvestmentTab {
  EXPLORE,
  MY_VENTURES,
  REQUESTS,
  PROFILES
}

enum class CatchyBusinessTab {
  EXPLORE,
  MY_PAGES,
  INQUIRIES
}

data class LoginUiState(
  val identifier: String = "",
  val password: String = "",
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val infoMessage: String? = null
)

data class SignUpUiState(
  val fullName: String = "",
  val email: String = "",
  val dateOfBirth: String = "",
  val gender: String = "Prefer not to say",
  val addressLocation: String = "",
  val educationStatus: String = "Student",
  val occupationStatus: String = "Employed",
  val skills: String = "",
  val maritalStatus: String = "Single",
  val password: String = "",
  val confirmPassword: String = "",
  val profilePhotoUri: String? = null,
  val termsAccepted: Boolean = false,
  val isLoading: Boolean = false,
  val errorMessage: String? = null
)

data class ForgotPasswordUiState(
  val email: String = "",
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val dispatch: PasswordResetDispatch? = null
)

data class ResetPasswordUiState(
  val token: String = "",
  val newPassword: String = "",
  val confirmPassword: String = "",
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val isCompleted: Boolean = false
)

data class CatchyNotificationItem(
  val id: String,
  val title: String,
  val message: String,
  val timestamp: Long,
  val type: String, // "welcome", "post", "social", "help"
  val isRead: Boolean = false
)

// --- Publishing UI State Machine for Catchy Go ---
sealed class PublishUiState {
  object Idle : PublishUiState()
  object Publishing : PublishUiState()
  data class Success(val video: CatchyGoUploadedVideo) : PublishUiState()
  data class Error(val message: String) : PublishUiState()
}

class AccountViewModel @JvmOverloads constructor(
  application: Application,
  customRepository: AccountRepository? = null
) : AndroidViewModel(application) {

  private val repository: AccountRepository = customRepository ?: run {
    val db = CatchyDatabase.getInstance(application)
    AccountRepository(db.userDao(), db.socialDao())
  }

  private val _currentScreen = MutableStateFlow(CatchyScreen.ACCOUNT_IDENTITY)
  val currentScreen = _currentScreen.asStateFlow()

  val currentUser: StateFlow<UserAccount?> = repository.currentUser

  val latestVerificationDispatch: StateFlow<VerificationDispatch?> =
    repository.latestVerificationDispatch

  val latestPasswordResetDispatch: StateFlow<PasswordResetDispatch?> =
    repository.latestPasswordResetDispatch

  private val _loginState = MutableStateFlow(LoginUiState())
  val loginState = _loginState.asStateFlow()

  private val _signUpState = MutableStateFlow(SignUpUiState())
  val signUpState = _signUpState.asStateFlow()

  private val _forgotPasswordState = MutableStateFlow(ForgotPasswordUiState())
  val forgotPasswordState = _forgotPasswordState.asStateFlow()

  private val _resetPasswordState = MutableStateFlow(ResetPasswordUiState())
  val resetPasswordState = _resetPasswordState.asStateFlow()

  // --- Bottom Navigation (Strictly 4 items: Home, Chat, Reels, Profile) ---
  private val _currentTab = MutableStateFlow(CatchyNavTab.HOME)
  val currentTab = _currentTab.asStateFlow()

  fun selectTab(tab: CatchyNavTab) {
    _currentTab.value = tab
    _viewingOtherUser.value = null
    _activeChatUser.value = null
  }

  // --- Search state ---
  private val _homeSearchQuery = MutableStateFlow("")
  val homeSearchQuery = _homeSearchQuery.asStateFlow()

  fun onHomeSearchQueryChange(query: String) {
    _homeSearchQuery.value = query
  }

  fun clearHomeSearchQuery() {
    _homeSearchQuery.value = ""
  }

  // --- Header Notifications Modal ---
  private val _notifications = MutableStateFlow<List<CatchyNotificationItem>>(emptyList())
  val notifications = _notifications.asStateFlow()

  private val _showNotificationsSheet = MutableStateFlow(false)
  val showNotificationsSheet = _showNotificationsSheet.asStateFlow()

  fun openNotifications() {
    _showNotificationsSheet.value = true
  }

  fun closeNotifications() {
    _showNotificationsSheet.value = false
  }

  fun markAllNotificationsRead() {
    _notifications.value = _notifications.value.map { it.copy(isRead = true) }
  }

  // --- Header Menu Sheet ---
  private val _showCatchyMenuSheet = MutableStateFlow(false)
  val showCatchyMenuSheet = _showCatchyMenuSheet.asStateFlow()

  fun openCatchyMenu() {
    _showCatchyMenuSheet.value = true
  }

  fun closeCatchyMenu() {
    _showCatchyMenuSheet.value = false
  }

  // --- Help Dialog / Help Center State ---
  private val _showHelpDialog = MutableStateFlow(false)
  val showHelpDialog = _showHelpDialog.asStateFlow()

  private val _showHelpCenter = MutableStateFlow(false)
  val showHelpCenter = _showHelpCenter.asStateFlow()

  fun openHelpCenter(tab: HelpCenterTab = HelpCenterTab.COMMUNITY_FEED) {
    _helpCenterTab.value = tab
    _showHelpCenter.value = true
    _showHelpDialog.value = true
  }

  fun closeHelpCenter() {
    _showHelpCenter.value = false
    _showHelpDialog.value = false
  }

  fun openHelpDialog() {
    openHelpCenter(HelpCenterTab.COMMUNITY_FEED)
  }

  fun closeHelpDialog() {
    closeHelpCenter()
  }

  // --- Multi-User Profile Viewing ---
  private val _viewingOtherUser = MutableStateFlow<UserAccount?>(null)
  val viewingOtherUser = _viewingOtherUser.asStateFlow()

  fun openUserProfile(user: UserAccount) {
    _viewingOtherUser.value = user
    _activeChatUser.value = null
  }

  fun closeUserProfile() {
    _viewingOtherUser.value = null
  }

  // --- Chat & Messaging ---
  private val _activeChatUser = MutableStateFlow<UserAccount?>(null)
  val activeChatUser = _activeChatUser.asStateFlow()

  private val _activeConversationId = MutableStateFlow<String?>(null)
  val activeConversationId = _activeConversationId.asStateFlow()

  private val _chatMessageInput = MutableStateFlow("")
  val chatMessageInput = _chatMessageInput.asStateFlow()

  private val _replyMessage = MutableStateFlow<CatchyDirectMessage?>(null)
  val replyMessage = _replyMessage.asStateFlow()

  fun setReplyMessage(msg: CatchyDirectMessage?) {
    _replyMessage.value = msg
  }

  fun clearReplyMessage() {
    _replyMessage.value = null
  }

  private val _chatSearchQuery = MutableStateFlow("")
  val chatSearchQuery = _chatSearchQuery.asStateFlow()

  fun onChatSearchQueryChange(query: String) {
    _chatSearchQuery.value = query
  }

  fun clearChatSearchQuery() {
    _chatSearchQuery.value = ""
  }

  private val _activeCallType = MutableStateFlow<String?>(null) // "audio", "video", or null
  val activeCallType = _activeCallType.asStateFlow()

  fun startCall(type: String) {
    _activeCallType.value = type
  }

  fun endCall() {
    _activeCallType.value = null
  }

  private val _isRecordingVoice = MutableStateFlow(false)
  val isRecordingVoice = _isRecordingVoice.asStateFlow()

  fun startVoiceRecording() {
    _isRecordingVoice.value = true
  }

  fun cancelVoiceRecording() {
    _isRecordingVoice.value = false
  }

  @OptIn(ExperimentalCoroutinesApi::class)
  val activeChatMessages: StateFlow<List<CatchyDirectMessage>> = _activeConversationId
    .flatMapLatest { convId ->
      if (convId != null) repository.observeMessages(convId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val userConversations = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeConversations(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  fun openChatWithUser(otherUser: UserAccount): kotlinx.coroutines.Job {
    _viewingOtherUser.value = null
    return viewModelScope.launch {
      val conv = repository.getOrCreateConversation(otherUser.userId)
      _activeConversationId.value = conv?.conversationId
      _activeChatUser.value = otherUser
      _currentTab.value = CatchyNavTab.CHAT
      conv?.conversationId?.let { repository.markConversationSeen(it) }
    }
  }

  fun closeChat() {
    _activeChatUser.value = null
    _activeConversationId.value = null
    _replyMessage.value = null
    _chatMessageInput.value = ""
    _isRecordingVoice.value = false
    _activeCallType.value = null
  }

  fun onChatMessageInputChange(text: String) {
    _chatMessageInput.value = text
  }

  fun sendChatMessage(): kotlinx.coroutines.Job = sendRichMessage()

  fun sendRichMessage(mediaType: String? = null, mediaLabel: String? = null): kotlinx.coroutines.Job {
    val otherUser = _activeChatUser.value ?: return viewModelScope.launch {}
    val text = _chatMessageInput.value.trim()
    if (text.isBlank() && mediaLabel == null) return viewModelScope.launch {}

    val rep = _replyMessage.value
    return viewModelScope.launch {
      val success = repository.sendRichDirectMessage(
        otherUserId = otherUser.userId,
        content = text,
        mediaType = mediaType,
        mediaLabel = mediaLabel,
        replyToMessageId = rep?.id,
        replyToText = rep?.content,
        replyToSenderName = if (rep?.senderUserId == currentUser.value?.userId) "You" else otherUser.fullName
      )
      if (success) {
        _chatMessageInput.value = ""
        _replyMessage.value = null
      }
    }
  }

  fun sendVoiceNote(seconds: Int = 4): kotlinx.coroutines.Job {
    _isRecordingVoice.value = false
    val otherUser = _activeChatUser.value ?: return viewModelScope.launch {}
    val rep = _replyMessage.value
    return viewModelScope.launch {
      repository.sendRichDirectMessage(
        otherUserId = otherUser.userId,
        content = "🎤 Voice Message (${seconds}s)",
        mediaType = "voice",
        mediaLabel = "Voice Message (${seconds}s)",
        replyToMessageId = rep?.id,
        replyToText = rep?.content,
        replyToSenderName = if (rep?.senderUserId == currentUser.value?.userId) "You" else otherUser.fullName
      )
      _replyMessage.value = null
    }
  }

  fun deleteDirectMessage(messageId: String): kotlinx.coroutines.Job {
    return viewModelScope.launch {
      repository.deleteDirectMessage(messageId)
    }
  }

  fun deleteConversation(convId: String) {
    viewModelScope.launch {
      repository.deleteConversation(convId)
      if (_activeConversationId.value == convId) {
        closeChat()
      }
    }
  }

  // --- Friends and Following Management ---
  enum class FriendsTab { DISCOVER, FOLLOWING, FOLLOWERS, FRIENDS }

  private val _showFriendsSheet = MutableStateFlow(false)
  val showFriendsSheet = _showFriendsSheet.asStateFlow()

  private val _friendsSelectedTab = MutableStateFlow(FriendsTab.DISCOVER)
  val friendsSelectedTab = _friendsSelectedTab.asStateFlow()

  private val _friendsSearchQuery = MutableStateFlow("")
  val friendsSearchQuery = _friendsSearchQuery.asStateFlow()

  fun openFriends() {
    _showFriendsSheet.value = true
  }

  fun closeFriends() {
    _showFriendsSheet.value = false
    _friendsSearchQuery.value = ""
  }

  fun setFriendsTab(tab: FriendsTab) {
    _friendsSelectedTab.value = tab
  }

  fun onFriendsSearchQueryChange(query: String) {
    _friendsSearchQuery.value = query
  }

  @OptIn(ExperimentalCoroutinesApi::class)
  val followingUserIds: StateFlow<Set<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowingUserIds(user.userId) else emptyFlow()
    }
    .map { it.toSet() }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

  @OptIn(ExperimentalCoroutinesApi::class)
  val followerUserIds: StateFlow<Set<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowerUserIds(user.userId) else emptyFlow()
    }
    .map { it.toSet() }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

  // --- Other Users and Posts ---
  @OptIn(ExperimentalCoroutinesApi::class)
  val otherUsers: StateFlow<List<UserAccount>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeOtherUsers(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myPosts: StateFlow<List<CatchyPost>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observePostsForUser(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val viewingUserPosts: StateFlow<List<CatchyPost>> = _viewingOtherUser
    .flatMapLatest { user ->
      if (user != null) repository.observePostsForUser(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val feedPosts: StateFlow<List<CatchyPost>> = repository.observeAllPosts()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // --- Likes State ---
  @OptIn(ExperimentalCoroutinesApi::class)
  val likedPostIds: StateFlow<Set<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeLikedPostIds(user.userId) else emptyFlow()
    }
    .combine(MutableStateFlow(Unit)) { list, _ -> list.toSet() }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

  fun togglePostLike(postId: String) {
    viewModelScope.launch {
      repository.togglePostLike(postId)
    }
  }

  // --- Post Comments State ---
  private val _activeCommentPost = MutableStateFlow<CatchyPost?>(null)
  val activeCommentPost = _activeCommentPost.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val activePostComments: StateFlow<List<CatchyPostComment>> = _activeCommentPost
    .flatMapLatest { post ->
      if (post != null) repository.observePostComments(post.id) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _commentInput = MutableStateFlow("")
  val commentInput = _commentInput.asStateFlow()

  fun openComments(post: CatchyPost) {
    _activeCommentPost.value = post
    _commentInput.value = ""
  }

  fun closeComments() {
    _activeCommentPost.value = null
    _commentInput.value = ""
  }

  fun onCommentInputChange(text: String) {
    _commentInput.value = text
  }

  fun submitComment(): kotlinx.coroutines.Job {
    val post = _activeCommentPost.value ?: return viewModelScope.launch {}
    val text = _commentInput.value.trim()
    if (text.isBlank()) return viewModelScope.launch {}
    return viewModelScope.launch {
      val ok = repository.addPostComment(post.id, text)
      if (ok) {
        _commentInput.value = ""
        val updatedPost = repository.getPostById(post.id)
        if (updatedPost != null && _activeCommentPost.value?.id == post.id) {
          _activeCommentPost.value = updatedPost
        }
      }
    }
  }

  // --- Own Post Edit & Delete State ---
  private val _editingPost = MutableStateFlow<CatchyPost?>(null)
  val editingPost = _editingPost.asStateFlow()

  private val _editPostInput = MutableStateFlow("")
  val editPostInput = _editPostInput.asStateFlow()

  private val _postDeleteTarget = MutableStateFlow<CatchyPost?>(null)
  val postDeleteTarget = _postDeleteTarget.asStateFlow()

  fun startEditPost(post: CatchyPost) {
    _editingPost.value = post
    _editPostInput.value = post.content
  }

  fun onEditPostInputChange(text: String) {
    _editPostInput.value = text
  }

  fun cancelEditPost() {
    _editingPost.value = null
    _editPostInput.value = ""
  }

  fun saveEditPost() {
    val post = _editingPost.value ?: return
    val newText = _editPostInput.value.trim()
    if (newText.isBlank()) return
    viewModelScope.launch {
      val ok = repository.editPost(post.id, newText, post.hashtags, post.location)
      if (ok) {
        _editingPost.value = null
        _editPostInput.value = ""
      }
    }
  }

  fun requestDeletePost(post: CatchyPost) {
    _postDeleteTarget.value = post
  }

  fun cancelDeletePost() {
    _postDeleteTarget.value = null
  }

  fun confirmDeletePost() {
    val post = _postDeleteTarget.value ?: return
    viewModelScope.launch {
      repository.deletePost(post.id)
      _postDeleteTarget.value = null
    }
  }

  // --- Trending Section State ---
  private val _trendingTopics = MutableStateFlow(
    listOf(
      TrendingTopic("#Bangladesh", "National", "42.8k posts"),
      TrendingTopic("#Tech", "Innovation", "28.3k posts"),
      TrendingTopic("#Jobs", "Careers", "19.5k posts"),
      TrendingTopic("#Education", "Learning", "15.2k posts"),
      TrendingTopic("#Business", "Economy", "12.7k posts"),
      TrendingTopic("#Catchy", "Community", "9.4k posts")
    )
  )
  val trendingTopics = _trendingTopics.asStateFlow()

  private val _selectedTrendingTag = MutableStateFlow<String?>(null)
  val selectedTrendingTag = _selectedTrendingTag.asStateFlow()

  private val _showFullTrending = MutableStateFlow(false)
  val showFullTrending = _showFullTrending.asStateFlow()

  fun selectTrendingTag(tag: String?) {
    if (tag != null && (tag.equals("#Jobs", ignoreCase = true) || tag.equals("#Careers", ignoreCase = true))) {
      openJobsCenter()
      return
    }
    if (tag != null && tag.equals("#Business", ignoreCase = true)) {
      openBusinessCenter()
      return
    }
    if (tag != null && (tag.equals("#Investment", ignoreCase = true) || tag.equals("#Startups", ignoreCase = true))) {
      openInvestmentCenter()
      return
    }
    if (tag != null && (tag.equals("#Community", ignoreCase = true) || tag.equals("#Catchy", ignoreCase = true))) {
      openCommunityCenter()
      return
    }
    if (_selectedTrendingTag.value == tag) {
      _selectedTrendingTag.value = null
    } else {
      _selectedTrendingTag.value = tag
    }
  }

  fun openTrendingPage() {
    _showFullTrending.value = true
  }

  fun closeTrendingPage() {
    _showFullTrending.value = false
  }

  // --- Catchy Help & Community Support State ---
  private val _helpCenterTab = MutableStateFlow(HelpCenterTab.COMMUNITY_FEED)
  val helpCenterTab = _helpCenterTab.asStateFlow()

  fun setHelpCenterTab(tab: HelpCenterTab) {
    _helpCenterTab.value = tab
  }

  private val _helpSearchQuery = MutableStateFlow("")
  val helpSearchQuery = _helpSearchQuery.asStateFlow()

  fun onHelpSearchQueryChange(query: String) {
    _helpSearchQuery.value = query
  }

  fun clearHelpSearchQuery() {
    _helpSearchQuery.value = ""
  }

  private val _helpSelectedCategory = MutableStateFlow("All")
  val helpSelectedCategory = _helpSelectedCategory.asStateFlow()

  fun selectHelpCategory(category: String) {
    _helpSelectedCategory.value = category
  }

  private val _helpStatusFilter = MutableStateFlow("All")
  val helpStatusFilter = _helpStatusFilter.asStateFlow()

  fun setHelpStatusFilter(status: String) {
    _helpStatusFilter.value = status
  }

  private val _helpNearbyLocationQuery = MutableStateFlow("Dhaka")
  val helpNearbyLocationQuery = _helpNearbyLocationQuery.asStateFlow()

  fun onNearbyLocationQueryChange(loc: String) {
    _helpNearbyLocationQuery.value = loc
  }

  private val _helpSortOrder = MutableStateFlow("Newest")
  val helpSortOrder = _helpSortOrder.asStateFlow()

  fun setHelpSortOrder(order: String) {
    _helpSortOrder.value = order
  }

  val helpPosts: StateFlow<List<CatchyHelpPost>> = repository.observeHelpPosts()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val blockedUserIds: StateFlow<Set<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeBlockedUserIds(user.userId) else emptyFlow()
    }
    .map { it.toSet() }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

  @OptIn(ExperimentalCoroutinesApi::class)
  val savedHelpPostIds: StateFlow<Set<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeSavedHelpPostIds(user.userId) else emptyFlow()
    }
    .map { it.toSet() }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

  @OptIn(ExperimentalCoroutinesApi::class)
  val savedHelpPosts: StateFlow<List<CatchyHelpPost>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeSavedHelpPosts(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myHelpPosts: StateFlow<List<CatchyHelpPost>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeUserHelpPosts(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myAnsweredHelpPosts: StateFlow<List<CatchyHelpPost>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeHelpPostsAnsweredByUser(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val helpFilterCriteria = combine(
    _helpSearchQuery,
    _helpSelectedCategory,
    _helpStatusFilter,
    _helpSortOrder,
    blockedUserIds
  ) { q, cat, stat, sort, blocked ->
    HelpFilterCriteria(q, cat, stat, sort, blocked)
  }

  val filteredHelpPosts: StateFlow<List<CatchyHelpPost>> = combine(
    helpPosts,
    helpFilterCriteria
  ) { posts, criteria ->
    posts.filter { post ->
      if (post.authorUserId in criteria.blockedUserIds) return@filter false
      val matchesCat = (criteria.category == "All" || post.category.equals(criteria.category, ignoreCase = true))
      val matchesStatus = (criteria.status == "All" || post.status.equals(criteria.status, ignoreCase = true))
      val q = criteria.query.trim().lowercase()
      val matchesQuery = q.isBlank() ||
        post.problemTitle.lowercase().contains(q) ||
        post.problemDescription.lowercase().contains(q) ||
        post.tags.lowercase().contains(q) ||
        (post.location?.lowercase()?.contains(q) == true)
      matchesCat && matchesStatus && matchesQuery
    }.let { list ->
      when (criteria.sortOrder) {
        "Most Helpful" -> list.sortedByDescending { it.helpfulCount }
        "Most Answers" -> list.sortedByDescending { it.answersCount }
        else -> list.sortedByDescending { it.timestamp }
      }
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val nearbyHelpPosts: StateFlow<List<CatchyHelpPost>> = combine(
    helpPosts,
    _helpNearbyLocationQuery,
    blockedUserIds
  ) { posts, locQuery, blocked ->
    val loc = locQuery.trim().lowercase()
    posts.filter { post ->
      post.authorUserId !in blocked &&
      !post.location.isNullOrBlank() &&
      (loc.isBlank() || post.location.lowercase().contains(loc))
    }.sortedByDescending { it.timestamp }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val mySupportTickets: StateFlow<List<SupportTicket>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeUserSupportTickets(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Help Post Detail & Answers
  private val _activeHelpPost = MutableStateFlow<CatchyHelpPost?>(null)
  val activeHelpPost = _activeHelpPost.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val activeHelpAnswers: StateFlow<List<CatchyHelpAnswer>> = _activeHelpPost
    .flatMapLatest { post ->
      if (post != null) repository.observeHelpAnswers(post.id) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _helpAnswerInput = MutableStateFlow("")
  val helpAnswerInput = _helpAnswerInput.asStateFlow()

  private val _replyToAnswerId = MutableStateFlow<String?>(null)
  val replyToAnswerId = _replyToAnswerId.asStateFlow()

  fun setReplyToAnswerId(id: String?) {
    _replyToAnswerId.value = id
  }

  fun openHelpDetail(helpPost: CatchyHelpPost) {
    _activeHelpPost.value = helpPost
    _helpAnswerInput.value = ""
    _replyToAnswerId.value = null
  }

  fun closeHelpDetail() {
    _activeHelpPost.value = null
    _helpAnswerInput.value = ""
    _replyToAnswerId.value = null
  }

  fun onHelpAnswerInputChange(text: String) {
    _helpAnswerInput.value = text
  }

  fun submitHelpAnswer() {
    val post = _activeHelpPost.value ?: return
    val text = _helpAnswerInput.value.trim()
    if (text.isBlank()) return
    val parentId = _replyToAnswerId.value
    viewModelScope.launch {
      val ok = repository.submitRichHelpAnswer(post.id, text, parentId)
      if (ok) {
        _helpAnswerInput.value = ""
        _replyToAnswerId.value = null
      }
    }
  }

  fun toggleAnswerHelpful(answer: CatchyHelpAnswer) {
    viewModelScope.launch {
      repository.toggleAnswerHelpful(answer.id, answer.isVerifiedSolution)
    }
  }

  fun markAnswerBestSolution(answer: CatchyHelpAnswer) {
    val post = _activeHelpPost.value ?: return
    viewModelScope.launch {
      repository.markAnswerBestSolution(post.id, answer.id, !answer.isBestSolution)
    }
  }

  // Create Help Post State
  private val _isCreatingHelpPost = MutableStateFlow(false)
  val isCreatingHelpPost = _isCreatingHelpPost.asStateFlow()

  private val _helpPostTitleInput = MutableStateFlow("")
  val helpPostTitleInput = _helpPostTitleInput.asStateFlow()

  private val _helpPostDescInput = MutableStateFlow("")
  val helpPostDescInput = _helpPostDescInput.asStateFlow()

  private val _helpPostLocationInput = MutableStateFlow("")
  val helpPostLocationInput = _helpPostLocationInput.asStateFlow()

  private val _helpPostCategoryInput = MutableStateFlow("General Help")
  val helpPostCategoryInput = _helpPostCategoryInput.asStateFlow()

  private val _helpPostMediaLabel = MutableStateFlow("")
  val helpPostMediaLabel = _helpPostMediaLabel.asStateFlow()

  private val _helpPostContactPref = MutableStateFlow("In-App Chat")
  val helpPostContactPref = _helpPostContactPref.asStateFlow()

  private val _helpPostTagsInput = MutableStateFlow("")
  val helpPostTagsInput = _helpPostTagsInput.asStateFlow()

  private val _helpPostVisibilityInput = MutableStateFlow("Public")
  val helpPostVisibilityInput = _helpPostVisibilityInput.asStateFlow()

  fun openCreateHelpPost(presetCategory: String? = null) {
    _isCreatingHelpPost.value = true
    _helpPostTitleInput.value = ""
    _helpPostDescInput.value = ""
    _helpPostLocationInput.value = currentUser.value?.addressLocation ?: ""
    _helpPostCategoryInput.value = presetCategory ?: "General Help"
    _helpPostMediaLabel.value = ""
    _helpPostContactPref.value = "In-App Chat"
    _helpPostTagsInput.value = ""
    _helpPostVisibilityInput.value = "Public"
  }

  fun closeCreateHelpPost() {
    _isCreatingHelpPost.value = false
  }

  fun onHelpTitleChange(text: String) { _helpPostTitleInput.value = text }
  fun onHelpDescChange(text: String) { _helpPostDescInput.value = text }
  fun onHelpLocationChange(text: String) { _helpPostLocationInput.value = text }
  fun onHelpCategoryChange(cat: String) { _helpPostCategoryInput.value = cat }
  fun onHelpMediaLabelChange(label: String) { _helpPostMediaLabel.value = label }
  fun onHelpContactPrefChange(pref: String) { _helpPostContactPref.value = pref }
  fun onHelpTagsChange(tags: String) { _helpPostTagsInput.value = tags }
  fun onHelpVisibilityChange(vis: String) { _helpPostVisibilityInput.value = vis }

  fun publishHelpPost() {
    val title = _helpPostTitleInput.value.trim()
    val desc = _helpPostDescInput.value.trim()
    val loc = _helpPostLocationInput.value.trim()
    val cat = _helpPostCategoryInput.value
    val mediaLabel = _helpPostMediaLabel.value.trim().takeIf { it.isNotBlank() }
    val mediaType = if (mediaLabel != null) "photo" else null
    val contact = _helpPostContactPref.value
    val tags = _helpPostTagsInput.value.trim()
    val vis = _helpPostVisibilityInput.value
    if (title.isBlank() || desc.isBlank()) return

    viewModelScope.launch {
      val ok = repository.createRichHelpPost(
        title = title,
        description = desc,
        category = cat,
        mediaType = mediaType,
        mediaLabel = mediaLabel,
        location = loc.ifBlank { null },
        contactPreference = contact,
        tags = tags,
        visibility = vis
      )
      if (ok) {
        closeCreateHelpPost()
      }
    }
  }

  // Editing Help Post State
  private val _editingHelpPost = MutableStateFlow<CatchyHelpPost?>(null)
  val editingHelpPost = _editingHelpPost.asStateFlow()

  private val _editHelpTitleInput = MutableStateFlow("")
  val editHelpTitleInput = _editHelpTitleInput.asStateFlow()

  private val _editHelpDescInput = MutableStateFlow("")
  val editHelpDescInput = _editHelpDescInput.asStateFlow()

  private val _editHelpCategoryInput = MutableStateFlow("General Help")
  val editHelpCategoryInput = _editHelpCategoryInput.asStateFlow()

  private val _editHelpLocationInput = MutableStateFlow("")
  val editHelpLocationInput = _editHelpLocationInput.asStateFlow()

  fun startEditingHelpPost(post: CatchyHelpPost) {
    _editingHelpPost.value = post
    _editHelpTitleInput.value = post.problemTitle
    _editHelpDescInput.value = post.problemDescription
    _editHelpCategoryInput.value = post.category
    _editHelpLocationInput.value = post.location ?: ""
  }

  fun cancelEditingHelpPost() {
    _editingHelpPost.value = null
  }

  fun onEditHelpTitleChange(v: String) { _editHelpTitleInput.value = v }
  fun onEditHelpDescChange(v: String) { _editHelpDescInput.value = v }
  fun onEditHelpCategoryChange(v: String) { _editHelpCategoryInput.value = v }
  fun onEditHelpLocationChange(v: String) { _editHelpLocationInput.value = v }

  fun saveEditedHelpPost() {
    val post = _editingHelpPost.value ?: return
    val title = _editHelpTitleInput.value.trim()
    val desc = _editHelpDescInput.value.trim()
    val cat = _editHelpCategoryInput.value
    val loc = _editHelpLocationInput.value.trim()
    if (title.isBlank() || desc.isBlank()) return

    viewModelScope.launch {
      val ok = repository.updateHelpPost(post.id, title, desc, cat, loc.ifBlank { null })
      if (ok) {
        _editingHelpPost.value = null
        if (_activeHelpPost.value?.id == post.id) {
          _activeHelpPost.value = _activeHelpPost.value?.copy(
            problemTitle = title,
            problemDescription = desc,
            category = cat,
            location = loc.ifBlank { null }
          )
        }
      }
    }
  }

  fun deleteHelpPost(postId: String) {
    viewModelScope.launch {
      val ok = repository.deleteHelpPost(postId)
      if (ok) {
        if (_activeHelpPost.value?.id == postId) {
          closeHelpDetail()
        }
      }
    }
  }

  fun markHelpPostStatus(postId: String, status: String) {
    viewModelScope.launch {
      val ok = repository.setHelpPostStatus(postId, status)
      if (ok && _activeHelpPost.value?.id == postId) {
        _activeHelpPost.value = _activeHelpPost.value?.copy(status = status)
      }
    }
  }

  fun toggleSaveHelpPost(helpPostId: String) {
    viewModelScope.launch {
      repository.toggleSaveHelpPost(helpPostId)
    }
  }

  // Reporting Dialog State
  private val _showReportDialog = MutableStateFlow(false)
  val showReportDialog = _showReportDialog.asStateFlow()

  private val _reportTargetType = MutableStateFlow("post") // "post", "answer", "user"
  val reportTargetType = _reportTargetType.asStateFlow()

  private val _reportTargetId = MutableStateFlow("")
  val reportTargetId = _reportTargetId.asStateFlow()

  private val _reportTargetTitle = MutableStateFlow("")
  val reportTargetTitle = _reportTargetTitle.asStateFlow()

  fun openReportDialog(targetType: String, targetId: String, targetTitle: String) {
    _reportTargetType.value = targetType
    _reportTargetId.value = targetId
    _reportTargetTitle.value = targetTitle
    _showReportDialog.value = true
  }

  fun closeReportDialog() {
    _showReportDialog.value = false
  }

  fun submitReport(reason: String, details: String) {
    val type = _reportTargetType.value
    val targetId = _reportTargetId.value
    if (targetId.isBlank() || reason.isBlank()) return
    viewModelScope.launch {
      repository.submitHelpReport(type, targetId, reason, details)
      closeReportDialog()
    }
  }

  // Block & Unblock User
  fun blockUser(targetUserId: String) {
    viewModelScope.launch {
      repository.blockUser(targetUserId)
    }
  }

  fun unblockUser(targetUserId: String) {
    viewModelScope.launch {
      repository.unblockUser(targetUserId)
    }
  }

  // Support Ticket Form State
  private val _showCreateTicketSheet = MutableStateFlow(false)
  val showCreateTicketSheet = _showCreateTicketSheet.asStateFlow()

  private val _ticketSubjectInput = MutableStateFlow("")
  val ticketSubjectInput = _ticketSubjectInput.asStateFlow()

  private val _ticketCategoryInput = MutableStateFlow("General Inquiry")
  val ticketCategoryInput = _ticketCategoryInput.asStateFlow()

  private val _ticketDescInput = MutableStateFlow("")
  val ticketDescInput = _ticketDescInput.asStateFlow()

  private val _ticketAttachmentLabel = MutableStateFlow("")
  val ticketAttachmentLabel = _ticketAttachmentLabel.asStateFlow()

  private val _ticketRelatedRef = MutableStateFlow("")
  val ticketRelatedRef = _ticketRelatedRef.asStateFlow()

  fun openCreateSupportTicket(presetSubject: String = "", presetCategory: String = "General Inquiry", relatedRef: String = "") {
    _showCreateTicketSheet.value = true
    _ticketSubjectInput.value = presetSubject
    _ticketCategoryInput.value = presetCategory
    _ticketDescInput.value = ""
    _ticketAttachmentLabel.value = ""
    _ticketRelatedRef.value = relatedRef
  }

  fun closeCreateSupportTicket() {
    _showCreateTicketSheet.value = false
  }

  fun onTicketSubjectChange(s: String) { _ticketSubjectInput.value = s }
  fun onTicketCategoryChange(c: String) { _ticketCategoryInput.value = c }
  fun onTicketDescChange(d: String) { _ticketDescInput.value = d }
  fun onTicketAttachmentChange(a: String) { _ticketAttachmentLabel.value = a }

  fun submitSupportTicket() {
    val subj = _ticketSubjectInput.value.trim()
    val cat = _ticketCategoryInput.value
    val desc = _ticketDescInput.value.trim()
    val att = _ticketAttachmentLabel.value.trim().takeIf { it.isNotBlank() }
    val ref = _ticketRelatedRef.value.trim().takeIf { it.isNotBlank() }
    if (subj.isBlank() || desc.isBlank()) return

    viewModelScope.launch {
      val ok = repository.submitSupportTicket(
        subject = subj,
        category = cat,
        description = desc,
        attachmentLabel = att,
        relatedContentRef = ref
      )
      if (ok) {
        closeCreateSupportTicket()
      }
    }
  }

  // Help Center FAQ Articles State
  private val _articleSearchQuery = MutableStateFlow("")
  val articleSearchQuery = _articleSearchQuery.asStateFlow()

  private val _selectedArticle = MutableStateFlow<HelpCenterArticle?>(null)
  val selectedArticle = _selectedArticle.asStateFlow()

  val filteredArticles: StateFlow<List<HelpCenterArticle>> = _articleSearchQuery
    .map { query ->
      val q = query.trim().lowercase()
      if (q.isBlank()) {
        CatchyHelpArticles.ARTICLES
      } else {
        CatchyHelpArticles.ARTICLES.filter { article ->
          article.title.lowercase().contains(q) ||
          article.topic.lowercase().contains(q) ||
          article.summary.lowercase().contains(q) ||
          article.content.lowercase().contains(q) ||
          article.keywords.any { it.lowercase().contains(q) }
        }
      }
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, CatchyHelpArticles.ARTICLES)

  fun onArticleSearchQueryChange(q: String) {
    _articleSearchQuery.value = q
  }

  fun selectArticle(article: HelpCenterArticle?) {
    _selectedArticle.value = article
  }

  // --- Stories State ---
  val stories: StateFlow<List<CatchyStory>> = repository.observeStories()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _activeStory = MutableStateFlow<CatchyStory?>(null)
  val activeStory = _activeStory.asStateFlow()

  private val _isAddingStory = MutableStateFlow(false)
  val isAddingStory = _isAddingStory.asStateFlow()

  private val _storyTextInput = MutableStateFlow("")
  val storyTextInput = _storyTextInput.asStateFlow()

  private val _selectedGradientIndex = MutableStateFlow(0)
  val selectedGradientIndex = _selectedGradientIndex.asStateFlow()

  fun openStory(story: CatchyStory) {
    _activeStory.value = story
  }

  fun closeStory() {
    _activeStory.value = null
  }

  fun openAddStory() {
    _isAddingStory.value = true
    _storyTextInput.value = ""
    _selectedGradientIndex.value = 0
  }

  fun closeAddStory() {
    _isAddingStory.value = false
    _storyTextInput.value = ""
  }

  fun onStoryTextChange(text: String) {
    _storyTextInput.value = text
  }

  fun setStoryGradient(index: Int) {
    _selectedGradientIndex.value = index
  }

  fun publishStory() {
    val text = _storyTextInput.value.trim()
    if (text.isBlank()) return
    viewModelScope.launch {
      val ok = repository.createStory(
        storyText = text,
        mediaLabel = "Catchy Story",
        gradientIndex = _selectedGradientIndex.value
      )
      if (ok) {
        closeAddStory()
      }
    }
  }

  private val _newPostInput = MutableStateFlow("")
  val newPostInput = _newPostInput.asStateFlow()

  private val _postAttachmentType = MutableStateFlow<String?>(null) // "photo", "video"
  val postAttachmentType = _postAttachmentType.asStateFlow()

  private val _postAttachmentLabel = MutableStateFlow<String?>(null)
  val postAttachmentLabel = _postAttachmentLabel.asStateFlow()

  init {
    viewModelScope.launch {
      repository.seedCatchyCommunityIfEmpty()
      val primary = repository.getCurrentOrPrimaryUser()
      if (primary != null && currentUser.value == null) {
        repository.setCurrentUserById(primary.id)
      }
    }
    viewModelScope.launch {
      currentUser.collect { user ->
        if (user != null && _notifications.value.isEmpty()) {
          _notifications.value = listOf(
            CatchyNotificationItem(
              id = "notif_welcome_${user.userId}",
              title = "Welcome to Catchy Social!",
              message = "Your official Catchy unique User ID is ${user.userId}. Use this ID to connect, chat, and share authentically.",
              timestamp = System.currentTimeMillis() - 1000L * 60 * 15,
              type = "welcome"
            ),
            CatchyNotificationItem(
              id = "notif_rahim_update",
              title = "Rahim Ahmed shared a post",
              message = "Rahim published: 'Welcome to my Catchy profile! Excited to connect authentically on this platform.'",
              timestamp = System.currentTimeMillis() - 1000L * 60 * 60 * 2,
              type = "post"
            ),
            CatchyNotificationItem(
              id = "notif_tahmina_network",
              title = "Community Activity",
              message = "Tahmina Chowdhury and others are active on Catchy. Discover their profiles and connect!",
              timestamp = System.currentTimeMillis() - 1000L * 60 * 60 * 5,
              type = "social"
            ),
            CatchyNotificationItem(
              id = "notif_security",
              title = "Account Verified",
              message = "Your profile is verified and safeguarded under Catchy security standards.",
              timestamp = System.currentTimeMillis() - 1000L * 60 * 60 * 24,
              type = "help",
              isRead = true
            )
          )
        }
      }
    }
  }

  fun onNewPostInputChange(text: String) {
    _newPostInput.value = text
  }

  fun setPostAttachment(type: String?, label: String?) {
    _postAttachmentType.value = type
    _postAttachmentLabel.value = label
  }

  fun clearPostAttachment() {
    _postAttachmentType.value = null
    _postAttachmentLabel.value = null
  }

  private val _postLocation = MutableStateFlow<String?>(null)
  val postLocation = _postLocation.asStateFlow()

  fun setPostLocation(loc: String?) {
    _postLocation.value = loc
  }

  fun publishPost(): kotlinx.coroutines.Job {
    val text = _newPostInput.value.trim()
    val attachmentType = _postAttachmentType.value
    val attachmentLabel = _postAttachmentLabel.value
    if (text.isBlank() && attachmentType == null) return viewModelScope.launch {}

    val contentToSave = if (text.isBlank()) {
      if (attachmentType == "photo") "Shared a photo: ${attachmentLabel ?: "Catchy Moment"}"
      else "Shared a video: ${attachmentLabel ?: "Catchy Reel Clip"}"
    } else {
      text
    }

    val foundHashtags = Regex("#[A-Za-z0-9_]+").findAll(contentToSave).map { it.value }.joinToString(" ")
    val hashtagsToSave = if (foundHashtags.isNotBlank()) foundHashtags else null
    val locationToSave = _postLocation.value ?: currentUser.value?.addressLocation

    return viewModelScope.launch {
      val post = repository.createPost(
        content = contentToSave,
        attachmentType = attachmentType,
        attachmentLabel = attachmentLabel,
        hashtags = hashtagsToSave,
        location = locationToSave
      )
      if (post != null) {
        _newPostInput.value = ""
        _postAttachmentType.value = null
        _postAttachmentLabel.value = null
        _postLocation.value = null
        _homeSearchQuery.value = ""
        _selectedTrendingTag.value = null
      }
    }
  }

  // --- Follows & Relationships ---
  @OptIn(ExperimentalCoroutinesApi::class)
  val isFollowingViewingUser: StateFlow<Boolean> = combine(
    currentUser,
    _viewingOtherUser
  ) { cur, viewing ->
    if (cur != null && viewing != null) {
      cur.userId to viewing.userId
    } else null
  }.flatMapLatest { pair ->
    if (pair != null) repository.isFollowing(pair.first, pair.second) else emptyFlow()
  }.stateIn(viewModelScope, SharingStarted.Lazily, false)

  @OptIn(ExperimentalCoroutinesApi::class)
  val myFollowerCount: StateFlow<Int> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowerCount(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  @OptIn(ExperimentalCoroutinesApi::class)
  val myFollowingCount: StateFlow<Int> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowingCount(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  @OptIn(ExperimentalCoroutinesApi::class)
  val viewingUserFollowerCount: StateFlow<Int> = _viewingOtherUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowerCount(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  @OptIn(ExperimentalCoroutinesApi::class)
  val viewingUserFollowingCount: StateFlow<Int> = _viewingOtherUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowingCount(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  fun toggleFollowViewingUser() {
    val other = _viewingOtherUser.value ?: return
    viewModelScope.launch {
      repository.toggleFollow(other.userId)
    }
  }

  fun toggleFollowUser(targetUserId: String) {
    viewModelScope.launch {
      repository.toggleFollow(targetUserId)
    }
  }

  // Verification dialog/action state
  private val _verificationInput = MutableStateFlow("")
  val verificationInput = _verificationInput.asStateFlow()

  private val _verificationFeedback = MutableStateFlow<String?>(null)
  val verificationFeedback = _verificationFeedback.asStateFlow()

  private val _isVerifying = MutableStateFlow(false)
  val isVerifying = _isVerifying.asStateFlow()

  // Profile Edit State (Only Full Name, Photo, and Bio are editable)
  private val _editFullName = MutableStateFlow("")
  val editFullName = _editFullName.asStateFlow()

  private val _editPhotoUri = MutableStateFlow<String?>(null)
  val editPhotoUri = _editPhotoUri.asStateFlow()

  private val _editBio = MutableStateFlow("")
  val editBio = _editBio.asStateFlow()

  private val _isEditingProfile = MutableStateFlow(false)
  val isEditingProfile = _isEditingProfile.asStateFlow()

  private val _profileFeedback = MutableStateFlow<String?>(null)
  val profileFeedback = _profileFeedback.asStateFlow()

  fun navigateTo(screen: CatchyScreen) {
    _currentScreen.value = screen
    _loginState.value = _loginState.value.copy(errorMessage = null)
    _signUpState.value = _signUpState.value.copy(errorMessage = null)
    _forgotPasswordState.value = _forgotPasswordState.value.copy(errorMessage = null)
    _resetPasswordState.value = _resetPasswordState.value.copy(errorMessage = null)
  }

  // --- Login Handlers ---
  fun onLoginIdentifierChange(value: String) {
    _loginState.value = _loginState.value.copy(identifier = value, errorMessage = null)
  }

  fun onLoginPasswordChange(value: String) {
    _loginState.value = _loginState.value.copy(password = value, errorMessage = null)
  }

  fun login() {
    viewModelScope.launch {
      _loginState.value = _loginState.value.copy(isLoading = true, errorMessage = null)
      val result = repository.login(
        identifier = _loginState.value.identifier,
        password = _loginState.value.password
      )
      when (result) {
        is AuthResult.Success -> {
          _loginState.value = LoginUiState()
          _currentScreen.value = CatchyScreen.ACCOUNT_IDENTITY
        }
        is AuthResult.Error -> {
          _loginState.value = _loginState.value.copy(
            isLoading = false,
            errorMessage = result.errorMessage
          )
        }
      }
    }
  }

  // --- Sign Up Handlers ---
  fun updateSignUpField(update: (SignUpUiState) -> SignUpUiState) {
    _signUpState.value = update(_signUpState.value).copy(errorMessage = null)
  }

  fun signUp() {
    val s = _signUpState.value
    viewModelScope.launch {
      _signUpState.value = s.copy(isLoading = true, errorMessage = null)
      val result = repository.createAccount(
        fullName = s.fullName,
        email = s.email,
        dateOfBirth = s.dateOfBirth,
        gender = s.gender,
        addressLocation = s.addressLocation,
        educationStatus = s.educationStatus,
        occupationStatus = s.occupationStatus,
        skills = s.skills,
        maritalStatus = s.maritalStatus,
        password = s.password,
        confirmPassword = s.confirmPassword,
        profilePhotoUri = s.profilePhotoUri,
        termsAccepted = s.termsAccepted
      )

      when (result) {
        is AuthResult.Success -> {
          _signUpState.value = SignUpUiState()
          _currentScreen.value = CatchyScreen.ACCOUNT_IDENTITY
        }
        is AuthResult.Error -> {
          _signUpState.value = s.copy(isLoading = false, errorMessage = result.errorMessage)
        }
      }
    }
  }

  // --- Email Verification Handlers ---
  fun onVerificationInputChange(value: String) {
    _verificationInput.value = value
    _verificationFeedback.value = null
  }

  fun verifyEmail(codeToVerify: String? = null) {
    val code = codeToVerify ?: _verificationInput.value
    viewModelScope.launch {
      _isVerifying.value = true
      val result = repository.verifyEmailCode(code)
      _isVerifying.value = false
      when (result) {
        is AuthResult.Success -> {
          _verificationFeedback.value = result.message ?: "Email verified successfully!"
          _verificationInput.value = ""
        }
        is AuthResult.Error -> {
          _verificationFeedback.value = result.errorMessage
        }
      }
    }
  }

  fun resendVerificationEmail() {
    viewModelScope.launch {
      val result = repository.resendEmailVerification()
      when (result) {
        is AuthResult.Success -> {
          _verificationFeedback.value = result.message
        }
        is AuthResult.Error -> {
          _verificationFeedback.value = result.errorMessage
        }
      }
    }
  }

  // --- Forgot Password Handlers ---
  fun onForgotPasswordEmailChange(value: String) {
    _forgotPasswordState.value = _forgotPasswordState.value.copy(email = value, errorMessage = null)
  }

  fun requestPasswordReset() {
    val email = _forgotPasswordState.value.email
    viewModelScope.launch {
      _forgotPasswordState.value = _forgotPasswordState.value.copy(isLoading = true, errorMessage = null)
      val result = repository.requestPasswordReset(email)
      when (result) {
        is AuthResult.Success -> {
          _forgotPasswordState.value = _forgotPasswordState.value.copy(
            isLoading = false,
            dispatch = result.data
          )
        }
        is AuthResult.Error -> {
          _forgotPasswordState.value = _forgotPasswordState.value.copy(
            isLoading = false,
            errorMessage = result.errorMessage
          )
        }
      }
    }
  }

  fun startResetPasswordWithToken(token: String) {
    _resetPasswordState.value = ResetPasswordUiState(token = token)
    _currentScreen.value = CatchyScreen.RESET_PASSWORD
  }

  fun onNewPasswordChange(value: String) {
    _resetPasswordState.value = _resetPasswordState.value.copy(newPassword = value, errorMessage = null)
  }

  fun onConfirmNewPasswordChange(value: String) {
    _resetPasswordState.value = _resetPasswordState.value.copy(confirmPassword = value, errorMessage = null)
  }

  fun submitPasswordReset() {
    val state = _resetPasswordState.value
    viewModelScope.launch {
      _resetPasswordState.value = state.copy(isLoading = true, errorMessage = null)
      val result = repository.resetPasswordWithToken(
        token = state.token,
        newPassword = state.newPassword,
        confirmPassword = state.confirmPassword
      )
      when (result) {
        is AuthResult.Success -> {
          _resetPasswordState.value = state.copy(
            isLoading = false,
            isCompleted = true
          )
          _loginState.value = LoginUiState(
            infoMessage = "Password changed successfully. Please log in with your new credentials."
          )
        }
        is AuthResult.Error -> {
          _resetPasswordState.value = state.copy(
            isLoading = false,
            errorMessage = result.errorMessage
          )
        }
      }
    }
  }

  // --- Editable Profile Details Handlers ---
  fun startEditingProfile(currentName: String, currentPhoto: String?, currentBio: String = "") {
    _editFullName.value = currentName
    _editPhotoUri.value = currentPhoto
    _editBio.value = currentBio
    _isEditingProfile.value = true
    _profileFeedback.value = null
  }

  fun cancelEditingProfile() {
    _isEditingProfile.value = false
    _profileFeedback.value = null
  }

  fun onEditFullNameChange(value: String) {
    _editFullName.value = value
  }

  fun onEditPhotoUriChange(value: String?) {
    _editPhotoUri.value = value
  }

  fun onEditBioChange(value: String) {
    _editBio.value = value
  }

  fun saveEditableProfile() {
    viewModelScope.launch {
      val result = repository.updateEditableProfile(
        _editFullName.value,
        _editPhotoUri.value,
        _editBio.value
      )
      when (result) {
        is AuthResult.Success -> {
          _isEditingProfile.value = false
          _profileFeedback.value = "Profile updated successfully"
        }
        is AuthResult.Error -> {
          _profileFeedback.value = result.errorMessage
        }
      }
    }
  }

  fun reportUser(userId: String, reason: String) {
    val notif = CatchyNotificationItem(
      id = "rep_${System.currentTimeMillis()}",
      title = "Report Submitted",
      message = "Your report regarding user @$userId ($reason) was received by Catchy moderation.",
      timestamp = System.currentTimeMillis(),
      type = "moderation"
    )
    _notifications.value = listOf(notif) + _notifications.value
  }

  // --- Catchy Go / Reels Real Database Video Experience (Step 3) ---
  private val _likedVideoIds = MutableStateFlow<Set<String>>(emptySet())
  private val _savedVideoIds = MutableStateFlow<Set<String>>(emptySet())
  private val _followingCreatorIds = MutableStateFlow<Set<String>>(emptySet())

  /**
   * Published Catchy Go feed sourced exclusively from the real Room database.
   * Drafts and unpublished uploads are strictly excluded.
   * Seamlessly combines real database video metadata with the creator's real profile identity.
   */
  val catchyGoVideos: StateFlow<List<CatchyGoVideo>> = combine(
    repository.getCatchyGoFeedVideos(),
    _likedVideoIds,
    _savedVideoIds,
    _followingCreatorIds
  ) { videos, liked, saved, following ->
    videos.map { v ->
      val isLiked = liked.contains(v.id)
      val isSaved = saved.contains(v.id)
      v.copy(
        isLiked = isLiked,
        likesCount = if (isLiked) v.likesCount + 1 else v.likesCount,
        isSaved = isSaved,
        savesCount = if (isSaved) v.savesCount + 1 else v.savesCount,
        isFollowing = following.contains(v.creatorUserId.uppercase())
      )
    }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.Eagerly,
    initialValue = emptyList()
  )

  fun toggleLikeVideo(videoId: String) {
    val currentlyLiked = _likedVideoIds.value.contains(videoId)
    val newLiked = !currentlyLiked
    _likedVideoIds.value = if (newLiked) {
      _likedVideoIds.value + videoId
    } else {
      _likedVideoIds.value - videoId
    }
    viewModelScope.launch {
      repository.updateCatchyGoVideoLikes(videoId, newLiked)
    }
  }

  fun toggleSaveVideo(videoId: String) {
    val currentlySaved = _savedVideoIds.value.contains(videoId)
    val newSaved = !currentlySaved
    _savedVideoIds.value = if (newSaved) {
      _savedVideoIds.value + videoId
    } else {
      _savedVideoIds.value - videoId
    }
    viewModelScope.launch {
      repository.updateCatchyGoVideoSaves(videoId, newSaved)
    }
  }

  fun toggleFollowCreator(creatorUserId: String) {
    val normalized = creatorUserId.uppercase()
    val isFollowing = _followingCreatorIds.value.contains(normalized)
    _followingCreatorIds.value = if (isFollowing) {
      _followingCreatorIds.value - normalized
    } else {
      _followingCreatorIds.value + normalized
    }
  }

  fun addCommentToVideo(videoId: String, commentText: String) {
    if (commentText.isBlank()) return
    viewModelScope.launch {
      repository.incrementCatchyGoVideoComments(videoId)
    }
  }

  // --- Catchy Go Step 2 & 3: Uploaded Video Metadata Persistence & Publishing ---
  private val _uploadedVideos = MutableStateFlow<List<CatchyGoUploadedVideo>>(emptyList())
  val uploadedVideos = _uploadedVideos.asStateFlow()

  private val _publishState = MutableStateFlow<PublishUiState>(PublishUiState.Idle)
  val publishState: StateFlow<PublishUiState> = _publishState.asStateFlow()

  fun loadUploadedVideos(creatorId: String) {
    viewModelScope.launch {
      repository.getCatchyGoUploadedVideos(creatorId).collect {
        _uploadedVideos.value = it
      }
    }
  }

  suspend fun saveUploadedVideoMetadata(
    title: String,
    description: String,
    category: String,
    tags: String,
    visibility: String,
    creatorId: String,
    storageUrl: String,
    localUri: String? = null,
    duration: Long,
    createdTime: Long = System.currentTimeMillis()
  ): CatchyGoUploadedVideo {
    val video = CatchyGoUploadedVideo(
      title = title,
      description = description,
      category = category,
      tags = tags,
      visibility = visibility,
      creatorId = creatorId,
      storageUrl = storageUrl,
      localUri = localUri,
      duration = duration,
      createdTime = createdTime,
      isPublishedToFeed = false
    )
    repository.saveCatchyGoUploadedVideo(video)
    _uploadedVideos.value = listOf(video) + _uploadedVideos.value.filter { it.id != video.id }
    return video
  }

  /**
   * Real publishing action: Marks uploaded draft video as published in the database.
   * Enforces duplicate publishing prevention and exposes clear success/error UI states.
   */
  suspend fun publishUploadedVideo(videoId: String): Result<CatchyGoUploadedVideo> {
    if (_publishState.value is PublishUiState.Publishing) {
      return Result.failure(IllegalStateException("Publishing is already in progress."))
    }
    _publishState.value = PublishUiState.Publishing
    val result = repository.publishCatchyGoVideo(videoId)
    result.fold(
      onSuccess = { updatedVideo ->
        _publishState.value = PublishUiState.Success(updatedVideo)
        _uploadedVideos.value = _uploadedVideos.value.map {
          if (it.id == videoId) updatedVideo else it
        }
      },
      onFailure = { error ->
        _publishState.value = PublishUiState.Error(
          error.localizedMessage ?: "Failed to publish video to the feed. Please try again."
        )
      }
    )
    return result
  }

  fun resetPublishState() {
    _publishState.value = PublishUiState.Idle
  }

  // ==========================================
  // CATCHY JOBS & CAREER SYSTEM
  // ==========================================

  private val _showJobsScreen = MutableStateFlow(false)
  val showJobsScreen: StateFlow<Boolean> = _showJobsScreen.asStateFlow()

  private val _jobsTab = MutableStateFlow(CatchyJobsTab.EXPLORE)
  val jobsTab: StateFlow<CatchyJobsTab> = _jobsTab.asStateFlow()

  private val _jobsSearchQuery = MutableStateFlow("")
  val jobsSearchQuery: StateFlow<String> = _jobsSearchQuery.asStateFlow()

  private val _selectedJobCategory = MutableStateFlow("All")
  val selectedJobCategory: StateFlow<String> = _selectedJobCategory.asStateFlow()

  private val _selectedEmploymentType = MutableStateFlow("All")
  val selectedEmploymentType: StateFlow<String> = _selectedEmploymentType.asStateFlow()

  private val _onlyRemote = MutableStateFlow(false)
  val onlyRemote: StateFlow<Boolean> = _onlyRemote.asStateFlow()

  val rawActiveJobs: StateFlow<List<CatchyJobPosting>> = repository.observeActiveJobs()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val filteredJobs: StateFlow<List<CatchyJobPosting>> = combine(
    rawActiveJobs,
    _jobsSearchQuery,
    _selectedJobCategory,
    _selectedEmploymentType,
    _onlyRemote
  ) { jobs, query, category, empType, remoteOnly ->
    jobs.filter { job ->
      val matchesQuery = query.isBlank() ||
        job.title.contains(query, ignoreCase = true) ||
        job.companyName.contains(query, ignoreCase = true) ||
        job.description.contains(query, ignoreCase = true) ||
        job.skillsRequired.contains(query, ignoreCase = true) ||
        job.location.contains(query, ignoreCase = true)

      val matchesCategory = category == "All" || job.category.equals(category, ignoreCase = true)
      val matchesType = empType == "All" || job.employmentType.equals(empType, ignoreCase = true)
      val matchesRemote = !remoteOnly || job.isRemote

      matchesQuery && matchesCategory && matchesType && matchesRemote
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myJobPostings: StateFlow<List<CatchyJobPosting>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeEmployerJobs(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myApplications: StateFlow<List<CatchyJobApplication>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeMyApplications(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val jobSeekerProfile: StateFlow<CatchyJobSeekerProfile?> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeJobSeekerProfile(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, null)

  @OptIn(ExperimentalCoroutinesApi::class)
  val employerProfile: StateFlow<CatchyEmployerProfile?> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeEmployerProfile(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, null)

  // Selected Job for Details Modal
  private val _selectedJob = MutableStateFlow<CatchyJobPosting?>(null)
  val selectedJob: StateFlow<CatchyJobPosting?> = _selectedJob.asStateFlow()

  // Apply Flow State
  private val _applyingToJob = MutableStateFlow<CatchyJobPosting?>(null)
  val applyingToJob: StateFlow<CatchyJobPosting?> = _applyingToJob.asStateFlow()

  private val _isSubmittingApplication = MutableStateFlow(false)
  val isSubmittingApplication: StateFlow<Boolean> = _isSubmittingApplication.asStateFlow()

  private val _applicationFeedbackMessage = MutableStateFlow<String?>(null)
  val applicationFeedbackMessage: StateFlow<String?> = _applicationFeedbackMessage.asStateFlow()

  // Manage Applicants for Employer
  private val _managingJob = MutableStateFlow<CatchyJobPosting?>(null)
  val managingJob: StateFlow<CatchyJobPosting?> = _managingJob.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val managingJobApplicants: StateFlow<List<CatchyJobApplication>> = _managingJob
    .flatMapLatest { job ->
      if (job != null) repository.observeApplicationsForJob(job.jobId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Job Creation / Editing State
  private val _isJobPostDialogVisible = MutableStateFlow(false)
  val isJobPostDialogVisible: StateFlow<Boolean> = _isJobPostDialogVisible.asStateFlow()

  private val _editingJobPosting = MutableStateFlow<CatchyJobPosting?>(null)
  val editingJobPosting: StateFlow<CatchyJobPosting?> = _editingJobPosting.asStateFlow()

  private val _isSavingJobPosting = MutableStateFlow(false)
  val isSavingJobPosting: StateFlow<Boolean> = _isSavingJobPosting.asStateFlow()

  private val _jobPostingFormError = MutableStateFlow<String?>(null)
  val jobPostingFormError: StateFlow<String?> = _jobPostingFormError.asStateFlow()

  fun openJobsCenter(initialTab: CatchyJobsTab = CatchyJobsTab.EXPLORE) {
    _jobsTab.value = initialTab
    _showJobsScreen.value = true
  }

  fun closeJobsCenter() {
    _showJobsScreen.value = false
    _selectedJob.value = null
    _applyingToJob.value = null
    _managingJob.value = null
    _isJobPostDialogVisible.value = false
    _editingJobPosting.value = null
    _applicationFeedbackMessage.value = null
  }

  fun setJobsTab(tab: CatchyJobsTab) {
    _jobsTab.value = tab
    _selectedJob.value = null
    _managingJob.value = null
  }

  fun setJobsSearchQuery(query: String) {
    _jobsSearchQuery.value = query
  }

  fun setSelectedJobCategory(category: String) {
    _selectedJobCategory.value = category
  }

  fun setSelectedEmploymentType(type: String) {
    _selectedEmploymentType.value = type
  }

  fun setOnlyRemote(remote: Boolean) {
    _onlyRemote.value = remote
  }

  fun selectJob(job: CatchyJobPosting?) {
    _selectedJob.value = job
  }

  fun openApplyDialog(job: CatchyJobPosting) {
    _applyingToJob.value = job
    _applicationFeedbackMessage.value = null
  }

  fun closeApplyDialog() {
    _applyingToJob.value = null
    _applicationFeedbackMessage.value = null
    _isSubmittingApplication.value = false
  }

  fun submitJobApplication(
    coverNote: String,
    resumeOrPortfolioLink: String,
    skills: String,
    experience: String,
    location: String
  ) {
    val job = _applyingToJob.value ?: return
    viewModelScope.launch {
      _isSubmittingApplication.value = true
      val result = repository.applyForJob(
        jobId = job.jobId,
        coverNote = coverNote,
        resumeOrPortfolioLink = resumeOrPortfolioLink,
        skills = skills,
        experience = experience,
        location = location
      )
      _isSubmittingApplication.value = false
      result.fold(
        onSuccess = {
          _applicationFeedbackMessage.value = "Application successfully submitted for ${job.title}!"
          _applyingToJob.value = null
        },
        onFailure = { error ->
          _applicationFeedbackMessage.value = error.localizedMessage ?: "Failed to submit application."
        }
      )
    }
  }

  fun clearApplicationFeedback() {
    _applicationFeedbackMessage.value = null
  }

  fun openCreateJobDialog() {
    _editingJobPosting.value = null
    _jobPostingFormError.value = null
    _isJobPostDialogVisible.value = true
  }

  fun openEditJobDialog(job: CatchyJobPosting) {
    _editingJobPosting.value = job
    _jobPostingFormError.value = null
    _isJobPostDialogVisible.value = true
  }

  fun closeJobPostDialog() {
    _isJobPostDialogVisible.value = false
    _editingJobPosting.value = null
    _jobPostingFormError.value = null
    _isSavingJobPosting.value = false
  }

  fun saveJobPosting(
    title: String,
    companyName: String,
    description: String,
    category: String,
    skillsRequired: String,
    location: String,
    isRemote: Boolean,
    employmentType: String,
    experienceLevel: String,
    salaryRange: String,
    applicationInstructions: String,
    status: String = "ACTIVE"
  ) {
    val editing = _editingJobPosting.value
    viewModelScope.launch {
      _isSavingJobPosting.value = true
      _jobPostingFormError.value = null
      val result = if (editing != null) {
        repository.updateJobPosting(
          jobId = editing.jobId,
          title = title,
          companyName = companyName,
          description = description,
          category = category,
          skillsRequired = skillsRequired,
          location = location,
          isRemote = isRemote,
          employmentType = employmentType,
          experienceLevel = experienceLevel,
          salaryRange = salaryRange,
          applicationInstructions = applicationInstructions,
          status = status
        )
      } else {
        repository.createJobPosting(
          title = title,
          companyName = companyName,
          description = description,
          category = category,
          skillsRequired = skillsRequired,
          location = location,
          isRemote = isRemote,
          employmentType = employmentType,
          experienceLevel = experienceLevel,
          salaryRange = salaryRange,
          applicationInstructions = applicationInstructions
        )
      }
      _isSavingJobPosting.value = false
      result.fold(
        onSuccess = {
          _isJobPostDialogVisible.value = false
          _editingJobPosting.value = null
        },
        onFailure = { error ->
          _jobPostingFormError.value = error.localizedMessage ?: "Failed to save job posting."
        }
      )
    }
  }

  fun closeJobPosting(jobId: String) {
    viewModelScope.launch {
      repository.closeJobPosting(jobId)
    }
  }

  fun deleteJobPosting(jobId: String) {
    viewModelScope.launch {
      repository.deleteJobPosting(jobId)
      if (_selectedJob.value?.jobId == jobId) {
        _selectedJob.value = null
      }
    }
  }

  fun openManageApplicants(job: CatchyJobPosting) {
    _managingJob.value = job
  }

  fun closeManageApplicants() {
    _managingJob.value = null
  }

  fun updateApplicantStatus(applicationId: String, newStatus: String) {
    viewModelScope.launch {
      repository.updateApplicationStatus(applicationId, newStatus)
    }
  }

  fun saveJobSeekerProfile(
    headline: String,
    careerGoal: String,
    skills: String,
    experienceYears: String,
    experienceSummary: String,
    education: String,
    location: String,
    cvSummaryOrUrl: String,
    preferredJobTypes: String,
    isAvailableForHire: Boolean
  ) {
    val user = currentUser.value ?: return
    viewModelScope.launch {
      val profile = CatchyJobSeekerProfile(
        userId = user.userId,
        headline = headline.trim(),
        careerGoal = careerGoal.trim(),
        skills = skills.trim(),
        experienceYears = experienceYears.trim(),
        experienceSummary = experienceSummary.trim(),
        education = education.trim(),
        location = location.trim(),
        cvSummaryOrUrl = cvSummaryOrUrl.trim(),
        preferredJobTypes = preferredJobTypes.trim(),
        isAvailableForHire = isAvailableForHire,
        updatedAt = System.currentTimeMillis()
      )
      repository.saveJobSeekerProfile(profile)
    }
  }

  fun saveEmployerProfile(
    companyName: String,
    industry: String,
    companyWebsite: String,
    companyLocation: String,
    companySize: String,
    companyBio: String,
    verifiedEmployer: Boolean
  ) {
    val user = currentUser.value ?: return
    viewModelScope.launch {
      val profile = CatchyEmployerProfile(
        userId = user.userId,
        companyName = companyName.trim(),
        industry = industry.trim(),
        companyWebsite = companyWebsite.trim(),
        companyLocation = companyLocation.trim(),
        companySize = companySize.trim(),
        companyBio = companyBio.trim(),
        verifiedEmployer = verifiedEmployer,
        updatedAt = System.currentTimeMillis()
      )
      repository.saveEmployerProfile(profile)
    }
  }

  fun messageJobContact(targetUserId: String, targetUserName: String, initialContextMessage: String? = null) {
    viewModelScope.launch {
      val targetUser = repository.getUserByUserId(targetUserId) ?: UserAccount(
        userId = targetUserId,
        email = "$targetUserId@catchy.com",
        dateOfBirth = "2000-01-01",
        gender = "Not specified",
        addressLocation = "Global",
        educationStatus = "Professional",
        occupationStatus = "Catchy Member",
        skills = "Networking",
        maritalStatus = "Single",
        fullName = targetUserName,
        passwordHash = "",
        passwordSalt = ""
      )
      _showJobsScreen.value = false
      _selectedJob.value = null
      _managingJob.value = null
      openChatWithUser(targetUser)
      if (!initialContextMessage.isNullOrBlank()) {
        _chatMessageInput.value = initialContextMessage
      }
    }
  }

  // ==========================================
  // CATCHY INVESTMENT NETWORK SYSTEM
  // ==========================================

  private val _showInvestmentScreen = MutableStateFlow(false)
  val showInvestmentScreen: StateFlow<Boolean> = _showInvestmentScreen.asStateFlow()

  private val _investmentTab = MutableStateFlow(CatchyInvestmentTab.EXPLORE)
  val investmentTab: StateFlow<CatchyInvestmentTab> = _investmentTab.asStateFlow()

  private val _investmentSearchQuery = MutableStateFlow("")
  val investmentSearchQuery: StateFlow<String> = _investmentSearchQuery.asStateFlow()

  private val _selectedIndustry = MutableStateFlow("All")
  val selectedIndustry: StateFlow<String> = _selectedIndustry.asStateFlow()

  private val _selectedStage = MutableStateFlow("All")
  val selectedStage: StateFlow<String> = _selectedStage.asStateFlow()

  private val _selectedInstrument = MutableStateFlow("All")
  val selectedInstrument: StateFlow<String> = _selectedInstrument.asStateFlow()

  private val _onlyVerifiedOpportunities = MutableStateFlow(false)
  val onlyVerifiedOpportunities: StateFlow<Boolean> = _onlyVerifiedOpportunities.asStateFlow()

  val rawActiveOpportunities: StateFlow<List<CatchyInvestmentOpportunity>> = repository.observeActiveInvestmentOpportunities()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private data class InvestmentFilterCriteria(
    val query: String = "",
    val industry: String = "All",
    val stage: String = "All",
    val instrument: String = "All",
    val onlyVerified: Boolean = false
  )

  private val _investmentCriteria = combine(
    _investmentSearchQuery,
    _selectedIndustry,
    _selectedStage,
    _selectedInstrument,
    _onlyVerifiedOpportunities
  ) { query, industry, stage, instrument, onlyVerified ->
    InvestmentFilterCriteria(query, industry, stage, instrument, onlyVerified)
  }

  val filteredOpportunities: StateFlow<List<CatchyInvestmentOpportunity>> = combine(
    rawActiveOpportunities,
    _investmentCriteria
  ) { opportunities, criteria ->
    opportunities.filter { opp ->
      val matchesQuery = criteria.query.isBlank() ||
        opp.companyName.contains(criteria.query, ignoreCase = true) ||
        opp.tagline.contains(criteria.query, ignoreCase = true) ||
        opp.pitchSummary.contains(criteria.query, ignoreCase = true) ||
        opp.location.contains(criteria.query, ignoreCase = true) ||
        opp.tractionAndMetrics.contains(criteria.query, ignoreCase = true)

      val matchesIndustry = criteria.industry == "All" || opp.industry.equals(criteria.industry, ignoreCase = true)
      val matchesStage = criteria.stage == "All" || opp.stage.equals(criteria.stage, ignoreCase = true)
      val matchesInstrument = criteria.instrument == "All" || opp.instrumentType.equals(criteria.instrument, ignoreCase = true)
      val matchesVerified = !criteria.onlyVerified || opp.isVerified

      matchesQuery && matchesIndustry && matchesStage && matchesInstrument && matchesVerified
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myOpportunities: StateFlow<List<CatchyInvestmentOpportunity>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeOpportunitiesByCreator(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val investorSentRequests: StateFlow<List<CatchyInvestmentRequest>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeInvestorRequests(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val founderReceivedRequests: StateFlow<List<CatchyInvestmentRequest>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFounderRequests(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val investorProfile: StateFlow<CatchyInvestorProfile?> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeInvestorProfile(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, null)

  @OptIn(ExperimentalCoroutinesApi::class)
  val founderProfile: StateFlow<CatchyFounderProfile?> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFounderProfile(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, null)

  // Modals & Selection
  private val _selectedOpportunity = MutableStateFlow<CatchyInvestmentOpportunity?>(null)
  val selectedOpportunity: StateFlow<CatchyInvestmentOpportunity?> = _selectedOpportunity.asStateFlow()

  private val _requestingOpportunity = MutableStateFlow<CatchyInvestmentOpportunity?>(null)
  val requestingOpportunity: StateFlow<CatchyInvestmentOpportunity?> = _requestingOpportunity.asStateFlow()

  private val _isSubmittingInvestmentRequest = MutableStateFlow(false)
  val isSubmittingInvestmentRequest: StateFlow<Boolean> = _isSubmittingInvestmentRequest.asStateFlow()

  private val _investmentFeedbackMessage = MutableStateFlow<String?>(null)
  val investmentFeedbackMessage: StateFlow<String?> = _investmentFeedbackMessage.asStateFlow()

  private val _isOpportunityEditorVisible = MutableStateFlow(false)
  val isOpportunityEditorVisible: StateFlow<Boolean> = _isOpportunityEditorVisible.asStateFlow()

  private val _editingOpportunity = MutableStateFlow<CatchyInvestmentOpportunity?>(null)
  val editingOpportunity: StateFlow<CatchyInvestmentOpportunity?> = _editingOpportunity.asStateFlow()

  private val _isSavingOpportunity = MutableStateFlow(false)
  val isSavingOpportunity: StateFlow<Boolean> = _isSavingOpportunity.asStateFlow()

  private val _opportunityFormError = MutableStateFlow<String?>(null)
  val opportunityFormError: StateFlow<String?> = _opportunityFormError.asStateFlow()

  fun openInvestmentCenter(initialTab: CatchyInvestmentTab = CatchyInvestmentTab.EXPLORE) {
    _investmentTab.value = initialTab
    _showInvestmentScreen.value = true
  }

  fun closeInvestmentCenter() {
    _showInvestmentScreen.value = false
    _selectedOpportunity.value = null
    _requestingOpportunity.value = null
    _isOpportunityEditorVisible.value = false
    _editingOpportunity.value = null
    _investmentFeedbackMessage.value = null
  }

  fun setInvestmentTab(tab: CatchyInvestmentTab) {
    _investmentTab.value = tab
    _selectedOpportunity.value = null
  }

  fun setInvestmentSearchQuery(query: String) {
    _investmentSearchQuery.value = query
  }

  fun setSelectedIndustry(industry: String) {
    _selectedIndustry.value = industry
  }

  fun setSelectedStage(stage: String) {
    _selectedStage.value = stage
  }

  fun setSelectedInstrument(instrument: String) {
    _selectedInstrument.value = instrument
  }

  fun setOnlyVerifiedOpportunities(verified: Boolean) {
    _onlyVerifiedOpportunities.value = verified
  }

  fun selectOpportunity(opportunity: CatchyInvestmentOpportunity?) {
    _selectedOpportunity.value = opportunity
  }

  fun openRequestInvestmentDialog(opportunity: CatchyInvestmentOpportunity) {
    _requestingOpportunity.value = opportunity
    _investmentFeedbackMessage.value = null
  }

  fun closeRequestInvestmentDialog() {
    _requestingOpportunity.value = null
    _investmentFeedbackMessage.value = null
    _isSubmittingInvestmentRequest.value = false
  }

  fun submitInvestmentRequest(
    proposedAmount: String,
    messageNote: String,
    termsOrInquiry: String
  ) {
    val opp = _requestingOpportunity.value ?: return
    viewModelScope.launch {
      _isSubmittingInvestmentRequest.value = true
      val result = repository.submitInvestmentRequest(
        opportunityId = opp.opportunityId,
        proposedAmount = proposedAmount,
        messageNote = messageNote,
        termsOrInquiry = termsOrInquiry
      )
      _isSubmittingInvestmentRequest.value = false
      result.fold(
        onSuccess = {
          _investmentFeedbackMessage.value = "Investment interest submitted to ${opp.companyName}!"
          _requestingOpportunity.value = null
        },
        onFailure = { error ->
          _investmentFeedbackMessage.value = error.localizedMessage ?: "Failed to submit investment interest."
        }
      )
    }
  }

  fun clearInvestmentFeedback() {
    _investmentFeedbackMessage.value = null
  }

  fun openCreateOpportunityDialog() {
    _editingOpportunity.value = null
    _opportunityFormError.value = null
    _isOpportunityEditorVisible.value = true
  }

  fun openEditOpportunityDialog(opportunity: CatchyInvestmentOpportunity) {
    _editingOpportunity.value = opportunity
    _opportunityFormError.value = null
    _isOpportunityEditorVisible.value = true
  }

  fun closeOpportunityEditorDialog() {
    _isOpportunityEditorVisible.value = false
    _editingOpportunity.value = null
    _opportunityFormError.value = null
    _isSavingOpportunity.value = false
  }

  fun saveInvestmentOpportunity(
    companyName: String,
    tagline: String,
    industry: String,
    stage: String,
    targetAmount: String,
    raisedSoFar: String,
    instrumentType: String,
    equityOffered: String,
    minTicket: String,
    location: String,
    pitchSummary: String,
    tractionAndMetrics: String,
    useOfFunds: String,
    pitchDeckUrl: String,
    status: String = "ACTIVE",
    privacyLevel: String = "PUBLIC"
  ) {
    val editing = _editingOpportunity.value
    viewModelScope.launch {
      _isSavingOpportunity.value = true
      _opportunityFormError.value = null
      val result = if (editing != null) {
        repository.updateInvestmentOpportunity(
          opportunityId = editing.opportunityId,
          companyName = companyName,
          tagline = tagline,
          industry = industry,
          stage = stage,
          targetAmount = targetAmount,
          raisedSoFar = raisedSoFar,
          instrumentType = instrumentType,
          equityOffered = equityOffered,
          minTicket = minTicket,
          location = location,
          pitchSummary = pitchSummary,
          tractionAndMetrics = tractionAndMetrics,
          useOfFunds = useOfFunds,
          pitchDeckUrl = pitchDeckUrl,
          status = status,
          privacyLevel = privacyLevel
        )
      } else {
        repository.createInvestmentOpportunity(
          companyName = companyName,
          tagline = tagline,
          industry = industry,
          stage = stage,
          targetAmount = targetAmount,
          raisedSoFar = raisedSoFar,
          instrumentType = instrumentType,
          equityOffered = equityOffered,
          minTicket = minTicket,
          location = location,
          pitchSummary = pitchSummary,
          tractionAndMetrics = tractionAndMetrics,
          useOfFunds = useOfFunds,
          pitchDeckUrl = pitchDeckUrl,
          privacyLevel = privacyLevel
        )
      }
      _isSavingOpportunity.value = false
      result.fold(
        onSuccess = {
          _isOpportunityEditorVisible.value = false
          _editingOpportunity.value = null
        },
        onFailure = { error ->
          _opportunityFormError.value = error.localizedMessage ?: "Failed to save investment opportunity."
        }
      )
    }
  }

  fun closeInvestmentOpportunity(opportunityId: String) {
    viewModelScope.launch {
      repository.closeInvestmentOpportunity(opportunityId)
    }
  }

  fun deleteInvestmentOpportunity(opportunityId: String) {
    viewModelScope.launch {
      repository.deleteInvestmentOpportunity(opportunityId)
      if (_selectedOpportunity.value?.opportunityId == opportunityId) {
        _selectedOpportunity.value = null
      }
    }
  }

  fun updateInvestmentRequestStatus(requestId: String, newStatus: String) {
    viewModelScope.launch {
      repository.updateInvestmentRequestStatus(requestId, newStatus)
    }
  }

  fun saveInvestorProfile(
    investorType: String,
    ticketSizeRange: String,
    preferredIndustries: String,
    preferredStages: String,
    investmentGeography: String,
    portfolioSummary: String,
    bio: String,
    isAccredited: Boolean,
    isPubliclyDiscoverable: Boolean
  ) {
    val user = currentUser.value ?: return
    viewModelScope.launch {
      val profile = CatchyInvestorProfile(
        userId = user.userId,
        investorName = user.fullName,
        investorType = investorType.trim(),
        ticketSizeRange = ticketSizeRange.trim(),
        preferredIndustries = preferredIndustries.trim(),
        preferredStages = preferredStages.trim(),
        investmentGeography = investmentGeography.trim(),
        portfolioSummary = portfolioSummary.trim(),
        bio = bio.trim(),
        isAccredited = isAccredited,
        isPubliclyDiscoverable = isPubliclyDiscoverable,
        updatedAt = System.currentTimeMillis()
      )
      repository.saveInvestorProfile(profile)
    }
  }

  fun saveFounderProfile(
    ventureName: String,
    legalEntityStatus: String,
    industry: String,
    stage: String,
    headquarters: String,
    websiteUrl: String,
    elevatorPitch: String,
    teamOverview: String,
    isVerifiedVenture: Boolean
  ) {
    val user = currentUser.value ?: return
    viewModelScope.launch {
      val profile = CatchyFounderProfile(
        userId = user.userId,
        founderName = user.fullName,
        ventureName = ventureName.trim(),
        legalEntityStatus = legalEntityStatus.trim(),
        industry = industry.trim(),
        stage = stage.trim(),
        headquarters = headquarters.trim(),
        websiteUrl = websiteUrl.trim(),
        elevatorPitch = elevatorPitch.trim(),
        teamOverview = teamOverview.trim(),
        isVerifiedVenture = isVerifiedVenture,
        updatedAt = System.currentTimeMillis()
      )
      repository.saveFounderProfile(profile)
    }
  }

  fun messageInvestmentContact(targetUserId: String, targetUserName: String, initialContextMessage: String? = null) {
    viewModelScope.launch {
      val targetUser = repository.getUserByUserId(targetUserId) ?: UserAccount(
        userId = targetUserId,
        email = "$targetUserId@catchy.com",
        dateOfBirth = "2000-01-01",
        gender = "Not specified",
        addressLocation = "Global",
        educationStatus = "Professional",
        occupationStatus = "Catchy Member",
        skills = "Networking",
        maritalStatus = "Single",
        fullName = targetUserName,
        passwordHash = "",
        passwordSalt = ""
      )
      _showInvestmentScreen.value = false
      _selectedOpportunity.value = null
      _requestingOpportunity.value = null
      openChatWithUser(targetUser)
      if (!initialContextMessage.isNullOrBlank()) {
        _chatMessageInput.value = initialContextMessage
      }
    }
  }

  // ==========================================
  // Catchy Business / Business Page Systems
  // ==========================================
  private val _showBusinessScreen = MutableStateFlow(false)
  val showBusinessScreen: StateFlow<Boolean> = _showBusinessScreen.asStateFlow()

  private val _businessTab = MutableStateFlow(CatchyBusinessTab.EXPLORE)
  val businessTab: StateFlow<CatchyBusinessTab> = _businessTab.asStateFlow()

  private val _businessSearchQuery = MutableStateFlow("")
  val businessSearchQuery: StateFlow<String> = _businessSearchQuery.asStateFlow()

  private val _selectedBusinessCategory = MutableStateFlow("All")
  val selectedBusinessCategory: StateFlow<String> = _selectedBusinessCategory.asStateFlow()

  val rawActiveBusinessPages: StateFlow<List<CatchyBusinessPage>> = repository.observeActiveBusinessPages()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val filteredBusinessPages: StateFlow<List<CatchyBusinessPage>> = combine(
    rawActiveBusinessPages,
    _businessSearchQuery,
    _selectedBusinessCategory
  ) { pages, query, category ->
    pages.filter { page ->
      val matchesQuery = query.isBlank() ||
        page.name.contains(query, ignoreCase = true) ||
        page.handle.contains(query, ignoreCase = true) ||
        page.tagline.contains(query, ignoreCase = true) ||
        page.description.contains(query, ignoreCase = true) ||
        page.location.contains(query, ignoreCase = true)

      val matchesCategory = category == "All" || page.category.equals(category, ignoreCase = true)

      matchesQuery && matchesCategory
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myBusinessPages: StateFlow<List<CatchyBusinessPage>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeBusinessPagesByOwner(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myFollowedPages: StateFlow<List<CatchyBusinessPage>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeFollowedBusinessPages(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _selectedBusinessPage = MutableStateFlow<CatchyBusinessPage?>(null)
  val selectedBusinessPage: StateFlow<CatchyBusinessPage?> = _selectedBusinessPage.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val pagePosts: StateFlow<List<CatchyBusinessPost>> = _selectedBusinessPage
    .flatMapLatest { page ->
      if (page != null) repository.observePostsByBusinessPage(page.pageId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val isFollowingSelectedPage: StateFlow<Boolean> = combine(
    _selectedBusinessPage,
    currentUser
  ) { page, user ->
    Pair(page, user)
  }.flatMapLatest { (page, user) ->
    if (page != null && user != null) {
      repository.isUserFollowingBusinessPage(page.pageId, user.userId)
    } else {
      emptyFlow()
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, false)

  @OptIn(ExperimentalCoroutinesApi::class)
  val myReceivedInquiries: StateFlow<List<CatchyBusinessInquiry>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeInquiriesForOwner(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _isPageEditorVisible = MutableStateFlow(false)
  val isPageEditorVisible: StateFlow<Boolean> = _isPageEditorVisible.asStateFlow()

  private val _editingPage = MutableStateFlow<CatchyBusinessPage?>(null)
  val editingPage: StateFlow<CatchyBusinessPage?> = _editingPage.asStateFlow()

  private val _inquiryTargetPage = MutableStateFlow<CatchyBusinessPage?>(null)
  val inquiryTargetPage: StateFlow<CatchyBusinessPage?> = _inquiryTargetPage.asStateFlow()

  private val _businessFormError = MutableStateFlow<String?>(null)
  val businessFormError: StateFlow<String?> = _businessFormError.asStateFlow()

  private val _isSavingBusinessPage = MutableStateFlow(false)
  val isSavingBusinessPage: StateFlow<Boolean> = _isSavingBusinessPage.asStateFlow()

  private val _businessFeedbackMessage = MutableStateFlow<String?>(null)
  val businessFeedbackMessage: StateFlow<String?> = _businessFeedbackMessage.asStateFlow()

  fun openBusinessCenter() {
    _showBusinessScreen.value = true
  }

  fun closeBusinessCenter() {
    _showBusinessScreen.value = false
    _selectedBusinessPage.value = null
    _inquiryTargetPage.value = null
    _isPageEditorVisible.value = false
    _businessFeedbackMessage.value = null
    _businessFormError.value = null
  }

  fun setBusinessTab(tab: CatchyBusinessTab) {
    _businessTab.value = tab
  }

  fun setBusinessSearchQuery(query: String) {
    _businessSearchQuery.value = query
  }

  fun setSelectedBusinessCategory(category: String) {
    _selectedBusinessCategory.value = category
  }

  fun selectBusinessPage(page: CatchyBusinessPage?) {
    _selectedBusinessPage.value = page
  }

  fun openCreateBusinessPageDialog() {
    _editingPage.value = null
    _businessFormError.value = null
    _isPageEditorVisible.value = true
  }

  fun openEditBusinessPageDialog(page: CatchyBusinessPage) {
    _editingPage.value = page
    _businessFormError.value = null
    _isPageEditorVisible.value = true
  }

  fun closeBusinessPageEditorDialog() {
    _isPageEditorVisible.value = false
    _editingPage.value = null
    _businessFormError.value = null
  }

  fun openSendInquiryDialog(page: CatchyBusinessPage) {
    _inquiryTargetPage.value = page
    _businessFeedbackMessage.value = null
  }

  fun closeSendInquiryDialog() {
    _inquiryTargetPage.value = null
    _businessFeedbackMessage.value = null
  }

  fun saveBusinessPage(
    name: String,
    handle: String,
    category: String,
    tagline: String,
    description: String,
    email: String,
    phone: String,
    website: String,
    location: String,
    operatingHours: String
  ) {
    if (name.isBlank()) {
      _businessFormError.value = "Business name cannot be empty."
      return
    }
    viewModelScope.launch {
      _isSavingBusinessPage.value = true
      _businessFormError.value = null

      val currentEditing = _editingPage.value
      val result = if (currentEditing != null) {
        val updated = currentEditing.copy(
          name = name.trim(),
          handle = if (handle.startsWith("@")) handle.trim() else "@${handle.trim()}",
          category = category.trim(),
          tagline = tagline.trim(),
          description = description.trim(),
          email = email.trim(),
          phone = phone.trim(),
          website = website.trim(),
          location = location.trim(),
          operatingHours = operatingHours.trim()
        )
        repository.updateBusinessPage(updated)
      } else {
        repository.createBusinessPage(
          name = name,
          handle = handle,
          category = category,
          tagline = tagline,
          description = description,
          email = email,
          phone = phone,
          website = website,
          location = location,
          operatingHours = operatingHours
        )
      }

      _isSavingBusinessPage.value = false
      if (result.isSuccess) {
        _isPageEditorVisible.value = false
        _editingPage.value = null
        val page = result.getOrNull()
        if (_selectedBusinessPage.value?.pageId == page?.pageId) {
          _selectedBusinessPage.value = page
        }
      } else {
        _businessFormError.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to save business page."
      }
    }
  }

  fun deleteBusinessPage(pageId: String) {
    viewModelScope.launch {
      repository.deleteBusinessPage(pageId)
      if (_selectedBusinessPage.value?.pageId == pageId) {
        _selectedBusinessPage.value = null
      }
    }
  }

  fun toggleFollowPage(pageId: String) {
    viewModelScope.launch {
      repository.toggleFollowBusinessPage(pageId)
      val updated = repository.getBusinessPageById(pageId)
      if (_selectedBusinessPage.value?.pageId == pageId && updated != null) {
        _selectedBusinessPage.value = updated
      }
    }
  }

  fun createBusinessPost(pageId: String, content: String, mediaUrl: String = "") {
    if (content.isBlank()) return
    viewModelScope.launch {
      repository.createBusinessPost(pageId, content, mediaUrl)
    }
  }

  fun deleteBusinessPost(pageId: String, postId: String) {
    viewModelScope.launch {
      repository.deleteBusinessPost(pageId, postId)
    }
  }

  fun submitBusinessInquiry(subject: String, message: String) {
    val target = _inquiryTargetPage.value ?: return
    viewModelScope.launch {
      val result = repository.submitBusinessInquiry(
        pageId = target.pageId,
        subject = subject,
        message = message
      )
      if (result.isSuccess) {
        _businessFeedbackMessage.value = "Inquiry sent successfully to ${target.name}!"
      } else {
        _businessFeedbackMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send inquiry."
      }
    }
  }

  fun updateInquiryStatus(inquiryId: String, status: String) {
    viewModelScope.launch {
      repository.updateInquiryStatus(inquiryId, status)
    }
  }

  fun deleteInquiry(inquiryId: String) {
    viewModelScope.launch {
      repository.deleteInquiry(inquiryId)
    }
  }

  fun messageBusinessContact(targetUserId: String, targetUserName: String, initialContextMessage: String? = null) {
    viewModelScope.launch {
      val targetUser = repository.getUserByUserId(targetUserId) ?: UserAccount(
        userId = targetUserId,
        email = "$targetUserId@catchy.com",
        dateOfBirth = "2000-01-01",
        gender = "Not specified",
        addressLocation = "Global",
        educationStatus = "Professional",
        occupationStatus = "Catchy Member",
        skills = "Business",
        maritalStatus = "Single",
        fullName = targetUserName,
        passwordHash = "",
        passwordSalt = ""
      )
      _showBusinessScreen.value = false
      _selectedBusinessPage.value = null
      _inquiryTargetPage.value = null
      openChatWithUser(targetUser)
      if (!initialContextMessage.isNullOrBlank()) {
        _chatMessageInput.value = initialContextMessage
      }
    }
  }

  // ==========================================
  // Catchy Community System
  // ==========================================
  private val _showCommunityScreen = MutableStateFlow(false)
  val showCommunityScreen: StateFlow<Boolean> = _showCommunityScreen.asStateFlow()

  private val _communityTab = MutableStateFlow(CatchyCommunityTab.EXPLORE)
  val communityTab: StateFlow<CatchyCommunityTab> = _communityTab.asStateFlow()

  private val _communitySearchQuery = MutableStateFlow("")
  val communitySearchQuery: StateFlow<String> = _communitySearchQuery.asStateFlow()

  private val _selectedCommunityCategory = MutableStateFlow("All")
  val selectedCommunityCategory: StateFlow<String> = _selectedCommunityCategory.asStateFlow()

  val rawCommunities: StateFlow<List<CatchyCommunity>> = repository.observeAllCommunities()
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val filteredCommunities: StateFlow<List<CatchyCommunity>> = combine(
    rawCommunities,
    _communitySearchQuery,
    _selectedCommunityCategory
  ) { communities, query, category ->
    communities.filter { community ->
      val matchesQuery = query.isBlank() ||
        community.name.contains(query, ignoreCase = true) ||
        community.description.contains(query, ignoreCase = true) ||
        community.category.contains(query, ignoreCase = true) ||
        community.creatorName.contains(query, ignoreCase = true)

      val matchesCategory = category == "All" || community.category.equals(category, ignoreCase = true)

      matchesQuery && matchesCategory
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val myJoinedCommunities: StateFlow<List<CatchyCommunity>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.observeCommunitiesJoinedByUser(user.userId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _selectedCommunity = MutableStateFlow<CatchyCommunity?>(null)
  val selectedCommunity: StateFlow<CatchyCommunity?> = _selectedCommunity.asStateFlow()

  private val _communityDetailTab = MutableStateFlow(CommunityDetailTab.POSTS)
  val communityDetailTab: StateFlow<CommunityDetailTab> = _communityDetailTab.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val communityMembers: StateFlow<List<CatchyCommunityMember>> = _selectedCommunity
    .flatMapLatest { comm ->
      if (comm != null) repository.observeCommunityMembers(comm.id) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  @OptIn(ExperimentalCoroutinesApi::class)
  val isCurrentUserCommunityMember: StateFlow<Boolean> = combine(
    _selectedCommunity,
    currentUser
  ) { comm, user ->
    Pair(comm, user)
  }.flatMapLatest { (comm, user) ->
    if (comm != null && user != null) {
      repository.observeIsCommunityMember(comm.id, user.userId)
    } else {
      emptyFlow()
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, false)

  val currentUserRoleInSelectedCommunity: StateFlow<String?> = combine(
    communityMembers,
    currentUser
  ) { members, user ->
    if (user == null) null
    else members.find { it.userId == user.userId }?.role
  }.stateIn(viewModelScope, SharingStarted.Lazily, null)

  @OptIn(ExperimentalCoroutinesApi::class)
  val communityPosts: StateFlow<List<CatchyCommunityPost>> = _selectedCommunity
    .flatMapLatest { comm ->
      if (comm != null) repository.observeCommunityPosts(comm.id) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _isCommunityEditorVisible = MutableStateFlow(false)
  val isCommunityEditorVisible: StateFlow<Boolean> = _isCommunityEditorVisible.asStateFlow()

  private val _editingCommunity = MutableStateFlow<CatchyCommunity?>(null)
  val editingCommunity: StateFlow<CatchyCommunity?> = _editingCommunity.asStateFlow()

  private val _communityFormError = MutableStateFlow<String?>(null)
  val communityFormError: StateFlow<String?> = _communityFormError.asStateFlow()

  private val _isSavingCommunity = MutableStateFlow(false)
  val isSavingCommunity: StateFlow<Boolean> = _isSavingCommunity.asStateFlow()

  private val _communityFeedbackMessage = MutableStateFlow<String?>(null)
  val communityFeedbackMessage: StateFlow<String?> = _communityFeedbackMessage.asStateFlow()

  // Community Post Editor
  private val _isCommunityPostEditorVisible = MutableStateFlow(false)
  val isCommunityPostEditorVisible: StateFlow<Boolean> = _isCommunityPostEditorVisible.asStateFlow()

  private val _editingCommunityPost = MutableStateFlow<CatchyCommunityPost?>(null)
  val editingCommunityPost: StateFlow<CatchyCommunityPost?> = _editingCommunityPost.asStateFlow()

  private val _isSavingCommunityPost = MutableStateFlow(false)
  val isSavingCommunityPost: StateFlow<Boolean> = _isSavingCommunityPost.asStateFlow()

  private val _communityPostFormError = MutableStateFlow<String?>(null)
  val communityPostFormError: StateFlow<String?> = _communityPostFormError.asStateFlow()

  // Post Comments
  private val _activeCommunityPostCommentsId = MutableStateFlow<String?>(null)
  val activeCommunityPostCommentsId: StateFlow<String?> = _activeCommunityPostCommentsId.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val activeCommunityPostComments: StateFlow<List<CatchyCommunityPostComment>> = _activeCommunityPostCommentsId
    .flatMapLatest { postId ->
      if (postId != null) repository.observeCommunityPostComments(postId) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  // Moderation & Safety Reports
  private val _reportingCommunityItem = MutableStateFlow<Pair<String, String>?>(null) // Pair(targetType, targetId)
  val reportingCommunityItem: StateFlow<Pair<String, String>?> = _reportingCommunityItem.asStateFlow()

  private val _communityReportReason = MutableStateFlow("")
  val communityReportReason: StateFlow<String> = _communityReportReason.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val communityReports: StateFlow<List<CatchyCommunityReport>> = _selectedCommunity
    .flatMapLatest { comm ->
      if (comm != null) repository.observeCommunityReports(comm.id) else emptyFlow()
    }
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  fun openCommunityCenter() {
    _showCommunityScreen.value = true
  }

  fun closeCommunityCenter() {
    _showCommunityScreen.value = false
    _selectedCommunity.value = null
    _isCommunityEditorVisible.value = false
    _isCommunityPostEditorVisible.value = false
    _activeCommunityPostCommentsId.value = null
    _reportingCommunityItem.value = null
    _communityFeedbackMessage.value = null
  }

  fun selectCommunity(community: CatchyCommunity?) {
    _selectedCommunity.value = community
    _communityDetailTab.value = CommunityDetailTab.POSTS
    _activeCommunityPostCommentsId.value = null
  }

  fun setCommunityTab(tab: CatchyCommunityTab) {
    _communityTab.value = tab
  }

  fun setCommunityDetailTab(tab: CommunityDetailTab) {
    _communityDetailTab.value = tab
  }

  fun setCommunitySearchQuery(query: String) {
    _communitySearchQuery.value = query
  }

  fun setSelectedCommunityCategory(category: String) {
    _selectedCommunityCategory.value = category
  }

  fun showCreateCommunityDialog() {
    _editingCommunity.value = null
    _communityFormError.value = null
    _isCommunityEditorVisible.value = true
  }

  fun showEditCommunityDialog(community: CatchyCommunity) {
    _editingCommunity.value = community
    _communityFormError.value = null
    _isCommunityEditorVisible.value = true
  }

  fun hideCommunityEditor() {
    _isCommunityEditorVisible.value = false
    _editingCommunity.value = null
    _communityFormError.value = null
  }

  fun saveCommunity(
    name: String,
    description: String,
    photo: String,
    category: String,
    isPrivate: Boolean,
    coverGradientIndex: Int
  ) {
    viewModelScope.launch {
      _isSavingCommunity.value = true
      _communityFormError.value = null
      val editing = _editingCommunity.value
      val result = if (editing == null) {
        repository.createCommunity(
          name = name,
          description = description,
          photo = photo,
          category = category,
          isPrivate = isPrivate,
          coverGradientIndex = coverGradientIndex
        )
      } else {
        repository.updateCommunitySettings(
          communityId = editing.id,
          name = name,
          description = description,
          photo = photo,
          category = category,
          isPrivate = isPrivate,
          coverGradientIndex = coverGradientIndex
        )
      }

      _isSavingCommunity.value = false
      result.fold(
        onSuccess = { savedCommunity ->
          _isCommunityEditorVisible.value = false
          _editingCommunity.value = null
          _selectedCommunity.value = savedCommunity
          _communityFeedbackMessage.value = if (editing == null) "Community created successfully!" else "Community settings updated!"
        },
        onFailure = { error ->
          _communityFormError.value = error.message ?: "Failed to save community."
        }
      )
    }
  }

  fun deleteCommunity(communityId: String) {
    viewModelScope.launch {
      val result = repository.deleteCommunity(communityId)
      result.fold(
        onSuccess = {
          _selectedCommunity.value = null
          _communityFeedbackMessage.value = "Community deleted."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to delete community."
        }
      )
    }
  }

  fun joinCommunity(communityId: String) {
    viewModelScope.launch {
      val result = repository.joinCommunity(communityId)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "Welcome to the community!"
          // Refresh selected community if open
          val updated = repository.getCommunityById(communityId)
          if (updated != null && _selectedCommunity.value?.id == communityId) {
            _selectedCommunity.value = updated
          }
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to join community."
        }
      )
    }
  }

  fun leaveCommunity(communityId: String) {
    viewModelScope.launch {
      val result = repository.leaveCommunity(communityId)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "You left the community."
          val updated = repository.getCommunityById(communityId)
          if (updated != null && _selectedCommunity.value?.id == communityId) {
            _selectedCommunity.value = updated
          }
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to leave community."
        }
      )
    }
  }

  // --- Community Post Actions ---
  fun showCreateCommunityPostDialog() {
    _editingCommunityPost.value = null
    _communityPostFormError.value = null
    _isCommunityPostEditorVisible.value = true
  }

  fun showEditCommunityPostDialog(post: CatchyCommunityPost) {
    _editingCommunityPost.value = post
    _communityPostFormError.value = null
    _isCommunityPostEditorVisible.value = true
  }

  fun hideCommunityPostEditor() {
    _isCommunityPostEditorVisible.value = false
    _editingCommunityPost.value = null
    _communityPostFormError.value = null
  }

  fun saveCommunityPost(
    content: String,
    mediaUrl: String = "",
    mediaType: String? = null,
    mediaLabel: String? = null
  ) {
    val community = _selectedCommunity.value ?: return
    viewModelScope.launch {
      _isSavingCommunityPost.value = true
      _communityPostFormError.value = null
      val editing = _editingCommunityPost.value
      val result = if (editing == null) {
        repository.createCommunityPost(
          communityId = community.id,
          content = content,
          mediaUrl = mediaUrl,
          mediaType = mediaType,
          mediaLabel = mediaLabel
        )
      } else {
        repository.updateCommunityPost(
          postId = editing.postId,
          content = content,
          mediaUrl = mediaUrl,
          mediaType = mediaType,
          mediaLabel = mediaLabel
        )
      }

      _isSavingCommunityPost.value = false
      result.fold(
        onSuccess = {
          _isCommunityPostEditorVisible.value = false
          _editingCommunityPost.value = null
          _communityFeedbackMessage.value = if (editing == null) "Post shared with community!" else "Post updated!"
        },
        onFailure = { error ->
          _communityPostFormError.value = error.message ?: "Failed to save post."
        }
      )
    }
  }

  fun deleteCommunityPost(postId: String) {
    viewModelScope.launch {
      val result = repository.deleteCommunityPost(postId)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "Post deleted."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to delete post."
        }
      )
    }
  }

  fun toggleCommunityPostPin(postId: String) {
    viewModelScope.launch {
      val result = repository.toggleCommunityPostPin(postId)
      result.fold(
        onSuccess = { isPinned ->
          _communityFeedbackMessage.value = if (isPinned) "Post pinned to top!" else "Post unpinned."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Action not allowed."
        }
      )
    }
  }

  fun toggleCommunityPostLike(postId: String) {
    viewModelScope.launch {
      repository.toggleCommunityPostLike(postId)
    }
  }

  fun openCommunityPostComments(postId: String) {
    _activeCommunityPostCommentsId.value = postId
  }

  fun closeCommunityPostComments() {
    _activeCommunityPostCommentsId.value = null
  }

  fun addCommunityPostComment(postId: String, content: String, parentCommentId: String? = null) {
    val community = _selectedCommunity.value ?: return
    viewModelScope.launch {
      val result = repository.addCommunityPostComment(postId, community.id, content, parentCommentId)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "Comment added."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to comment."
        }
      )
    }
  }

  fun deleteCommunityPostComment(postId: String, commentId: String) {
    viewModelScope.launch {
      repository.deleteCommunityPostComment(postId, commentId)
    }
  }

  fun shareCommunityPost(post: CatchyCommunityPost) {
    viewModelScope.launch {
      repository.shareCommunityPost(post.postId)
      _communityFeedbackMessage.value = "Post link ready to share!"
    }
  }

  // --- Member Management & Safety ---
  fun removeCommunityMember(memberUserId: String) {
    val comm = _selectedCommunity.value ?: return
    viewModelScope.launch {
      val result = repository.removeCommunityMember(comm.id, memberUserId)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "Member removed."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to remove member."
        }
      )
    }
  }

  fun updateMemberRole(memberUserId: String, newRole: String) {
    val comm = _selectedCommunity.value ?: return
    viewModelScope.launch {
      val result = repository.updateMemberRole(comm.id, memberUserId, newRole)
      result.fold(
        onSuccess = {
          _communityFeedbackMessage.value = "Member role updated to $newRole."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to update role."
        }
      )
    }
  }

  fun openCommunityReportDialog(targetType: String, targetId: String) {
    _reportingCommunityItem.value = Pair(targetType, targetId)
    _communityReportReason.value = ""
  }

  fun closeCommunityReportDialog() {
    _reportingCommunityItem.value = null
    _communityReportReason.value = ""
  }

  fun setCommunityReportReason(reason: String) {
    _communityReportReason.value = reason
  }

  fun submitCommunityReport() {
    val target = _reportingCommunityItem.value ?: return
    val comm = _selectedCommunity.value ?: return
    val reason = _communityReportReason.value
    viewModelScope.launch {
      val result = repository.reportCommunityItem(
        communityId = comm.id,
        targetType = target.first,
        targetId = target.second,
        reason = reason
      )
      result.fold(
        onSuccess = {
          _reportingCommunityItem.value = null
          _communityReportReason.value = ""
          _communityFeedbackMessage.value = "Report submitted. Thank you for keeping Catchy safe."
        },
        onFailure = { error ->
          _communityFeedbackMessage.value = error.message ?: "Failed to submit report."
        }
      )
    }
  }

  fun clearCommunityFeedbackMessage() {
    _communityFeedbackMessage.value = null
  }

  fun openChatWithCommunityMember(
    targetUserId: String,
    targetUserName: String,
    targetAvatar: String?,
    initialContextMessage: String? = null
  ) {
    viewModelScope.launch {
      val existingUser = repository.getUserByUserId(targetUserId)
      val targetUser = existingUser ?: UserAccount(
        userId = targetUserId,
        email = "$targetUserId@catchy.community",
        bio = "Catchy Community Member",
        profilePhotoUri = targetAvatar ?: "avatar_1",
        dateOfBirth = "1995-01-01",
        gender = "Other",
        addressLocation = "Catchy Community",
        educationStatus = "Member",
        occupationStatus = "Catchy Member",
        skills = "Community",
        maritalStatus = "Single",
        fullName = targetUserName,
        passwordHash = "",
        passwordSalt = ""
      )
      _showCommunityScreen.value = false
      _selectedCommunity.value = null
      openChatWithUser(targetUser)
      if (!initialContextMessage.isNullOrBlank()) {
        _chatMessageInput.value = initialContextMessage
      }
    }
  }

  fun openCommunityMemberProfile(
    targetUserId: String,
    targetUserName: String,
    targetAvatar: String?
  ) {
    viewModelScope.launch {
      val existingUser = repository.getUserByUserId(targetUserId)
      val targetUser = existingUser ?: UserAccount(
        userId = targetUserId,
        email = "$targetUserId@catchy.community",
        bio = "Catchy Community Member",
        profilePhotoUri = targetAvatar ?: "avatar_1",
        dateOfBirth = "1995-01-01",
        gender = "Other",
        addressLocation = "Catchy Community",
        educationStatus = "Member",
        occupationStatus = "Catchy Member",
        skills = "Community",
        maritalStatus = "Single",
        fullName = targetUserName,
        passwordHash = "",
        passwordSalt = ""
      )
      _showCommunityScreen.value = false
      openUserProfile(targetUser)
    }
  }

  fun signOut() {
    repository.clearSession()
    _currentTab.value = CatchyNavTab.HOME
    _viewingOtherUser.value = null
    _activeChatUser.value = null
    _currentScreen.value = CatchyScreen.LOGIN
  }

  fun logout() = signOut()
}
