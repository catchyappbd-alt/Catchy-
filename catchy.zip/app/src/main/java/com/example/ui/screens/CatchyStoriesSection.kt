package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyStory
import com.example.data.model.UserAccount
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoDark
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchyViolet
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Predefined vibrant story gradient themes
val storyGradients = listOf(
  listOf(Color(0xFF6366F1), Color(0xFF06B6D4)), // Indigo to Cyan
  listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)), // Violet to Pink
  listOf(Color(0xFF0EA5E9), Color(0xFF10B981)), // Sky to Emerald
  listOf(Color(0xFFF59E0B), Color(0xFFEF4444)), // Amber to Crimson
  listOf(Color(0xFF1E1B4B), Color(0xFF312E81))  // Deep Midnight
)

/**
 * Stories Carousel near the top of the Home feed.
 * Includes "Add Story" (+) tile followed by friends' and community stories.
 */
@Composable
fun CatchyStoriesSection(
  currentUser: UserAccount?,
  stories: List<CatchyStory>,
  onAddStoryClick: () -> Unit,
  onStoryClick: (CatchyStory) -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
    modifier = modifier
      .fillMaxWidth()
      .testTag("catchy_stories_section")
  ) {
    Column(modifier = Modifier.padding(vertical = 6.dp, horizontal = 10.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 2.dp, vertical = 1.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Stories",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.2.sp
            ),
            color = MaterialTheme.colorScheme.onBackground
          )
        }

        Text(
          text = "${stories.size} moments",
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // First item: Add Story tile
        item {
          AddStoryTile(
            currentUser = currentUser,
            onClick = onAddStoryClick
          )
        }

        // Subsequent items: User Stories
        items(stories, key = { it.id }) { story ->
          StoryBubbleItem(
            story = story,
            onClick = { onStoryClick(story) }
          )
        }
      }
    }
  }
}

@Composable
private fun AddStoryTile(
  currentUser: UserAccount?,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable { onClick() }
      .width(56.dp)
      .testTag("add_story_button")
  ) {
    Box(
      modifier = Modifier.size(46.dp),
      contentAlignment = Alignment.Center
    ) {
      // User avatar background
      val initials = currentUser?.fullName?.take(2)?.uppercase() ?: "CU"
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .border(1.5.dp, CatchyCyan.copy(alpha = 0.4f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = initials,
          style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        )
      }

      // Small '+' badge at bottom right
      Box(
        modifier = Modifier
          .size(16.dp)
          .align(Alignment.BottomEnd)
          .clip(CircleShape)
          .background(CatchyCyan)
          .border(1.dp, MaterialTheme.colorScheme.surface, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = "Add Story",
          tint = Color.Black,
          modifier = Modifier.size(11.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = "Your Story",
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp
      ),
      color = MaterialTheme.colorScheme.onBackground,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

@Composable
private fun StoryBubbleItem(
  story: CatchyStory,
  onClick: () -> Unit
) {
  val gradient = storyGradients.getOrElse(story.gradientIndex % storyGradients.size) {
    listOf(CatchyIndigo, CatchyCyan)
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clickable { onClick() }
      .width(56.dp)
      .testTag("story_item_${story.id}")
  ) {
    Box(
      modifier = Modifier
        .size(46.dp)
        .clip(CircleShape)
        .background(Brush.linearGradient(gradient))
        .padding(2.dp),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = story.authorName.take(2).uppercase(),
          style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = FontWeight.Bold,
            color = CatchyCyan
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = story.authorName.split(" ").firstOrNull() ?: story.authorName,
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp
      ),
      color = MaterialTheme.colorScheme.onBackground,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

/**
 * Fullscreen / Immersive Story Viewer Dialog
 */
@Composable
fun CatchyStoryViewerDialog(
  story: CatchyStory,
  onDismiss: () -> Unit
) {
  val gradient = storyGradients.getOrElse(story.gradientIndex % storyGradients.size) {
    listOf(CatchyIndigo, CatchyCyan)
  }

  var progress by remember { mutableFloatStateOf(0f) }

  // Auto-progress simulation for story viewing
  LaunchedEffect(story.id) {
    progress = 0f
    val step = 0.02f
    while (progress < 1f) {
      delay(100)
      progress += step
    }
    onDismiss()
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(gradient))
        .padding(16.dp)
        .testTag("story_viewer_dialog")
    ) {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Top header with progress bar and author info
        Column {
          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .fillMaxWidth()
              .height(3.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = Color.White,
            trackColor = Color.White.copy(alpha = 0.3f)
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(Color.White.copy(alpha = 0.25f))
                  .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = story.authorName.take(2).uppercase(),
                  style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                )
              }

              Spacer(modifier = Modifier.width(10.dp))

              Column {
                Text(
                  text = story.authorName,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                )
                val dateStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(story.timestamp))
                Text(
                  text = "@${story.authorUserId} • $dateStr",
                  style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.White.copy(alpha = 0.8f),
                    fontFamily = FontFamily.Monospace
                  )
                )
              }
            }

            IconButton(
              onClick = onDismiss,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close Story",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
              )
            }
          }
        }

        // Center: Story text message
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .padding(horizontal = 24.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = story.storyText,
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              lineHeight = 36.sp
            ),
            color = Color.White,
            textAlign = TextAlign.Center
          )
        }

        // Bottom footer badge
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.Black.copy(alpha = 0.25f),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(
              text = "Catchy Moment",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.85f),
                letterSpacing = 0.5.sp
              ),
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
          }
        }
      }
    }
  }
}

/**
 * Add Story Dialog
 */
@Composable
fun CatchyAddStoryDialog(
  inputText: String,
  onInputChange: (String) -> Unit,
  selectedGradient: Int,
  onSelectGradient: (Int) -> Unit,
  onPublish: () -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.35f)),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("add_story_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Create Catchy Story",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Preview box with chosen gradient
        val activeGradient = storyGradients.getOrElse(selectedGradient % storyGradients.size) {
          listOf(CatchyIndigo, CatchyCyan)
        }
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(activeGradient))
            .padding(14.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (inputText.isNotBlank()) inputText else "Your story preview will appear here...",
            style = MaterialTheme.typography.bodyLarge.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            ),
            textAlign = TextAlign.Center,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Text input field
        OutlinedTextField(
          value = inputText,
          onValueChange = onInputChange,
          placeholder = { Text("What's your story today?") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2,
          maxLines = 3,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CatchyCyan,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Gradient color picker row
        Text(
          text = "Choose Background Style",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          storyGradients.forEachIndexed { index, grad ->
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(grad))
                .clickable { onSelectGradient(index) }
                .then(
                  if (selectedGradient == index) {
                    Modifier.border(2.5.dp, Color.White, CircleShape)
                  } else {
                    Modifier
                  }
                )
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Action buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = onPublish,
            enabled = inputText.isNotBlank(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Share Story")
          }
        }
      }
    }
  }
}
