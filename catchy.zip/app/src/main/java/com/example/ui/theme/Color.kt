package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Catchy Brand Palette
val CatchyIndigo = Color(0xFF6366F1)
val CatchyIndigoLight = Color(0xFF818CF8)
val CatchyIndigoDark = Color(0xFF4338CA)

val CatchyViolet = Color(0xFF8B5CF6)
val CatchyCyan = Color(0xFF06B6D4)
val CatchyCyanGlow = Color(0xFF22D3EE)

val CatchyDarkBg = Color(0xFF0A0D14)
val CatchyDarkSurface = Color(0xFF131825)
val CatchyDarkSurfaceVariant = Color(0xFF1C2336)
val CatchyDarkBorder = Color(0xFF2B364F)

val CatchyTextPrimaryDark = Color(0xFFF8FAFC)
val CatchyTextSecondaryDark = Color(0xFF94A3B8)
val CatchyTextMutedDark = Color(0xFF64748B)

val CatchySuccess = Color(0xFF10B981)
val CatchyError = Color(0xFFEF4444)
val CatchyWarning = Color(0xFFF59E0B)

val CatchyLightBg = Color(0xFFF8FAFC)
val CatchyLightSurface = Color(0xFFFFFFFF)
val CatchyLightSurfaceVariant = Color(0xFFF1F5F9)
val CatchyLightBorder = Color(0xFFE2E8F0)
val CatchyTextPrimaryLight = Color(0xFF0F172A)
val CatchyTextSecondaryLight = Color(0xFF475569)
