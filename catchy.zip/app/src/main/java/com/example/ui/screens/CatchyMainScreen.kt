package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyNavTab

/**
 * Catchy Main Screen hosting the 4 core sections:
 * Home Feed (⌂), Chat (🗨️), Reels (▶️), Profile (👤).
 *
 * Requirements:
 * - Exactly 4 items
 * - Icons only
 * - No text labels
 * - No additional bottom tabs
 * - The Profile icon 👤 opens the current user's Profile.
 */
@Composable
fun CatchyMainScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val currentTab by viewModel.currentTab.collectAsState()
  val viewingOtherUser by viewModel.viewingOtherUser.collectAsState()

  Scaffold(
    modifier = modifier.fillMaxSize(),
    bottomBar = {
      CatchyBottomNavBar(
        currentTab = currentTab,
        onTabSelected = { tab ->
          viewModel.selectTab(tab)
        }
      )
    },
    containerColor = MaterialTheme.colorScheme.background
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      // If actively viewing another user's profile, always display CatchyProfileScreen
      if (viewingOtherUser != null) {
        CatchyProfileScreen(viewModel = viewModel)
      } else {
        Crossfade(targetState = currentTab, label = "TabTransition") { tab ->
          when (tab) {
            CatchyNavTab.HOME -> CatchyFeedScreen(viewModel = viewModel)
            CatchyNavTab.CHAT -> CatchyChatScreen(viewModel = viewModel)
            CatchyNavTab.REELS -> CatchyReelsScreen(viewModel = viewModel)
            CatchyNavTab.PROFILE -> CatchyProfileScreen(viewModel = viewModel)
          }
        }
      }
    }
  }
}

/**
 * Exact 4-item bottom navigation:
 * ⌂ (Home), 🗨️ (Chat), ▶️ (Reels), 👤 (Profile)
 * Icons only, no text labels, no extra tabs.
 */
@Composable
private fun CatchyBottomNavBar(
  currentTab: CatchyNavTab,
  onTabSelected: (CatchyNavTab) -> Unit
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    shadowElevation = 8.dp,
    modifier = Modifier
      .fillMaxWidth()
      .border(
        width = 1.dp,
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
      )
      .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(vertical = 10.dp, horizontal = 24.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Tab 1: ⌂ (Home)
      CatchyNavItem(
        isSelected = currentTab == CatchyNavTab.HOME,
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        contentDescription = "Home",
        testTag = "nav_home",
        onClick = { onTabSelected(CatchyNavTab.HOME) }
      )

      // Tab 2: 🗨️ (Chat)
      CatchyNavItem(
        isSelected = currentTab == CatchyNavTab.CHAT,
        selectedIcon = Icons.Filled.ChatBubble,
        unselectedIcon = Icons.Outlined.ChatBubbleOutline,
        contentDescription = "Chat",
        testTag = "nav_chat",
        onClick = { onTabSelected(CatchyNavTab.CHAT) }
      )

      // Tab 3: ▶️ (Reels)
      CatchyNavItem(
        isSelected = currentTab == CatchyNavTab.REELS,
        selectedIcon = Icons.Filled.PlayArrow,
        unselectedIcon = Icons.Outlined.PlayArrow,
        contentDescription = "Reels",
        testTag = "nav_reels",
        onClick = { onTabSelected(CatchyNavTab.REELS) }
      )

      // Tab 4: 👤 (Profile)
      CatchyNavItem(
        isSelected = currentTab == CatchyNavTab.PROFILE,
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        contentDescription = "Profile",
        testTag = "nav_profile",
        onClick = { onTabSelected(CatchyNavTab.PROFILE) }
      )
    }
  }
}

@Composable
private fun CatchyNavItem(
  isSelected: Boolean,
  selectedIcon: ImageVector,
  unselectedIcon: ImageVector,
  contentDescription: String,
  testTag: String,
  onClick: () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }

  Box(
    modifier = Modifier
      .size(48.dp)
      .clip(CircleShape)
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick
      )
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    if (isSelected) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(CatchyCyan.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = selectedIcon,
          contentDescription = contentDescription,
          tint = CatchyCyan,
          modifier = Modifier.size(26.dp)
        )
      }
    } else {
      Icon(
        imageVector = unselectedIcon,
        contentDescription = contentDescription,
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.size(24.dp)
      )
    }
  }
}
