package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CatchyBrandHeader
import com.example.ui.components.CatchyButton
import com.example.ui.components.CatchyPasswordField
import com.example.ui.components.CatchyTextField
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchySuccess
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyScreen

@Composable
fun ForgotPasswordScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val forgotState by viewModel.forgotPasswordState.collectAsState()
  val resetState by viewModel.resetPasswordState.collectAsState()
  val currentScreen by viewModel.currentScreen.collectAsState()
  val scrollState = rememberScrollState()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top back button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
      ) {
        IconButton(
          onClick = { viewModel.navigateTo(CatchyScreen.LOGIN) },
          modifier = Modifier.testTag("forgot_back_button")
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Back to Login",
            tint = MaterialTheme.colorScheme.onBackground
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      CatchyBrandHeader(
        title = if (currentScreen == CatchyScreen.RESET_PASSWORD) "Set New Password" else stringResource(R.string.forgot_password_title),
        subtitle = if (currentScreen == CatchyScreen.RESET_PASSWORD) "Enter a new secure password for your Catchy account" else stringResource(R.string.forgot_password_subtitle)
      )

      Spacer(modifier = Modifier.height(28.dp))

      if (currentScreen == CatchyScreen.FORGOT_PASSWORD) {
        // Stage 1: Request Password Reset via Email
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            CatchyTextField(
              value = forgotState.email,
              onValueChange = { viewModel.onForgotPasswordEmailChange(it) },
              label = stringResource(R.string.email_label),
              placeholder = "e.g. rahim@gmail.com",
              leadingIcon = Icons.Default.Email,
              keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Done
              ),
              keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                onDone = { viewModel.requestPasswordReset() }
              ),
              testTag = "forgot_email_input"
            )

            // Error banner
            if (!forgotState.errorMessage.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(14.dp))
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(MaterialTheme.colorScheme.error.copy(alpha = 0.15f))
                  .padding(12.dp)
              ) {
                Text(
                  text = forgotState.errorMessage ?: "",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.error
                )
              }
            }

            Spacer(modifier = Modifier.height(20.dp))

            CatchyButton(
              text = stringResource(R.string.send_reset_link_button),
              onClick = { viewModel.requestPasswordReset() },
              isLoading = forgotState.isLoading,
              testTag = "send_reset_link_button"
            )
          }
        }

        // Display dispatched reset link card if generated
        forgotState.dispatch?.let { dispatch ->
          Spacer(modifier = Modifier.height(20.dp))

          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Security,
                  contentDescription = null,
                  tint = CatchyCyan,
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Secure Reset Link Dispatched",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = CatchyCyan
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = "A time-limited one-time reset link has been dispatched to ${dispatch.recipientEmail}. It will expire in 15 minutes.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )

              Spacer(modifier = Modifier.height(14.dp))

              // Direct secure link activator
              OutlinedButton(
                onClick = { viewModel.startResetPasswordWithToken(dispatch.resetToken) },
                shape = RoundedCornerShape(12.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                  contentColor = CatchyCyan
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, CatchyCyan),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("open_reset_link_button")
              ) {
                Icon(imageVector = Icons.Default.LockReset, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Secure Password Reset Flow")
              }
            }
          }
        }
      } else {
        // Stage 2: Reset Password Form with Token
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            if (resetState.isCompleted) {
              Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = "Success",
                  tint = CatchySuccess,
                  modifier = Modifier.size(54.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                  text = "Password Changed Successfully!",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = "Your password has been securely updated. Your User ID and profile relationships remain strictly preserved.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                CatchyButton(
                  text = stringResource(R.string.back_to_login),
                  onClick = { viewModel.navigateTo(CatchyScreen.LOGIN) },
                  testTag = "reset_success_login_button"
                )
              }
            } else {
              CatchyPasswordField(
                value = resetState.newPassword,
                onValueChange = { viewModel.onNewPasswordChange(it) },
                label = stringResource(R.string.new_password_label),
                placeholder = "At least 6 characters",
                keyboardOptions = KeyboardOptions(
                  keyboardType = KeyboardType.Password,
                  imeAction = ImeAction.Next
                ),
                testTag = "new_password_input"
              )

              Spacer(modifier = Modifier.height(16.dp))

              CatchyPasswordField(
                value = resetState.confirmPassword,
                onValueChange = { viewModel.onConfirmNewPasswordChange(it) },
                label = stringResource(R.string.confirm_password_label),
                placeholder = "Confirm new password",
                keyboardOptions = KeyboardOptions(
                  keyboardType = KeyboardType.Password,
                  imeAction = ImeAction.Done
                ),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                  onDone = { viewModel.submitPasswordReset() }
                ),
                testTag = "confirm_new_password_input"
              )

              if (!resetState.errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.15f))
                    .padding(12.dp)
                ) {
                  Text(
                    text = resetState.errorMessage ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                  )
                }
              }

              Spacer(modifier = Modifier.height(20.dp))

              CatchyButton(
                text = stringResource(R.string.reset_password_button),
                onClick = { viewModel.submitPasswordReset() },
                isLoading = resetState.isLoading,
                testTag = "submit_password_reset_button"
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      TextButton(
        onClick = { viewModel.navigateTo(CatchyScreen.LOGIN) },
        modifier = Modifier.testTag("back_to_login_button")
      ) {
        Text(
          text = stringResource(R.string.back_to_login),
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          color = CatchyIndigoLight
        )
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
