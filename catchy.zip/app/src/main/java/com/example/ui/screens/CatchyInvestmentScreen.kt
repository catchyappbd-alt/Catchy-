package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyFounderProfile
import com.example.data.model.CatchyInvestmentOpportunity
import com.example.data.model.CatchyInvestmentRequest
import com.example.data.model.CatchyInvestorProfile
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyInvestmentTab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val InvestmentDarkBg = Color(0xFF0C0D14)
private val InvestmentCardBg = Color(0xFF161722)
private val InvestmentBorder = Color(0xFF262838)
private val InvestmentNeon = Color(0xFFFF2A6D)
private val InvestmentEmerald = Color(0xFF00E676)
private val InvestmentGold = Color(0xFFFFD166)

@Composable
fun CatchyInvestmentDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentTab by viewModel.investmentTab.collectAsState()
  val selectedOpportunity by viewModel.selectedOpportunity.collectAsState()
  val requestingOpportunity by viewModel.requestingOpportunity.collectAsState()
  val isEditorOpen by viewModel.isOpportunityEditorVisible.collectAsState()
  val editingOpportunity by viewModel.editingOpportunity.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("catchy_investment_dialog"),
      color = InvestmentDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        InvestmentHeader(
          onClose = onDismiss,
          onPitchVenture = { viewModel.openCreateOpportunityDialog() }
        )

        // Navigation Tabs
        InvestmentTabRow(
          currentTab = currentTab,
          onSelectTab = { viewModel.setInvestmentTab(it) }
        )

        // Tab Content
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          when (currentTab) {
            CatchyInvestmentTab.EXPLORE -> ExploreDealsView(viewModel = viewModel)
            CatchyInvestmentTab.MY_VENTURES -> MyVenturesView(viewModel = viewModel)
            CatchyInvestmentTab.REQUESTS -> InvestmentRequestsPipelineView(viewModel = viewModel)
            CatchyInvestmentTab.PROFILES -> InvestmentProfilesView(viewModel = viewModel)
          }
        }
      }

      // Modals
      if (selectedOpportunity != null) {
        OpportunityDetailsDialog(
          opportunity = selectedOpportunity!!,
          viewModel = viewModel,
          onDismiss = { viewModel.selectOpportunity(null) }
        )
      }

      if (requestingOpportunity != null) {
        ExpressInvestmentInterestDialog(
          opportunity = requestingOpportunity!!,
          viewModel = viewModel,
          onDismiss = { viewModel.closeRequestInvestmentDialog() }
        )
      }

      if (isEditorOpen) {
        OpportunityEditorDialog(
          existing = editingOpportunity,
          viewModel = viewModel,
          onDismiss = { viewModel.closeOpportunityEditorDialog() }
        )
      }
    }
  }
}

@Composable
private fun InvestmentHeader(
  onClose: () -> Unit,
  onPitchVenture: () -> Unit
) {
  Surface(
    color = Color(0xFF12131C),
    tonalElevation = 4.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        IconButton(
          onClick = onClose,
          modifier = Modifier.testTag("investment_back_button")
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Back",
            tint = Color.White
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Catchy Investment Network",
              color = Color.White,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.Default.TrendingUp,
              contentDescription = "Invest",
              tint = InvestmentEmerald,
              modifier = Modifier.size(18.dp)
            )
          }
          Text(
            text = "Capital • Angels • Ventures",
            color = Color(0xFF9E9EB8),
            fontSize = 12.sp
          )
        }
      }

      Button(
        onClick = onPitchVenture,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = InvestmentNeon,
          contentColor = Color.White
        ),
        modifier = Modifier.testTag("pitch_venture_button")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Pitch Deal", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

@Composable
private fun InvestmentTabRow(
  currentTab: CatchyInvestmentTab,
  onSelectTab: (CatchyInvestmentTab) -> Unit
) {
  val tabs = listOf(
    CatchyInvestmentTab.EXPLORE to "Explore",
    CatchyInvestmentTab.MY_VENTURES to "My Deals",
    CatchyInvestmentTab.REQUESTS to "Pipeline",
    CatchyInvestmentTab.PROFILES to "Profiles"
  )
  val selectedIndex = tabs.indexOfFirst { it.first == currentTab }

  TabRow(
    selectedTabIndex = if (selectedIndex >= 0) selectedIndex else 0,
    containerColor = Color(0xFF12131C),
    contentColor = Color.White,
    indicator = { tabPositions ->
      if (selectedIndex in tabPositions.indices) {
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
          color = InvestmentNeon,
          height = 3.dp
        )
      }
    }
  ) {
    tabs.forEachIndexed { _, (tab, label) ->
      val isSelected = tab == currentTab
      Tab(
        selected = isSelected,
        onClick = { onSelectTab(tab) },
        text = {
          Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) InvestmentNeon else Color(0xFF9E9EB8)
          )
        }
      )
    }
  }
}

// -------------------------------------------------------------
// TAB 1: EXPLORE DEALS
// -------------------------------------------------------------
@Composable
private fun ExploreDealsView(viewModel: AccountViewModel) {
  val searchQuery by viewModel.investmentSearchQuery.collectAsState()
  val selectedIndustry by viewModel.selectedIndustry.collectAsState()
  val selectedStage by viewModel.selectedStage.collectAsState()
  val selectedInstrument by viewModel.selectedInstrument.collectAsState()
  val onlyVerified by viewModel.onlyVerifiedOpportunities.collectAsState()
  val opportunities by viewModel.filteredOpportunities.collectAsState()

  val industries = listOf("All", "FinTech", "AgriTech", "AI & Software", "HealthTech", "E-Commerce", "CleanTech", "Logistics", "EdTech")
  val stages = listOf("All", "Pre-seed", "Seed", "Pre-Series A", "Series A", "Growth")
  val instruments = listOf("All", "Equity", "SAFE", "Convertible Note", "Revenue Share")

  Column(modifier = Modifier.fillMaxSize()) {
    // Search Field
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { viewModel.setInvestmentSearchQuery(it) },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("investment_search_input"),
      placeholder = { Text("Search companies, pitch, traction, location...", color = Color.Gray, fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { viewModel.setInvestmentSearchQuery("") }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = InvestmentCardBg,
        unfocusedContainerColor = InvestmentCardBg,
        focusedBorderColor = InvestmentNeon,
        unfocusedBorderColor = InvestmentBorder,
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      )
    )

    // Filter Chips: Industry
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      industries.forEach { ind ->
        val selected = ind == selectedIndustry
        FilterChip(
          selected = selected,
          onClick = { viewModel.setSelectedIndustry(ind) },
          label = { Text(ind, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = InvestmentNeon.copy(alpha = 0.2f),
            selectedLabelColor = InvestmentNeon,
            containerColor = InvestmentCardBg,
            labelColor = Color(0xFFCCCED9)
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = InvestmentBorder,
            selectedBorderColor = InvestmentNeon
          )
        )
      }
    }

    // Filter Chips: Stage & Instrument & Verified
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      stages.forEach { st ->
        val selected = st == selectedStage
        FilterChip(
          selected = selected,
          onClick = { viewModel.setSelectedStage(st) },
          label = { Text(st, fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = InvestmentEmerald.copy(alpha = 0.2f),
            selectedLabelColor = InvestmentEmerald,
            containerColor = InvestmentCardBg,
            labelColor = Color(0xFFCCCED9)
          )
        )
      }

      instruments.forEach { inst ->
        val selected = inst == selectedInstrument
        FilterChip(
          selected = selected,
          onClick = { viewModel.setSelectedInstrument(inst) },
          label = { Text(inst, fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = InvestmentGold.copy(alpha = 0.2f),
            selectedLabelColor = InvestmentGold,
            containerColor = InvestmentCardBg,
            labelColor = Color(0xFFCCCED9)
          )
        )
      }

      // Verified toggle
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .clip(RoundedCornerShape(16.dp))
          .background(InvestmentCardBg)
          .padding(horizontal = 8.dp, vertical = 2.dp)
      ) {
        Text("Verified Only", color = Color(0xFFCCCED9), fontSize = 11.sp)
        Spacer(modifier = Modifier.width(4.dp))
        Switch(
          checked = onlyVerified,
          onCheckedChange = { viewModel.setOnlyVerifiedOpportunities(it) },
          colors = SwitchDefaults.colors(
            checkedThumbColor = InvestmentEmerald,
            checkedTrackColor = InvestmentEmerald.copy(alpha = 0.3f)
          ),
          modifier = Modifier.size(36.dp)
        )
      }
    }

    // Opportunities List
    if (opportunities.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Business,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(56.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "No Investment Opportunities Found",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Be the first founder to pitch your startup or adjust your search filters.",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = { viewModel.openCreateOpportunityDialog() },
            colors = ButtonDefaults.buttonColors(containerColor = InvestmentNeon)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Post Opportunity", fontWeight = FontWeight.SemiBold)
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(opportunities, key = { it.opportunityId }) { opp ->
          OpportunityDealCard(
            opportunity = opp,
            onClick = { viewModel.selectOpportunity(opp) },
            onExpressInterest = { viewModel.openRequestInvestmentDialog(opp) }
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OpportunityDealCard(
  opportunity: CatchyInvestmentOpportunity,
  onClick: () -> Unit,
  onExpressInterest: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, InvestmentBorder, RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("deal_card_${opportunity.opportunityId}"),
    colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Top row: Company & Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = opportunity.companyName,
              color = Color.White,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold
            )
            if (opportunity.isVerified) {
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = "Verified",
                tint = InvestmentEmerald,
                modifier = Modifier.size(16.dp)
              )
            }
          }
          Text(
            text = opportunity.tagline,
            color = Color(0xFFB4B7C5),
            fontSize = 13.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
          )
        }

        // Target Amount Badge
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = opportunity.targetAmount,
            color = InvestmentEmerald,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold
          )
          Text(
            text = "Target",
            color = Color.Gray,
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Tags Row
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        BadgeChip(text = opportunity.industry, color = InvestmentNeon)
        BadgeChip(text = opportunity.stage, color = InvestmentGold)
        BadgeChip(text = opportunity.instrumentType, color = Color(0xFF00E5FF))
        if (opportunity.location.isNotBlank()) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFF202230))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text(opportunity.location, color = Color(0xFFCCCED9), fontSize = 11.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Financial Metrics Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0xFF1B1D2C))
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("Raised So Far", color = Color.Gray, fontSize = 11.sp)
          Text(opportunity.raisedSoFar.ifBlank { "$0" }, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        if (opportunity.equityOffered.isNotBlank()) {
          Column {
            Text("Equity / Terms", color = Color.Gray, fontSize = 11.sp)
            Text(opportunity.equityOffered, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          }
        }
        Column {
          Text("Min Ticket", color = Color.Gray, fontSize = 11.sp)
          Text(opportunity.minTicket.ifBlank { "Flexible" }, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Pitch Summary snippet
      Text(
        text = opportunity.pitchSummary,
        color = Color(0xFFCCCED9),
        fontSize = 12.sp,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Action Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Tap to view pitch deck & metrics",
          color = Color.Gray,
          fontSize = 11.sp
        )

        Button(
          onClick = onExpressInterest,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = InvestmentEmerald,
            contentColor = Color.Black
          ),
          modifier = Modifier.testTag("express_interest_btn_${opportunity.opportunityId}")
        ) {
          Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Invest / Connect", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 2: MY DEALS & PITCHES
// -------------------------------------------------------------
@Composable
private fun MyVenturesView(viewModel: AccountViewModel) {
  val myDeals by viewModel.myOpportunities.collectAsState()

  if (myDeals.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          imageVector = Icons.Default.ShowChart,
          contentDescription = null,
          tint = Color.Gray,
          modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "You haven't pitched any deals yet",
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Create an investment opportunity to raise funding from verified angel investors and VCs on Catchy.",
          color = Color.Gray,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
          onClick = { viewModel.openCreateOpportunityDialog() },
          colors = ButtonDefaults.buttonColors(containerColor = InvestmentNeon)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Post New Deal", fontWeight = FontWeight.SemiBold)
        }
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(myDeals, key = { it.opportunityId }) { deal ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, InvestmentBorder, RoundedCornerShape(16.dp)),
          colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = deal.companyName,
                  color = Color.White,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = deal.tagline,
                  color = Color.Gray,
                  fontSize = 12.sp
                )
              }
              BadgeChip(
                text = deal.status,
                color = if (deal.status == "ACTIVE") InvestmentEmerald else Color.Gray
              )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Target: ${deal.targetAmount} • Raised: ${deal.raisedSoFar} • ${deal.instrumentType}",
              color = InvestmentGold,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedButton(
                onClick = { viewModel.openEditOpportunityDialog(deal) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(end = 8.dp)
              ) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Edit", color = Color.White, fontSize = 12.sp)
              }

              if (deal.status == "ACTIVE") {
                Button(
                  onClick = { viewModel.closeInvestmentOpportunity(deal.opportunityId) },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF323447)),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.padding(end = 8.dp)
                ) {
                  Text("Close Deal", color = Color.White, fontSize = 12.sp)
                }
              }

              IconButton(
                onClick = { viewModel.deleteInvestmentOpportunity(deal.opportunityId) }
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252))
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 3: INVESTMENT REQUESTS & DEAL PIPELINE
// -------------------------------------------------------------
@Composable
private fun InvestmentRequestsPipelineView(viewModel: AccountViewModel) {
  var selectedSubTab by remember { mutableStateOf(0) } // 0 = Received (Founder), 1 = Sent (Investor)
  val founderRequests by viewModel.founderReceivedRequests.collectAsState()
  val investorRequests by viewModel.investorSentRequests.collectAsState()

  Column(modifier = Modifier.fillMaxSize()) {
    // Sub-tab toggler
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(InvestmentCardBg)
        .padding(4.dp)
    ) {
      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(if (selectedSubTab == 0) InvestmentNeon else Color.Transparent)
          .clickable { selectedSubTab = 0 }
          .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "Received (${founderRequests.size})",
          color = Color.White,
          fontWeight = FontWeight.SemiBold,
          fontSize = 13.sp
        )
      }
      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(if (selectedSubTab == 1) InvestmentNeon else Color.Transparent)
          .clickable { selectedSubTab = 1 }
          .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "Sent (${investorRequests.size})",
          color = Color.White,
          fontWeight = FontWeight.SemiBold,
          fontSize = 13.sp
        )
      }
    }

    if (selectedSubTab == 0) {
      // Received for Founder
      if (founderRequests.isEmpty()) {
        EmptyRequestsView(message = "No investment inquiries or requests received yet.")
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(founderRequests, key = { it.requestId }) { req ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, InvestmentBorder, RoundedCornerShape(14.dp)),
              colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(
                      text = req.investorName,
                      color = Color.White,
                      fontWeight = FontWeight.Bold,
                      fontSize = 15.sp
                    )
                    Text(
                      text = "${req.investorType} • ${req.investorEmail}",
                      color = Color.Gray,
                      fontSize = 12.sp
                    )
                  }
                  BadgeChip(
                    text = req.status,
                    color = when (req.status) {
                      "ACCEPTED" -> InvestmentEmerald
                      "DECLINED" -> Color(0xFFFF5252)
                      "DISCUSSING" -> InvestmentGold
                      else -> InvestmentNeon
                    }
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "Proposed: ${req.proposedAmount} for ${req.companyName}",
                  color = InvestmentEmerald,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )

                if (req.messageNote.isNotBlank()) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "\"${req.messageNote}\"",
                    color = Color(0xFFCCCED9),
                    fontSize = 12.sp
                  )
                }

                if (req.termsOrInquiry.isNotBlank()) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Terms / Inquiry: ${req.termsOrInquiry}",
                    color = Color(0xFF9E9EB8),
                    fontSize = 11.sp
                  )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Button(
                    onClick = {
                      viewModel.messageInvestmentContact(
                        targetUserId = req.investorUserId,
                        targetUserName = req.investorName,
                        initialContextMessage = "Hi ${req.investorName}, regarding your investment inquiry of ${req.proposedAmount} for ${req.companyName}..."
                      )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat", fontSize = 12.sp, color = Color.White)
                  }

                  Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (req.status != "ACCEPTED") {
                      Button(
                        onClick = { viewModel.updateInvestmentRequestStatus(req.requestId, "ACCEPTED") },
                        colors = ButtonDefaults.buttonColors(containerColor = InvestmentEmerald),
                        shape = RoundedCornerShape(10.dp)
                      ) {
                        Text("Accept", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                      }
                    }
                    if (req.status != "DECLINED") {
                      OutlinedButton(
                        onClick = { viewModel.updateInvestmentRequestStatus(req.requestId, "DECLINED") },
                        shape = RoundedCornerShape(10.dp)
                      ) {
                        Text("Decline", fontSize = 11.sp, color = Color(0xFFFF5252))
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Sent for Investor
      if (investorRequests.isEmpty()) {
        EmptyRequestsView(message = "You have not submitted any investment inquiries yet.")
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(investorRequests, key = { it.requestId }) { req ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, InvestmentBorder, RoundedCornerShape(14.dp)),
              colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = req.companyName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                  )
                  BadgeChip(
                    text = req.status,
                    color = when (req.status) {
                      "ACCEPTED" -> InvestmentEmerald
                      "DECLINED" -> Color(0xFFFF5252)
                      "DISCUSSING" -> InvestmentGold
                      else -> InvestmentNeon
                    }
                  )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "Your Offer: ${req.proposedAmount}",
                  color = InvestmentEmerald,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold
                )

                if (req.messageNote.isNotBlank()) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "\"${req.messageNote}\"",
                    color = Color(0xFFCCCED9),
                    fontSize = 12.sp
                  )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.End
                ) {
                  Button(
                    onClick = {
                      viewModel.messageInvestmentContact(
                        targetUserId = req.founderUserId,
                        targetUserName = "Founder (${req.companyName})",
                        initialContextMessage = "Hi, following up on my investment request of ${req.proposedAmount} for ${req.companyName}..."
                      )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat with Founder", fontSize = 12.sp, color = Color.White)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyRequestsView(message: String) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = message,
      color = Color.Gray,
      fontSize = 14.sp,
      textAlign = TextAlign.Center
    )
  }
}

// -------------------------------------------------------------
// TAB 4: INVESTOR & FOUNDER PROFILES
// -------------------------------------------------------------
@Composable
private fun InvestmentProfilesView(viewModel: AccountViewModel) {
  val investorProfile by viewModel.investorProfile.collectAsState()
  val founderProfile by viewModel.founderProfile.collectAsState()
  val context = LocalContext.current

  var isEditingInvestor by remember { mutableStateOf(false) }
  var isEditingFounder by remember { mutableStateOf(false) }

  // Investor form state
  var investorType by remember(investorProfile) { mutableStateOf(investorProfile?.investorType ?: "Angel Investor") }
  var ticketSize by remember(investorProfile) { mutableStateOf(investorProfile?.ticketSizeRange ?: "$10k - $50k") }
  var industries by remember(investorProfile) { mutableStateOf(investorProfile?.preferredIndustries ?: "FinTech, AI, Tech") }
  var stages by remember(investorProfile) { mutableStateOf(investorProfile?.preferredStages ?: "Pre-seed, Seed") }
  var geography by remember(investorProfile) { mutableStateOf(investorProfile?.investmentGeography ?: "Bangladesh & Global") }
  var bio by remember(investorProfile) { mutableStateOf(investorProfile?.bio ?: "") }
  var isAccredited by remember(investorProfile) { mutableStateOf(investorProfile?.isAccredited ?: true) }
  var isDiscoverable by remember(investorProfile) { mutableStateOf(investorProfile?.isPubliclyDiscoverable ?: true) }

  // Founder form state
  var ventureName by remember(founderProfile) { mutableStateOf(founderProfile?.ventureName ?: "") }
  var legalStatus by remember(founderProfile) { mutableStateOf(founderProfile?.legalEntityStatus ?: "Private Limited") }
  var founderIndustry by remember(founderProfile) { mutableStateOf(founderProfile?.industry ?: "Technology") }
  var founderStage by remember(founderProfile) { mutableStateOf(founderProfile?.stage ?: "Seed") }
  var headquarters by remember(founderProfile) { mutableStateOf(founderProfile?.headquarters ?: "Dhaka, Bangladesh") }
  var websiteUrl by remember(founderProfile) { mutableStateOf(founderProfile?.websiteUrl ?: "") }
  var pitch by remember(founderProfile) { mutableStateOf(founderProfile?.elevatorPitch ?: "") }
  var teamOverview by remember(founderProfile) { mutableStateOf(founderProfile?.teamOverview ?: "") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    // Section 1: Investor Profile
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .border(1.dp, InvestmentBorder, RoundedCornerShape(16.dp)),
      colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Person, contentDescription = null, tint = InvestmentEmerald)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Investor Profile", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
          IconButton(onClick = { isEditingInvestor = !isEditingInvestor }) {
            Icon(
              imageVector = if (isEditingInvestor) Icons.Default.Close else Icons.Default.Edit,
              contentDescription = "Toggle Edit",
              tint = Color.White
            )
          }
        }

        if (!isEditingInvestor) {
          if (investorProfile == null) {
            Text(
              text = "Set up your investor credentials, check size, and preferred sectors to connect with high-growth ventures.",
              color = Color.Gray,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
              onClick = { isEditingInvestor = true },
              colors = ButtonDefaults.buttonColors(containerColor = InvestmentEmerald, contentColor = Color.Black)
            ) {
              Text("Create Investor Profile", fontWeight = FontWeight.Bold)
            }
          } else {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Type: ${investorProfile!!.investorType}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Ticket Size: ${investorProfile!!.ticketSizeRange}", color = InvestmentEmerald, fontSize = 13.sp)
            Text("Preferred Sectors: ${investorProfile!!.preferredIndustries}", color = Color(0xFFCCCED9), fontSize = 12.sp)
            Text("Geography: ${investorProfile!!.investmentGeography}", color = Color(0xFFCCCED9), fontSize = 12.sp)
            if (investorProfile!!.bio.isNotBlank()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text("Bio: ${investorProfile!!.bio}", color = Color.Gray, fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = InvestmentEmerald, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (investorProfile!!.isAccredited) "Accredited Investor Verified" else "Standard Investor", color = InvestmentEmerald, fontSize = 12.sp)
            }
          }
        } else {
          // Edit Mode
          Spacer(modifier = Modifier.height(12.dp))
          ProfileTextField(value = investorType, onValueChange = { investorType = it }, label = "Investor Type (e.g. Angel, VC, Family Office)")
          ProfileTextField(value = ticketSize, onValueChange = { ticketSize = it }, label = "Typical Ticket Size Range (e.g. $10k - $50k)")
          ProfileTextField(value = industries, onValueChange = { industries = it }, label = "Preferred Industries")
          ProfileTextField(value = stages, onValueChange = { stages = it }, label = "Preferred Investment Stages")
          ProfileTextField(value = geography, onValueChange = { geography = it }, label = "Investment Geography")
          ProfileTextField(value = bio, onValueChange = { bio = it }, label = "Investor Bio / Background", singleLine = false)

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Accredited Investor", color = Color.White, fontSize = 13.sp)
            Switch(
              checked = isAccredited,
              onCheckedChange = { isAccredited = it },
              colors = SwitchDefaults.colors(checkedThumbColor = InvestmentEmerald)
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Publicly Discoverable Profile", color = Color.White, fontSize = 13.sp)
            Switch(
              checked = isDiscoverable,
              onCheckedChange = { isDiscoverable = it },
              colors = SwitchDefaults.colors(checkedThumbColor = InvestmentNeon)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = {
              viewModel.saveInvestorProfile(
                investorType = investorType,
                ticketSizeRange = ticketSize,
                preferredIndustries = industries,
                preferredStages = stages,
                investmentGeography = geography,
                portfolioSummary = "",
                bio = bio,
                isAccredited = isAccredited,
                isPubliclyDiscoverable = isDiscoverable
              )
              isEditingInvestor = false
              Toast.makeText(context, "Investor profile saved!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = InvestmentEmerald, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Save Investor Profile", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Section 2: Founder / Business Profile
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .border(1.dp, InvestmentBorder, RoundedCornerShape(16.dp)),
      colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Business, contentDescription = null, tint = InvestmentNeon)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Founder & Venture Profile", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
          IconButton(onClick = { isEditingFounder = !isEditingFounder }) {
            Icon(
              imageVector = if (isEditingFounder) Icons.Default.Close else Icons.Default.Edit,
              contentDescription = "Toggle Edit",
              tint = Color.White
            )
          }
        }

        if (!isEditingFounder) {
          if (founderProfile == null) {
            Text(
              text = "Showcase your company profile, legal entity details, and team to build credibility with investors.",
              color = Color.Gray,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
              onClick = { isEditingFounder = true },
              colors = ButtonDefaults.buttonColors(containerColor = InvestmentNeon)
            ) {
              Text("Create Founder Profile", fontWeight = FontWeight.Bold)
            }
          } else {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Venture: ${founderProfile!!.ventureName}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Entity: ${founderProfile!!.legalEntityStatus} • ${founderProfile!!.industry}", color = InvestmentGold, fontSize = 13.sp)
            Text("HQ: ${founderProfile!!.headquarters} • Stage: ${founderProfile!!.stage}", color = Color(0xFFCCCED9), fontSize = 12.sp)
            if (founderProfile!!.websiteUrl.isNotBlank()) {
              Text("Website: ${founderProfile!!.websiteUrl}", color = Color(0xFF80D8FF), fontSize = 12.sp)
            }
            if (founderProfile!!.elevatorPitch.isNotBlank()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text("Pitch: ${founderProfile!!.elevatorPitch}", color = Color.Gray, fontSize = 12.sp)
            }
          }
        } else {
          // Edit Mode
          Spacer(modifier = Modifier.height(12.dp))
          ProfileTextField(value = ventureName, onValueChange = { ventureName = it }, label = "Company / Venture Name")
          ProfileTextField(value = legalStatus, onValueChange = { legalStatus = it }, label = "Legal Status (e.g. Private Limited, Delaware C-Corp)")
          ProfileTextField(value = founderIndustry, onValueChange = { founderIndustry = it }, label = "Industry / Sector")
          ProfileTextField(value = founderStage, onValueChange = { founderStage = it }, label = "Venture Stage (e.g. MVP, Seed, Series A)")
          ProfileTextField(value = headquarters, onValueChange = { headquarters = it }, label = "Headquarters / City")
          ProfileTextField(value = websiteUrl, onValueChange = { websiteUrl = it }, label = "Website / Link")
          ProfileTextField(value = pitch, onValueChange = { pitch = it }, label = "Elevator Pitch Summary", singleLine = false)
          ProfileTextField(value = teamOverview, onValueChange = { teamOverview = it }, label = "Founding Team Overview", singleLine = false)

          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = {
              viewModel.saveFounderProfile(
                ventureName = ventureName,
                legalEntityStatus = legalStatus,
                industry = founderIndustry,
                stage = founderStage,
                headquarters = headquarters,
                websiteUrl = websiteUrl,
                elevatorPitch = pitch,
                teamOverview = teamOverview,
                isVerifiedVenture = true
              )
              isEditingFounder = false
              Toast.makeText(context, "Founder profile saved!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = InvestmentNeon),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Save Founder Profile", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 1: OPPORTUNITY DETAILS DIALOG
// -------------------------------------------------------------
@Composable
private fun OpportunityDetailsDialog(
  opportunity: CatchyInvestmentOpportunity,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val isOwner = currentUser?.userId == opportunity.creatorUserId

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("opportunity_details_dialog"),
      color = InvestmentDarkBg
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top App Bar
        Surface(color = Color(0xFF141520)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text("Opportunity Details", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (!isOwner) {
              Button(
                onClick = {
                  onDismiss()
                  viewModel.openRequestInvestmentDialog(opportunity)
                },
                colors = ButtonDefaults.buttonColors(containerColor = InvestmentEmerald, contentColor = Color.Black),
                shape = RoundedCornerShape(16.dp)
              ) {
                Text("Invest / Connect", fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
            }
          }
        }

        // Body content
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          // Company Title & Tagline
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = opportunity.companyName,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
              )
              if (opportunity.isVerified) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Default.Verified, contentDescription = "Verified", tint = InvestmentEmerald, modifier = Modifier.size(20.dp))
              }
            }
            Text(
              text = opportunity.tagline,
              color = Color(0xFFB4B7C5),
              fontSize = 14.sp
            )
          }

          // Key Highlights Cards
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            HighlightCard(label = "Target Round", value = opportunity.targetAmount, color = InvestmentEmerald, modifier = Modifier.weight(1f))
            HighlightCard(label = "Raised So Far", value = opportunity.raisedSoFar.ifBlank { "$0" }, color = Color.White, modifier = Modifier.weight(1f))
            HighlightCard(label = "Min Ticket", value = opportunity.minTicket, color = InvestmentGold, modifier = Modifier.weight(1f))
          }

          // Details grid
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .border(1.dp, InvestmentBorder, RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              DetailRow(label = "Industry / Sector", value = opportunity.industry)
              DetailRow(label = "Venture Stage", value = opportunity.stage)
              DetailRow(label = "Instrument", value = opportunity.instrumentType)
              if (opportunity.equityOffered.isNotBlank()) {
                DetailRow(label = "Equity / Share Offered", value = opportunity.equityOffered)
              }
              DetailRow(label = "Headquarters", value = opportunity.location)
              DetailRow(label = "Deal Privacy", value = opportunity.privacyLevel)
            }
          }

          // Pitch Summary
          SectionBlock(title = "Pitch Summary", content = opportunity.pitchSummary)

          // Traction & Metrics
          if (opportunity.tractionAndMetrics.isNotBlank()) {
            SectionBlock(title = "Traction & Key Metrics", content = opportunity.tractionAndMetrics)
          }

          // Use of Funds
          if (opportunity.useOfFunds.isNotBlank()) {
            SectionBlock(title = "Use of Funds & Growth Plan", content = opportunity.useOfFunds)
          }

          // Pitch Deck URL
          if (opportunity.pitchDeckUrl.isNotBlank()) {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF191B2A))
                .border(1.dp, Color(0xFF2E3247), RoundedCornerShape(12.dp))
                .padding(12.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, contentDescription = null, tint = InvestmentNeon)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("Pitch Deck / Presentation Link", color = Color.Gray, fontSize = 11.sp)
                  Text(opportunity.pitchDeckUrl, color = Color(0xFF80D8FF), fontSize = 13.sp)
                }
              }
            }
          }

          // Founder Contact / Chat
          if (!isOwner) {
            Button(
              onClick = {
                onDismiss()
                viewModel.messageInvestmentContact(
                  targetUserId = opportunity.creatorUserId,
                  targetUserName = "${opportunity.companyName} Founder",
                  initialContextMessage = "Hi, I am interested in ${opportunity.companyName}'s round on Catchy Investment Network."
                )
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282A3A)),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Direct Message Founder", color = Color.White, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 2: EXPRESS INTEREST / INVESTMENT REQUEST DIALOG
// -------------------------------------------------------------
@Composable
private fun ExpressInvestmentInterestDialog(
  opportunity: CatchyInvestmentOpportunity,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  var proposedAmount by remember { mutableStateOf(opportunity.minTicket) }
  var messageNote by remember { mutableStateOf("") }
  var termsInquiry by remember { mutableStateOf("") }

  val isSubmitting by viewModel.isSubmittingInvestmentRequest.collectAsState()
  val feedbackMessage by viewModel.investmentFeedbackMessage.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("express_interest_dialog"),
      color = InvestmentDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Express Investment Interest", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Target: ${opportunity.companyName}", color = InvestmentEmerald, fontSize = 13.sp)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        // Feedback / Error banner
        if (feedbackMessage != null) {
          Card(
            colors = CardDefaults.cardColors(
              containerColor = if (feedbackMessage!!.contains("submitted", ignoreCase = true)) Color(0xFF1B382B) else Color(0xFF3E1E28)
            ),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(
              text = feedbackMessage!!,
              color = Color.White,
              fontSize = 13.sp,
              modifier = Modifier.padding(12.dp)
            )
          }
        }

        Text(
          text = "Submit an investment request or introduction to the founding team. The founder will receive your investor credentials, offer size, and note.",
          color = Color(0xFFCCCED9),
          fontSize = 13.sp
        )

        ProfileTextField(
          value = proposedAmount,
          onValueChange = { proposedAmount = it },
          label = "Proposed Check / Investment Amount * (e.g. $10,000)",
          keyboardType = KeyboardType.Text
        )

        ProfileTextField(
          value = messageNote,
          onValueChange = { messageNote = it },
          label = "Introductory Note to Founder *",
          singleLine = false
        )

        ProfileTextField(
          value = termsInquiry,
          onValueChange = { termsInquiry = it },
          label = "Specific Terms, Inquiry, or Syndicate Details (Optional)",
          singleLine = false
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            if (proposedAmount.isNotBlank() && messageNote.isNotBlank()) {
              viewModel.submitInvestmentRequest(
                proposedAmount = proposedAmount,
                messageNote = messageNote,
                termsOrInquiry = termsInquiry
              )
            }
          },
          enabled = !isSubmitting && proposedAmount.isNotBlank() && messageNote.isNotBlank(),
          colors = ButtonDefaults.buttonColors(
            containerColor = InvestmentEmerald,
            contentColor = Color.Black
          ),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("submit_investment_request_btn")
        ) {
          if (isSubmitting) {
            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.AttachMoney, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Submit Investment Request", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SUB-MODAL 3: CREATE / EDIT OPPORTUNITY DIALOG
// -------------------------------------------------------------
@Composable
private fun OpportunityEditorDialog(
  existing: CatchyInvestmentOpportunity?,
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  var companyName by remember { mutableStateOf(existing?.companyName ?: "") }
  var tagline by remember { mutableStateOf(existing?.tagline ?: "") }
  var industry by remember { mutableStateOf(existing?.industry ?: "AI & Software") }
  var stage by remember { mutableStateOf(existing?.stage ?: "Seed") }
  var targetAmount by remember { mutableStateOf(existing?.targetAmount ?: "$100,000") }
  var raisedSoFar by remember { mutableStateOf(existing?.raisedSoFar ?: "$0") }
  var instrumentType by remember { mutableStateOf(existing?.instrumentType ?: "Equity") }
  var equityOffered by remember { mutableStateOf(existing?.equityOffered ?: "7%") }
  var minTicket by remember { mutableStateOf(existing?.minTicket ?: "$5,000") }
  var location by remember { mutableStateOf(existing?.location ?: "Dhaka, Bangladesh") }
  var pitchSummary by remember { mutableStateOf(existing?.pitchSummary ?: "") }
  var traction by remember { mutableStateOf(existing?.tractionAndMetrics ?: "") }
  var useOfFunds by remember { mutableStateOf(existing?.useOfFunds ?: "") }
  var pitchDeckUrl by remember { mutableStateOf(existing?.pitchDeckUrl ?: "") }
  var privacyLevel by remember { mutableStateOf(existing?.privacyLevel ?: "PUBLIC") }

  val isSaving by viewModel.isSavingOpportunity.collectAsState()
  val formError by viewModel.opportunityFormError.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("opportunity_editor_dialog"),
      color = InvestmentDarkBg
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (existing != null) "Edit Investment Deal" else "Pitch New Deal",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        if (formError != null) {
          Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3E1E28))) {
            Text(formError!!, color = Color(0xFFFF8080), fontSize = 12.sp, modifier = Modifier.padding(10.dp))
          }
        }

        ProfileTextField(value = companyName, onValueChange = { companyName = it }, label = "Company Name *")
        ProfileTextField(value = tagline, onValueChange = { tagline = it }, label = "One-line Tagline / Mission *")
        ProfileTextField(value = industry, onValueChange = { industry = it }, label = "Industry (FinTech, AgriTech, AI, HealthTech...) *")
        ProfileTextField(value = stage, onValueChange = { stage = it }, label = "Venture Stage (Pre-seed, Seed, Series A...) *")

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(modifier = Modifier.weight(1f)) {
            ProfileTextField(value = targetAmount, onValueChange = { targetAmount = it }, label = "Target Round *")
          }
          Box(modifier = Modifier.weight(1f)) {
            ProfileTextField(value = raisedSoFar, onValueChange = { raisedSoFar = it }, label = "Raised So Far")
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(modifier = Modifier.weight(1f)) {
            ProfileTextField(value = instrumentType, onValueChange = { instrumentType = it }, label = "Instrument (Equity/SAFE)")
          }
          Box(modifier = Modifier.weight(1f)) {
            ProfileTextField(value = minTicket, onValueChange = { minTicket = it }, label = "Min Check Size *")
          }
        }

        ProfileTextField(value = equityOffered, onValueChange = { equityOffered = it }, label = "Equity / Share Terms Offered (e.g. 5% - 8%)")
        ProfileTextField(value = location, onValueChange = { location = it }, label = "Headquarters / Location *")
        ProfileTextField(value = pitchSummary, onValueChange = { pitchSummary = it }, label = "Pitch Summary & Problem/Solution *", singleLine = false)
        ProfileTextField(value = traction, onValueChange = { traction = it }, label = "Traction & Financial Metrics (MRR, GMV, Users)", singleLine = false)
        ProfileTextField(value = useOfFunds, onValueChange = { useOfFunds = it }, label = "Use of Funds & 18-month Milestones", singleLine = false)
        ProfileTextField(value = pitchDeckUrl, onValueChange = { pitchDeckUrl = it }, label = "Pitch Deck URL / Presentation Link")

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Publicly Discoverable on Catchy", color = Color.White, fontSize = 13.sp)
          Switch(
            checked = privacyLevel == "PUBLIC",
            onCheckedChange = { privacyLevel = if (it) "PUBLIC" else "VERIFIED_INVESTORS_ONLY" },
            colors = SwitchDefaults.colors(checkedThumbColor = InvestmentNeon)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = {
            if (companyName.isNotBlank() && tagline.isNotBlank() && pitchSummary.isNotBlank()) {
              viewModel.saveInvestmentOpportunity(
                companyName = companyName,
                tagline = tagline,
                industry = industry,
                stage = stage,
                targetAmount = targetAmount,
                raisedSoFar = raisedSoFar,
                instrumentType = instrumentType,
                equityOffered = equityOffered,
                minTicket = minTicket,
                location = location,
                pitchSummary = pitchSummary,
                tractionAndMetrics = traction,
                useOfFunds = useOfFunds,
                pitchDeckUrl = pitchDeckUrl,
                privacyLevel = privacyLevel
              )
            }
          },
          enabled = !isSaving && companyName.isNotBlank() && tagline.isNotBlank() && pitchSummary.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = InvestmentNeon),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("save_opportunity_btn")
        ) {
          if (isSaving) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
          } else {
            Text(if (existing != null) "Update Deal" else "Publish Deal Opportunity", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// HELPER COMPONENTS
// -------------------------------------------------------------
@Composable
private fun HighlightCard(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .border(1.dp, InvestmentBorder, RoundedCornerShape(12.dp)),
    colors = CardDefaults.cardColors(containerColor = InvestmentCardBg)
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Text(label, color = Color.Gray, fontSize = 10.sp)
      Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
private fun DetailRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, color = Color.Gray, fontSize = 12.sp)
    Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
  }
}

@Composable
private fun SectionBlock(title: String, content: String) {
  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    Text(title, color = InvestmentGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    Text(
      text = content,
      color = Color(0xFFD6D8E4),
      fontSize = 13.sp,
      lineHeight = 18.sp
    )
  }
}

@Composable
private fun BadgeChip(text: String, color: Color) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.15f))
      .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Text(text = text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun ProfileTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  singleLine: Boolean = true,
  keyboardType: KeyboardType = KeyboardType.Text
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label, color = Color.Gray, fontSize = 12.sp) },
    singleLine = singleLine,
    keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedContainerColor = InvestmentCardBg,
      unfocusedContainerColor = InvestmentCardBg,
      focusedBorderColor = InvestmentNeon,
      unfocusedBorderColor = InvestmentBorder,
      focusedTextColor = Color.White,
      unfocusedTextColor = Color.White
    )
  )
}
