package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CatchyPost
import com.example.data.model.UserAccount
import com.example.ui.components.CatchyButton
import com.example.ui.components.CatchyTextField
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchySuccess
import com.example.ui.theme.CatchyViolet
import com.example.ui.theme.CatchyWarning
import com.example.ui.viewmodel.AccountViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CatchyProfileScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val viewingOtherUser by viewModel.viewingOtherUser.collectAsState()

  val isViewingSelf = viewingOtherUser == null
  val displayUser = viewingOtherUser ?: currentUser

  if (displayUser == null) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background),
      contentAlignment = Alignment.Center
    ) {
      CircularProgressIndicator(color = CatchyCyan)
    }
    return
  }

  val context = LocalContext.current
  val isEditingProfile by viewModel.isEditingProfile.collectAsState()
  val editFullName by viewModel.editFullName.collectAsState()
  val editPhotoUri by viewModel.editPhotoUri.collectAsState()
  val editBio by viewModel.editBio.collectAsState()
  val profileFeedback by viewModel.profileFeedback.collectAsState()

  // Social Stats Flows
  val followerCount by (if (isViewingSelf) viewModel.myFollowerCount else viewModel.viewingUserFollowerCount).collectAsState()
  val followingCount by (if (isViewingSelf) viewModel.myFollowingCount else viewModel.viewingUserFollowingCount).collectAsState()
  val isFollowing by viewModel.isFollowingViewingUser.collectAsState()
  val posts by (if (isViewingSelf) viewModel.myPosts else viewModel.viewingUserPosts).collectAsState()
  val followingIds by viewModel.followingUserIds.collectAsState()
  val followerIds by viewModel.followerUserIds.collectAsState()
  val showFriendsSheet by viewModel.showFriendsSheet.collectAsState()
  val isOtherFollowingMe = !isViewingSelf && displayUser.userId in followerIds
  val isMutualConnection = !isViewingSelf && isFollowing && isOtherFollowingMe

  // Post composer toggle
  var showPostComposer by remember { mutableStateOf(false) }
  val newPostInput by viewModel.newPostInput.collectAsState()

  // Private info drawer (only for self)
  var showPrivateCoreInfo by remember { mutableStateOf(false) }

  // Edit Profile Dialog (Only for Self)
  if (isEditingProfile && isViewingSelf) {
    EditProfileDialog(
      userId = displayUser.userId,
      fullName = editFullName,
      onFullNameChange = { viewModel.onEditFullNameChange(it) },
      bio = editBio,
      onBioChange = { viewModel.onEditBioChange(it) },
      selectedPhotoUri = editPhotoUri,
      onPhotoSelected = { viewModel.onEditPhotoUriChange(it) },
      onSave = { viewModel.saveEditableProfile() },
      onDismiss = { viewModel.cancelEditingProfile() }
    )
  }

  // Friends & Following Sheet
  if (showFriendsSheet) {
    CatchyFriendsDialog(
      viewModel = viewModel,
      onDismiss = { viewModel.closeFriends() }
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))

      // Header Navigation Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (!isViewingSelf) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .clickable { viewModel.closeUserProfile() }
              .padding(vertical = 4.dp, horizontal = 6.dp)
              .testTag("back_to_my_profile")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = CatchyCyan
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Back",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
              color = CatchyCyan
            )
          }
        } else {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan)))
                .padding(1.5.dp)
            ) {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .clip(RoundedCornerShape(7.dp))
                .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "C",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                  color = CatchyCyan
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Profile",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }
        }

        if (isViewingSelf) {
          OutlinedButton(
            onClick = { viewModel.signOut() },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
            modifier = Modifier.testTag("sign_out_button")
          ) {
            Icon(
              imageVector = Icons.Default.ExitToApp,
              contentDescription = "Sign Out",
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = stringResource(R.string.sign_out_button),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
            )
          }
        }
      }
    }

    // ORIGINAL CATCHY PROFILE HEADER
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Profile Photo Avatar
          val avatarGradients = when (displayUser.profilePhotoUri) {
            "avatar_1" -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
            "avatar_2" -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
            "avatar_3" -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
            else -> listOf(Color(0xFF10B981), Color(0xFF059669))
          }

          Box(
            modifier = Modifier
              .size(92.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(avatarGradients))
              .border(3.dp, CatchyCyan.copy(alpha = 0.7f), CircleShape)
              .testTag("profile_photo"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = displayUser.fullName.take(2).uppercase(),
              style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Full Name
          Text(
            text = displayUser.fullName,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.testTag("profile_full_name")
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Automatically generated User ID (@CTY-XXXXXX)
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = CatchyIndigo.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, CatchyIndigoLight.copy(alpha = 0.4f)),
            modifier = Modifier
              .clickable {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Catchy User ID", displayUser.userId)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Copied @${displayUser.userId}", Toast.LENGTH_SHORT).show()
              }
              .testTag("profile_user_id")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Permanently linked User ID",
                tint = CatchyCyan,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "@${displayUser.userId}",
                style = MaterialTheme.typography.labelLarge.copy(
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.sp
                ),
                color = CatchyCyan
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Copy",
                tint = CatchyIndigoLight,
                modifier = Modifier.size(12.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Bio / About Section
          val bioText = if (displayUser.bio.isNotBlank()) displayUser.bio else "Connecting authentically on Catchy."
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
              .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
              .padding(horizontal = 14.dp, vertical = 10.dp)
              .testTag("profile_bio")
          ) {
            Text(
              text = bioText,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.align(Alignment.Center)
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Social Stats Bar (Followers, Following, Posts)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
              .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            StatItem(
              count = posts.size.toString(),
              label = "Posts",
              testTag = "profile_posts_count"
            )
            Box(
              modifier = Modifier
                .width(1.dp)
                .height(26.dp)
                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            )
            StatItem(
              count = followerCount.toString(),
              label = "Followers",
              testTag = "profile_followers_count",
              onClick = {
                viewModel.setFriendsTab(AccountViewModel.FriendsTab.FOLLOWERS)
                viewModel.openFriends()
              }
            )
            Box(
              modifier = Modifier
                .width(1.dp)
                .height(26.dp)
                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            )
            StatItem(
              count = followingCount.toString(),
              label = "Following",
              testTag = "profile_following_count",
              onClick = {
                viewModel.setFriendsTab(AccountViewModel.FriendsTab.FOLLOWING)
                viewModel.openFriends()
              }
            )
          }

          // Relationship Status Badge for Other User
          if (!isViewingSelf) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = when {
                isMutualConnection -> CatchySuccess.copy(alpha = 0.15f)
                isOtherFollowingMe -> CatchyIndigo.copy(alpha = 0.15f)
                isFollowing -> MaterialTheme.colorScheme.surfaceVariant
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
              },
              border = BorderStroke(
                1.dp,
                when {
                  isMutualConnection -> CatchySuccess.copy(alpha = 0.4f)
                  isOtherFollowingMe -> CatchyIndigoLight.copy(alpha = 0.4f)
                  else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                }
              ),
              modifier = Modifier.testTag("profile_relationship_badge")
            ) {
              Text(
                text = when {
                  isMutualConnection -> "Mutual Connection • Friends"
                  isOtherFollowingMe -> "Follows You"
                  isFollowing -> "Following"
                  else -> "Catchy Community Member"
                },
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 11.sp
                ),
                color = when {
                  isMutualConnection -> CatchySuccess
                  isOtherFollowingMe -> CatchyCyan
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Action Buttons:
          // Own Profile -> [ Edit Profile ] + [ New Post ]
          // Other User Profile -> [ Follow / Following ] + [ Message ]
          if (isViewingSelf) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = {
                  viewModel.startEditingProfile(
                    currentName = displayUser.fullName,
                    currentPhoto = displayUser.profilePhotoUri,
                    currentBio = displayUser.bio
                  )
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
                modifier = Modifier
                  .weight(1f)
                  .testTag("edit_profile_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Edit,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit Profile", fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = { showPostComposer = !showPostComposer },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CatchyCyan),
                border = androidx.compose.foundation.BorderStroke(1.dp, CatchyCyan),
                modifier = Modifier
                  .weight(1f)
                  .testTag("toggle_new_post_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Post", fontWeight = FontWeight.SemiBold)
              }
            }

            if (!profileFeedback.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = profileFeedback ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = CatchySuccess
              )
            }
          } else {
            // Other User's Profile: Follow and Message
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = { viewModel.toggleFollowViewingUser() },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isFollowing) MaterialTheme.colorScheme.surfaceVariant else CatchyIndigo
                ),
                modifier = Modifier
                  .weight(1f)
                  .testTag("profile_follow_button")
              ) {
                Icon(
                  imageVector = if (isFollowing) Icons.Default.PersonRemove else Icons.Default.PersonAdd,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                  tint = if (isFollowing) CatchyCyan else Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isFollowing) "Following" else "Follow",
                  fontWeight = FontWeight.Bold,
                  color = if (isFollowing) CatchyCyan else Color.White
                )
              }

              Button(
                onClick = { viewModel.openChatWithUser(displayUser) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan),
                modifier = Modifier
                  .weight(1f)
                  .testTag("profile_message_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Mail,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                  tint = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Message", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
              }
            }
          }
        }
      }
    }

    // New Post Composer Card (expandable on own profile)
    if (isViewingSelf && showPostComposer) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CatchyIndigoLight.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Share with Catchy Community",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
              value = newPostInput,
              onValueChange = { viewModel.onNewPostInputChange(it) },
              placeholder = { Text("What's on your mind today?") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("new_post_input"),
              maxLines = 4,
              shape = RoundedCornerShape(12.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CatchyCyan,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
              )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End
            ) {
              TextButton(onClick = { showPostComposer = false }) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Spacer(modifier = Modifier.width(8.dp))
              Button(
                onClick = {
                  viewModel.publishPost()
                  showPostComposer = false
                },
                enabled = newPostInput.isNotBlank(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
                modifier = Modifier.testTag("publish_post_button")
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Send,
                  contentDescription = null,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Post")
              }
            }
          }
        }
      }
    }

    // FIXED CORE ACCOUNT INFORMATION (Only visible for self - strictly protected)
    if (isViewingSelf) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { showPrivateCoreInfo = !showPrivateCoreInfo }
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Shield,
                  contentDescription = null,
                  tint = CatchyIndigoLight,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Fixed Core Account Credentials",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onBackground
                )
              }
              Icon(
                imageVector = if (showPrivateCoreInfo) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = "Expand",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            AnimatedVisibility(visible = showPrivateCoreInfo) {
              Column(modifier = Modifier.padding(top = 12.dp)) {
                // Fixed info notice
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(8.dp)
                ) {
                  Row(verticalAlignment = Alignment.Top) {
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = null,
                      tint = CatchyCyan,
                      modifier = Modifier.size(14.dp).padding(top = 1.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = stringResource(R.string.fixed_info_notice),
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                FixedDataRow(label = "Unique User ID", value = displayUser.userId, isMonospace = true)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Registered Email", value = displayUser.email)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Date of Birth", value = displayUser.dateOfBirth)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Gender", value = displayUser.gender)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Address / Location", value = displayUser.addressLocation)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Education Status", value = displayUser.educationStatus)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Occupation Status", value = displayUser.occupationStatus)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Skills", value = displayUser.skills)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                FixedDataRow(label = "Marital Status", value = displayUser.maritalStatus)
              }
            }
          }
        }
      }
    }

    // USER'S POSTS SECTION HEADER
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isViewingSelf) "My Posts" else "${displayUser.fullName}'s Posts",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
        Text(
          text = "${posts.size} total",
          style = MaterialTheme.typography.labelMedium,
          color = CatchyCyan
        )
      }
    }

    // POSTS LIST
    if (posts.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (isViewingSelf) "You haven't posted yet" else "No posts yet from this user",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Public updates and ideas will appear here.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          }
        }
      }
    } else {
      items(posts, key = { it.id }) { post ->
        PostCard(post = post)
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }
}

@Composable
private fun StatItem(
  count: String,
  label: String,
  testTag: String,
  onClick: (() -> Unit)? = null
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
      .testTag(testTag)
  ) {
    Text(
      text = count,
      style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
      color = MaterialTheme.colorScheme.onBackground
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

@Composable
private fun PostCard(post: CatchyPost) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("post_item_${post.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        val avatarBg = when (post.authorAvatar) {
          "avatar_1" -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
          "avatar_2" -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
          "avatar_3" -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
          else -> listOf(Color(0xFF10B981), Color(0xFF059669))
        }

        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(avatarBg)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = post.authorName.take(2).uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = post.authorName,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "@${post.authorUserId}",
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
              color = CatchyCyan
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "•",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(6.dp))
            val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(post.timestamp))
            Text(
              text = dateStr,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = post.content,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.FavoriteBorder,
            contentDescription = "Like",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = post.likesCount.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.ModeComment,
            contentDescription = "Comment",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = post.commentsCount.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
private fun FixedDataRow(
  label: String,
  value: String,
  isMonospace: Boolean = false
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = value,
        style = if (isMonospace) {
          MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        } else {
          MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
        },
        color = MaterialTheme.colorScheme.onBackground
      )
      Spacer(modifier = Modifier.width(4.dp))
      Icon(
        imageVector = Icons.Default.Lock,
        contentDescription = "Fixed and locked",
        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.size(12.dp)
      )
    }
  }
}

@Composable
private fun EditProfileDialog(
  userId: String,
  fullName: String,
  onFullNameChange: (String) -> Unit,
  bio: String,
  onBioChange: (String) -> Unit,
  selectedPhotoUri: String?,
  onPhotoSelected: (String?) -> Unit,
  onSave: () -> Unit,
  onDismiss: () -> Unit
) {
  val avatarPresets = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Edit Profile",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "You can update your Full Name, Profile Photo, and Bio. Core account information remains locked.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Read-only User ID badge
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "USER ID (LOCKED)",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CatchyCyan
              )
              Text(
                text = "@$userId",
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onBackground
              )
            }
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = "Read only",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(16.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        CatchyTextField(
          value = fullName,
          onValueChange = onFullNameChange,
          label = "Full Name",
          placeholder = "Enter your full name",
          testTag = "edit_fullname_input"
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = bio,
          onValueChange = onBioChange,
          label = { Text("Bio / About") },
          placeholder = { Text("Tell the Catchy community about yourself") },
          maxLines = 3,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("edit_bio_input"),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CatchyCyan,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
          )
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "Select Profile Photo",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          avatarPresets.forEachIndexed { index, avatarId ->
            val isSelected = selectedPhotoUri == avatarId
            val bgColors = when (index) {
              0 -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
              1 -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
              2 -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
              else -> listOf(Color(0xFF10B981), Color(0xFF059669))
            }

            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(bgColors))
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) CatchyCyan else Color.Transparent,
                  shape = CircleShape
                )
                .clickable { onPhotoSelected(avatarId) }
                .testTag("edit_avatar_preset_$index"),
              contentAlignment = Alignment.Center
            ) {
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = "Selected Avatar",
                  tint = Color.White
                )
              } else {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = Color.White.copy(alpha = 0.8f),
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onSave,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
        modifier = Modifier.testTag("save_profile_button")
      ) {
        Text("Save Changes")
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("cancel_edit_profile_button")
      ) {
        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    },
    shape = RoundedCornerShape(20.dp),
    containerColor = MaterialTheme.colorScheme.surface
  )
}
