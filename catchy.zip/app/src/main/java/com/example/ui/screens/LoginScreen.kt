package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CatchyButton
import com.example.ui.components.CatchyPasswordField
import com.example.ui.components.CatchyTextField
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchyViolet
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyScreen

@Composable
fun LoginScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val loginState by viewModel.loginState.collectAsState()
  val scrollState = rememberScrollState()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding()
      .navigationBarsPadding()
      .imePadding()
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Spacer(modifier = Modifier.height(12.dp))

      // Catchy Brand Emblem & Title
      Box(
        modifier = Modifier
          .size(68.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(
            brush = Brush.linearGradient(
              colors = listOf(CatchyIndigo, CatchyViolet, CatchyCyan)
            )
          )
          .padding(2.dp)
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_catchy_logo),
            contentDescription = "Catchy Brand Logo",
            modifier = Modifier
              .size(50.dp)
              .clip(RoundedCornerShape(14.dp))
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Text(
          text = "Catchy",
          style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.5.sp
          ),
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CatchyIndigo.copy(alpha = 0.2f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "SOCIAL",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            ),
            color = CatchyCyan
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 1. WELCOME BRANDING (Exact required wording: "Welcome to Catchy, a proud concern of kichaan.")
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = CatchyIndigo.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.35f)),
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 480.dp)
      ) {
        Text(
          text = "Welcome to Catchy, a proud concern of kichaan.",
          style = MaterialTheme.typography.bodyMedium.copy(
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.2.sp
          ),
          color = CatchyCyan,
          textAlign = TextAlign.Center,
          modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("welcome_branding_text")
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // 2. LOGIN FORM CARD
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
          1.dp,
          MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 480.dp)
      ) {
        Column(modifier = Modifier.padding(22.dp)) {
          Text(
            text = "Sign In",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold
            ),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Enter your registered Email or Catchy User ID",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(20.dp))

          // Email or User ID field
          CatchyTextField(
            value = loginState.identifier,
            onValueChange = { viewModel.onLoginIdentifierChange(it) },
            label = "Email or User ID",
            placeholder = "user@example.com or CTY-XXXXXX",
            leadingIcon = Icons.Default.AccountCircle,
            keyboardOptions = KeyboardOptions(
              keyboardType = KeyboardType.Text,
              imeAction = ImeAction.Next
            ),
            testTag = "login_identifier_input"
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Password Field
          CatchyPasswordField(
            value = loginState.password,
            onValueChange = { viewModel.onLoginPasswordChange(it) },
            label = "Password",
            placeholder = "Enter your password",
            keyboardOptions = KeyboardOptions(
              keyboardType = KeyboardType.Password,
              imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
              onDone = { viewModel.login() }
            ),
            testTag = "login_password_input"
          )

          // 3. FORGOT PASSWORD ACTION
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            TextButton(
              onClick = { viewModel.navigateTo(CatchyScreen.FORGOT_PASSWORD) },
              modifier = Modifier.testTag("forgot_password_button")
            ) {
              Text(
                text = "Forgot Password?",
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = FontWeight.SemiBold
                ),
                color = CatchyCyan
              )
            }
          }

          // Error banner
          if (!loginState.errorMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f))
                .border(
                  1.dp,
                  MaterialTheme.colorScheme.error.copy(alpha = 0.35f),
                  RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("login_error_banner")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(
                  imageVector = Icons.Default.ErrorOutline,
                  contentDescription = "Error",
                  tint = MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = loginState.errorMessage ?: "",
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                  color = MaterialTheme.colorScheme.error
                )
              }
            }
            Spacer(modifier = Modifier.height(14.dp))
          }

          // Info banner
          if (!loginState.infoMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CatchyIndigoLight.copy(alpha = 0.12f))
                .border(
                  1.dp,
                  CatchyCyan.copy(alpha = 0.35f),
                  RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("login_info_banner")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = "Info",
                  tint = CatchyCyan,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = loginState.infoMessage ?: "",
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                  color = CatchyCyan
                )
              }
            }
            Spacer(modifier = Modifier.height(14.dp))
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Log In Button
          CatchyButton(
            text = "Log In",
            onClick = { viewModel.login() },
            isLoading = loginState.isLoading,
            testTag = "login_submit_button"
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // 4. CREATE ACCOUNT ACTION
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 480.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          )
          Text(
            text = "New to Catchy?",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp)
          )
          HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
          onClick = { viewModel.navigateTo(CatchyScreen.SIGN_UP) },
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.5.dp, CatchyIndigoLight.copy(alpha = 0.8f)),
          colors = ButtonDefaults.outlinedButtonColors(
            containerColor = CatchyIndigo.copy(alpha = 0.08f),
            contentColor = CatchyIndigoLight
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("navigate_signup_button")
        ) {
          Icon(
            imageVector = Icons.Default.PersonAdd,
            contentDescription = null,
            tint = CatchyIndigoLight,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Create New Account",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.3.sp
            ),
            color = CatchyIndigoLight
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
