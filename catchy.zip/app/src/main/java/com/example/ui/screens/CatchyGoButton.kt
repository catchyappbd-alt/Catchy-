package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Catchy Go Premium Neon Palette
private val CatchyGoObsidianDark = Color(0xFF070913)
private val CatchyGoObsidianMid = Color(0xFF101424)
private val CatchyGoObsidianEnd = Color(0xFF090B16)
private val CatchyGoStripBg = Color(0xFF13172B)

private val CatchyGoNeonRed = Color(0xFFFF1744)
private val CatchyGoNeonPink = Color(0xFFFF2E93)
private val CatchyGoNeonRose = Color(0xFFFF598B)
private val CatchyGoNeonOrange = Color(0xFFFF7A00)

// Radiant neon glowing border
private val CatchyGoNeonGlowBorder = Brush.horizontalGradient(
  colors = listOf(
    CatchyGoNeonRed,
    CatchyGoNeonPink,
    CatchyGoNeonRose,
    CatchyGoNeonOrange,
    CatchyGoNeonPink,
    CatchyGoNeonRed
  )
)

/**
 * Catchy Go Button & Hero Portal.
 *
 * Visual Styling:
 * - Premium dark obsidian background
 * - Neon red/pink glowing rounded Catchy Go button
 * - Video / clapper icon
 * - "Catchy Go"
 * - "Movies • Creators • Talent • More"
 * - "Your Video World Awaits"
 *
 * Keeps all existing upload, publish, database, and playback functionality unchanged.
 */
@Composable
fun CatchyGoButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .shadow(
        elevation = 12.dp,
        shape = RoundedCornerShape(22.dp),
        spotColor = CatchyGoNeonPink.copy(alpha = 0.65f),
        ambientColor = CatchyGoNeonRed.copy(alpha = 0.50f)
      )
      .clip(RoundedCornerShape(22.dp))
      .border(
        width = 2.dp,
        brush = CatchyGoNeonGlowBorder,
        shape = RoundedCornerShape(22.dp)
      )
      .background(
        brush = Brush.verticalGradient(
          colors = listOf(
            CatchyGoObsidianDark,
            CatchyGoObsidianMid,
            CatchyGoObsidianEnd
          )
        )
      )
      .clickable(
        role = Role.Button,
        onClickLabel = "Open Catchy Go",
        onClick = onClick
      )
      .testTag("catchy_go_button")
      .padding(horizontal = 18.dp, vertical = 16.dp)
  ) {
    Column(
      modifier = Modifier.fillMaxWidth()
    ) {
      // Top Row: Clapper Badge + Catchy Go + Subtitle & Forward Arrow
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f, fill = false)
        ) {
          // Video / Clapper Icon Badge with neon red/pink gradient & crisp white icon
          Box(
            modifier = Modifier
              .size(52.dp)
              .clip(RoundedCornerShape(15.dp))
              .background(
                brush = Brush.linearGradient(
                  colors = listOf(CatchyGoNeonRed, CatchyGoNeonPink)
                )
              )
              .border(
                width = 1.2.dp,
                color = Color.White.copy(alpha = 0.40f),
                shape = RoundedCornerShape(15.dp)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Filled.Movie,
              contentDescription = "Catchy Go Video Clapper",
              tint = Color.White,
              modifier = Modifier.size(28.dp)
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column {
            // "Catchy" + "GO" title
            Row(
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Catchy",
                style = MaterialTheme.typography.headlineSmall.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 0.5.sp,
                  fontSize = 22.sp
                ),
                color = Color.White
              )

              Spacer(modifier = Modifier.width(8.dp))

              // Neon Glowing GO Badge
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(7.dp))
                  .background(
                    brush = Brush.horizontalGradient(
                      colors = listOf(CatchyGoNeonRed, CatchyGoNeonPink, CatchyGoNeonRose)
                    )
                  )
                  .padding(horizontal = 9.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "GO",
                  style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.3.sp,
                    fontSize = 12.sp
                  ),
                  color = Color.White
                )
              }
            }

            Spacer(modifier = Modifier.height(3.dp))

            // Subtitle Tagline: "Your Video World Awaits"
            Text(
              text = "Your Video World Awaits",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.3.sp,
                fontSize = 13.sp
              ),
              color = CatchyGoNeonRose
            )
          }
        }

        // Right side: Glowing neon action circle
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(
              brush = Brush.linearGradient(
                colors = listOf(
                  CatchyGoNeonRed.copy(alpha = 0.28f),
                  CatchyGoNeonPink.copy(alpha = 0.40f)
                )
              )
            )
            .border(
              width = 1.2.dp,
              brush = Brush.linearGradient(
                colors = listOf(CatchyGoNeonRed, CatchyGoNeonPink)
              ),
              shape = CircleShape
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Enter Catchy Go",
            tint = Color.White,
            modifier = Modifier.size(19.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(13.dp))

      // Bottom Category Strip: "Movies • Creators • Talent • More"
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(CatchyGoStripBg)
          .border(
            width = 0.9.dp,
            color = Color.White.copy(alpha = 0.12f),
            shape = RoundedCornerShape(12.dp)
          )
          .padding(horizontal = 14.dp, vertical = 8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
          ) {
            Text(
              text = "Movies",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = Color(0xFFF8FAFC)
            )
            Text(
              text = "•",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
              ),
              color = CatchyGoNeonPink
            )
            Text(
              text = "Creators",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = Color(0xFFF8FAFC)
            )
            Text(
              text = "•",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
              ),
              color = CatchyGoNeonPink
            )
            Text(
              text = "Talent",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = Color(0xFFF8FAFC)
            )
            Text(
              text = "•",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
              ),
              color = CatchyGoNeonPink
            )
            Text(
              text = "More",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = Color(0xFFF8FAFC)
            )
          }

          // Subtle play indicator
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            tint = CatchyGoNeonRose,
            modifier = Modifier.size(15.dp)
          )
        }
      }
    }
  }
}

