package com.example.ui.screens

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyGoUploadedVideo
import com.example.data.model.UserAccount
import com.example.data.repository.AccountRepository
import com.example.data.storage.CatchyCloudStorageService
import com.example.data.storage.CloudUploadResult
import com.example.data.storage.UploadProgress
import com.example.ui.components.CatchyGoDarkSurface
import com.example.ui.components.CatchyGoOrange
import com.example.ui.components.CatchyGoPink
import com.example.ui.components.CatchyGoPlayer
import com.example.ui.components.CatchyGoRed
import com.example.ui.components.formatVideoDuration
import com.example.ui.theme.CatchyCyan
import com.example.ui.viewmodel.AccountViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_VIDEO_DURATION_MS = 5 * 60 * 1000L // 5 minutes in ms (300,000 ms)

private val CATCHY_CATEGORIES = listOf(
  "Tech & Coding",
  "Design & Art",
  "Lifestyle & Vlog",
  "Music & Sound",
  "Entertainment",
  "Gaming",
  "Business & Startups"
)

private val VISIBILITY_OPTIONS = listOf(
  "Public",
  "Followers Only",
  "Private"
)

enum class UploadStage {
  DETAILS_FORM,
  UPLOADING,
  FAILED,
  COMPLETED
}

/**
 * Extracts duration of a video Uri using Android's MediaMetadataRetriever
 */
fun extractVideoDurationMs(context: Context, uri: Uri): Long {
  val retriever = MediaMetadataRetriever()
  return try {
    retriever.setDataSource(context, uri)
    val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
    durationStr?.toLongOrNull() ?: 0L
  } catch (e: Exception) {
    0L
  } finally {
    try {
      retriever.release()
    } catch (_: Exception) {}
  }
}

/**
 * Catchy Go Real Video Upload - Step 2:
 * - Media selection from Android gallery via zero-permission Photo Picker
 * - Duration validation (5 minutes or less)
 * - Real video preview using CatchyGoPlayer
 * - Title, description, category, tags, and visibility inputs
 * - Real streaming upload to Catchy Cloud Storage backend with live byte progress
 * - Upload failure handling with Retry capability
 * - Persisting video metadata to the existing database using authenticated user ID:
 *   title, description, category, tags, visibility, creator ID, storage URL, duration, and created time
 * - Kept unpublished from the public feed draft state
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CatchyGoUploadDialog(
  currentUser: UserAccount?,
  viewModel: AccountViewModel? = null,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  // Form State
  var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
  var videoDurationMs by remember { mutableLongStateOf(0L) }
  var durationError by remember { mutableStateOf<String?>(null) }

  var title by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(CATCHY_CATEGORIES.first()) }
  var selectedVisibility by remember { mutableStateOf(VISIBILITY_OPTIONS.first()) }
  var tags by remember { mutableStateOf("#CatchyGo #Reels") }

  // Upload Engine State
  var uploadStage by remember { mutableStateOf(UploadStage.DETAILS_FORM) }
  var uploadProgress by remember { mutableStateOf(UploadProgress(0L, 0L, 0)) }
  var uploadErrorMessage by remember { mutableStateOf<String?>(null) }
  var savedUploadedRecord by remember { mutableStateOf<CatchyGoUploadedVideo?>(null) }
  var activeUploadJob by remember { mutableStateOf<Job?>(null) }

  // Publishing State Machine for Step 3
  var isPublishing by remember { mutableStateOf(false) }
  var publishErrorMessage by remember { mutableStateOf<String?>(null) }

  // Optional Test Simulation Toggle for testing failure & retry UI
  var simulateTestFailure by remember { mutableStateOf(false) }

  // Zero-permission modern Android Photo/Video Picker
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      try {
        context.contentResolver.takePersistableUriPermission(
          uri,
          android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
      } catch (_: Exception) {}
      val duration = extractVideoDurationMs(context, uri)
      videoDurationMs = duration
      if (duration > MAX_VIDEO_DURATION_MS) {
        durationError = "Video duration is ${formatVideoDuration(duration)} (${duration / 1000}s). Catchy Go requires videos to be 5 minutes or less."
        selectedVideoUri = null
      } else {
        durationError = null
        selectedVideoUri = uri
      }
    }
  }

  // Function to publish the uploaded video to the public Catchy Go feed
  fun publishCurrentVideo() {
    val record = savedUploadedRecord ?: return
    if (isPublishing || record.isPublishedToFeed) return // Prevent duplicate publishing
    isPublishing = true
    publishErrorMessage = null

    coroutineScope.launch {
      if (viewModel != null) {
        val result = viewModel.publishUploadedVideo(record.id)
        result.fold(
          onSuccess = { updatedVideo ->
            savedUploadedRecord = updatedVideo
            isPublishing = false
          },
          onFailure = { error ->
            publishErrorMessage = error.localizedMessage ?: "Failed to publish video to feed. Please try again."
            isPublishing = false
          }
        )
      } else {
        try {
          val timestamp = System.currentTimeMillis()
          val dao = com.example.data.local.CatchyDatabase.getInstance(context).socialDao()
          val existing = dao.getCatchyGoUploadedVideoById(record.id)
          if (existing?.isPublishedToFeed == true) {
            publishErrorMessage = "Video has already been published to the Catchy Go feed."
            isPublishing = false
            return@launch
          }
          dao.markCatchyGoVideoAsPublished(record.id, timestamp)
          val updated = dao.getCatchyGoUploadedVideoById(record.id)
            ?: record.copy(isPublishedToFeed = true, publishedTime = timestamp)
          savedUploadedRecord = updated
          isPublishing = false
        } catch (e: Exception) {
          publishErrorMessage = e.localizedMessage ?: "Failed to publish video to feed."
          isPublishing = false
        }
      }
    }
  }

  // Function to execute or retry cloud storage upload
  fun startUpload(isRetry: Boolean = false) {
    val uri = selectedVideoUri ?: return
    val creatorId = currentUser?.id ?: "anon_creator_${System.currentTimeMillis()}"

    activeUploadJob?.cancel()
    uploadStage = UploadStage.UPLOADING
    uploadErrorMessage = null
    uploadProgress = UploadProgress(0L, 0L, 0)
    isPublishing = false
    publishErrorMessage = null

    activeUploadJob = coroutineScope.launch {
      val result = CatchyCloudStorageService.uploadVideo(
        context = context,
        videoUri = uri,
        creatorId = creatorId,
        simulateNetworkError = if (isRetry) false else simulateTestFailure,
        onProgress = { progress ->
          uploadProgress = progress
        }
      )

      when (result) {
        is CloudUploadResult.Success -> {
          val creationTimestamp = System.currentTimeMillis()
          val videoPlaybackUri = result.localFileUri ?: uri.toString()
          val savedVideo = if (viewModel != null) {
            viewModel.saveUploadedVideoMetadata(
              title = title.trim(),
              description = description.trim(),
              category = selectedCategory,
              tags = tags.trim(),
              visibility = selectedVisibility,
              creatorId = creatorId,
              storageUrl = result.storageUrl,
              localUri = videoPlaybackUri,
              duration = videoDurationMs,
              createdTime = creationTimestamp
            )
          } else {
            val record = CatchyGoUploadedVideo(
              title = title.trim(),
              description = description.trim(),
              category = selectedCategory,
              tags = tags.trim(),
              visibility = selectedVisibility,
              creatorId = creatorId,
              storageUrl = result.storageUrl,
              localUri = videoPlaybackUri,
              duration = videoDurationMs,
              createdTime = creationTimestamp,
              isPublishedToFeed = false
            )
            com.example.data.local.CatchyDatabase.getInstance(context).socialDao().insertCatchyGoUploadedVideo(record)
            record
          }
          savedUploadedRecord = savedVideo
          uploadStage = UploadStage.COMPLETED
        }
        is CloudUploadResult.Failure -> {
          uploadErrorMessage = result.errorMessage
          uploadStage = UploadStage.FAILED
        }
      }
    }
  }

  Dialog(
    onDismissRequest = {
      if (uploadStage != UploadStage.UPLOADING) {
        onDismiss()
      }
    },
    properties = DialogProperties(
      usePlatformDefaultWidth = false,
      dismissOnBackPress = (uploadStage != UploadStage.UPLOADING)
    )
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.85f)),
      color = Color(0xFF0B0D13)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(scrollState)
          .padding(horizontal = 20.dp, vertical = 24.dp)
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(
                  brush = Brush.linearGradient(listOf(CatchyGoRed, CatchyGoPink))
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.CloudUpload,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Catchy Go Video Upload",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "Step 2: Cloud Storage Upload & Metadata Persistence",
                style = MaterialTheme.typography.labelSmall,
                color = CatchyGoPink
              )
            }
          }

          if (uploadStage != UploadStage.UPLOADING) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f))
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color.White
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Authenticated user identity banner
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color(0xFF141824),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(CatchyGoRed, CatchyGoPink))),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = (currentUser?.fullName?.take(2) ?: "ME").uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = currentUser?.fullName ?: "Authenticated Creator",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "Creator ID: ${currentUser?.id ?: "N/A"} • @${currentUser?.userId ?: "CTY-CREATOR"}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = CatchyGoPink
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ----------------------------------------------------
        // STAGE-BASED RENDERING
        // ----------------------------------------------------
        when (uploadStage) {
          UploadStage.DETAILS_FORM -> {
            // 1. VIDEO SELECTION / REAL PREVIEW
            if (selectedVideoUri == null) {
              // Empty State: Select Video Button
              Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
                border = BorderStroke(
                  1.dp,
                  Brush.horizontalGradient(listOf(CatchyGoRed.copy(alpha = 0.5f), CatchyGoPink.copy(alpha = 0.5f)))
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(200.dp)
                  .clickable {
                    videoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                  }
                  .testTag("select_video_gallery_btn")
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.Center
                ) {
                  Box(
                    modifier = Modifier
                      .size(54.dp)
                      .clip(CircleShape)
                      .background(CatchyGoRed.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = Icons.Default.VideoLibrary,
                      contentDescription = "Select Video",
                      tint = CatchyGoRed,
                      modifier = Modifier.size(30.dp)
                    )
                  }
                  Spacer(modifier = Modifier.height(12.dp))
                  Text(
                    text = "Select Video from Gallery",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Maximum allowed duration: 5 minutes (300s)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8)
                  )
                }
              }
            } else {
              // Real Video Preview with CatchyGoPlayer
              Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = Color(0xFF10B981),
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Video Preview (${formatVideoDuration(videoDurationMs)} / 05:00 max)",
                      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                      color = Color.White
                    )
                  }

                  Text(
                    text = "Change Video",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CatchyGoPink,
                    modifier = Modifier
                      .clickable {
                        videoPickerLauncher.launch(
                          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                      }
                      .padding(4.dp)
                      .testTag("change_selected_video_btn")
                  )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Card(
                  shape = RoundedCornerShape(20.dp),
                  colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
                  border = BorderStroke(1.dp, CatchyGoPink.copy(alpha = 0.5f)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                ) {
                  CatchyGoPlayer(
                    videoUri = selectedVideoUri.toString(),
                    autoPlay = false,
                    isFullscreen = false,
                    modifier = Modifier.fillMaxSize()
                  )
                }
              }
            }

            // Error message if exceeds 5 minutes
            if (durationError != null) {
              Spacer(modifier = Modifier.height(12.dp))
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF450A0A),
                border = BorderStroke(1.dp, CatchyGoRed),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("video_duration_error_banner")
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = "Duration Error",
                    tint = CatchyGoRed,
                    modifier = Modifier.size(24.dp)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = "Duration Exceeded",
                      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                      color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = durationError ?: "",
                      style = MaterialTheme.typography.bodySmall,
                      color = Color(0xFFFCA5A5)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. VIDEO METADATA INPUT FIELDS
            Text(
              text = "Video Details",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Title Field
            OutlinedTextField(
              value = title,
              onValueChange = { if (it.length <= 100) title = it },
              label = { Text("Title *") },
              placeholder = { Text("Catchy title for your video (max 100 chars)") },
              singleLine = true,
              shape = RoundedCornerShape(14.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CatchyGoPink,
                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                focusedLabelColor = CatchyGoPink,
                unfocusedLabelColor = Color(0xFF94A3B8)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_video_title_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Description Field
            OutlinedTextField(
              value = description,
              onValueChange = { description = it },
              label = { Text("Description") },
              placeholder = { Text("Tell viewers what your video is about...") },
              minLines = 3,
              maxLines = 5,
              shape = RoundedCornerShape(14.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CatchyGoPink,
                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                focusedLabelColor = CatchyGoPink,
                unfocusedLabelColor = Color(0xFF94A3B8)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_video_description_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Field
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Category,
                contentDescription = null,
                tint = CatchyGoPink,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Category",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              CATCHY_CATEGORIES.forEach { category ->
                val isSelected = (selectedCategory == category)
                Surface(
                  shape = RoundedCornerShape(16.dp),
                  color = if (isSelected) CatchyGoRed else Color(0xFF1E2333),
                  border = if (isSelected) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                  modifier = Modifier
                    .clickable { selectedCategory = category }
                    .testTag("category_chip_$category")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    if (isSelected) {
                      Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                      text = category,
                      style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                      ),
                      color = Color.White
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tags Field
            OutlinedTextField(
              value = tags,
              onValueChange = { tags = it },
              label = { Text("Tags") },
              placeholder = { Text("#Catchy #Shorts #Technology") },
              leadingIcon = {
                Icon(
                  imageVector = Icons.Default.Tag,
                  contentDescription = null,
                  tint = CatchyGoPink,
                  modifier = Modifier.size(18.dp)
                )
              },
              singleLine = true,
              shape = RoundedCornerShape(14.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CatchyGoPink,
                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                focusedLabelColor = CatchyGoPink,
                unfocusedLabelColor = Color(0xFF94A3B8)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_video_tags_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Visibility Selector
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Visibility,
                contentDescription = null,
                tint = CatchyGoPink,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Visibility",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              VISIBILITY_OPTIONS.forEach { vis ->
                val isSelected = (selectedVisibility == vis)
                Surface(
                  shape = RoundedCornerShape(14.dp),
                  color = if (isSelected) CatchyGoRed.copy(alpha = 0.2f) else Color(0xFF1E2333),
                  border = BorderStroke(
                    1.dp,
                    if (isSelected) CatchyGoPink else Color.White.copy(alpha = 0.12f)
                  ),
                  modifier = Modifier
                    .weight(1f)
                    .clickable { selectedVisibility = vis }
                    .testTag("visibility_option_$vis")
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Icon(
                      imageVector = when (vis) {
                        "Public" -> Icons.Default.Public
                        "Followers Only" -> Icons.Default.Visibility
                        else -> Icons.Default.Lock
                      },
                      contentDescription = null,
                      tint = if (isSelected) CatchyGoPink else Color(0xFF94A3B8),
                      modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = vis,
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = if (isSelected) Color.White else Color(0xFF94A3B8)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive simulation toggle for verifying retry flow
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFF141824),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Test Network Failure & Retry",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                  )
                  Text(
                    text = "Simulates connection drop to test recovery UX",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8)
                  )
                }
                Switch(
                  checked = simulateTestFailure,
                  onCheckedChange = { simulateTestFailure = it },
                  colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = CatchyGoRed
                  ),
                  modifier = Modifier.testTag("simulate_failure_switch")
                )
              }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
              ) {
                Text("Cancel")
              }

              val canProceed = (selectedVideoUri != null && title.isNotBlank() && durationError == null)

              Button(
                onClick = {
                  if (canProceed) {
                    startUpload(isRetry = false)
                  }
                },
                enabled = canProceed,
                colors = ButtonDefaults.buttonColors(
                  containerColor = CatchyGoRed,
                  disabledContainerColor = Color.White.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                  .weight(1.5f)
                  .testTag("upload_video_start_btn")
              ) {
                Icon(
                  imageVector = Icons.Default.CloudUpload,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (canProceed) "Upload Video" else "Select Video First",
                  fontWeight = FontWeight.Bold,
                  color = if (canProceed) Color.White else Color(0xFF94A3B8)
                )
              }
            }
          }

          UploadStage.UPLOADING -> {
            // ----------------------------------------------------
            // ACTIVE STREAMING UPLOAD PROGRESS SCREEN
            // ----------------------------------------------------
            Card(
              shape = RoundedCornerShape(20.dp),
              colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
              border = BorderStroke(1.dp, CatchyGoPink.copy(alpha = 0.6f)),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Box(
                  modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                      Brush.linearGradient(listOf(CatchyGoRed.copy(alpha = 0.25f), CatchyGoPink.copy(alpha = 0.25f)))
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  CircularProgressIndicator(
                    progress = { (uploadProgress.percentage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.size(56.dp),
                    color = CatchyGoPink,
                    strokeWidth = 4.dp
                  )
                  Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                  )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                  text = "Uploading to Catchy Cloud Storage",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = "Streaming real video bytes to cloud storage backend...",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Progress Bar
                LinearProgressIndicator(
                  progress = { (uploadProgress.percentage / 100f).coerceIn(0f, 1f) },
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .testTag("upload_progress_bar"),
                  color = CatchyGoPink,
                  trackColor = Color.White.copy(alpha = 0.1f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "${uploadProgress.percentage}%",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = CatchyGoPink,
                    modifier = Modifier.testTag("upload_progress_percentage")
                  )

                  Text(
                    text = "${CatchyCloudStorageService.formatBytes(uploadProgress.bytesUploaded)} / ${CatchyCloudStorageService.formatBytes(uploadProgress.totalBytes)}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace),
                    color = Color.White
                  )
                }

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedButton(
                  onClick = {
                    activeUploadJob?.cancel()
                    uploadStage = UploadStage.DETAILS_FORM
                  },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF87171)),
                  border = BorderStroke(1.dp, Color(0xFFF87171).copy(alpha = 0.4f)),
                  shape = RoundedCornerShape(14.dp)
                ) {
                  Text("Cancel Upload")
                }
              }
            }
          }

          UploadStage.FAILED -> {
            // ----------------------------------------------------
            // ERROR STATE WITH ACTIONABLE RETRY
            // ----------------------------------------------------
            Card(
              shape = RoundedCornerShape(20.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1015)),
              border = BorderStroke(1.dp, CatchyGoRed),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("upload_failure_card")
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Box(
                  modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(CatchyGoRed.copy(alpha = 0.2f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = CatchyGoRed,
                    modifier = Modifier.size(34.dp)
                  )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                  text = "Upload Failed",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                  text = uploadErrorMessage ?: "A network interruption occurred during video upload.",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFFFCA5A5),
                  modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                  OutlinedButton(
                    onClick = { uploadStage = UploadStage.DETAILS_FORM },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                  ) {
                    Text("Edit Details")
                  }

                  Button(
                    onClick = { startUpload(isRetry = true) },
                    colors = ButtonDefaults.buttonColors(containerColor = CatchyGoRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                      .weight(1.3f)
                      .testTag("upload_retry_btn")
                  ) {
                    Icon(
                      imageVector = Icons.Default.Refresh,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Retry Upload", fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }

          UploadStage.COMPLETED -> {
            // ----------------------------------------------------
            // SUCCESSFUL UPLOAD & PUBLISH TO FEED FLOW (STEP 3)
            // ----------------------------------------------------
            val isPublished = savedUploadedRecord?.isPublishedToFeed == true

            Card(
              shape = RoundedCornerShape(20.dp),
              colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
              border = BorderStroke(1.dp, if (isPublished) Color(0xFF10B981) else CatchyCyan.copy(alpha = 0.6f)),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("upload_success_card")
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(22.dp)
              ) {
                // Header Banner
                Row(
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(
                    modifier = Modifier
                      .size(48.dp)
                      .clip(CircleShape)
                      .background(if (isPublished) Color(0xFF10B981).copy(alpha = 0.15f) else CatchyCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = if (isPublished) Icons.Default.CheckCircle else Icons.Default.CloudDone,
                      contentDescription = null,
                      tint = if (isPublished) Color(0xFF10B981) else CatchyCyan,
                      modifier = Modifier.size(28.dp)
                    )
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(
                      text = if (isPublished) "Published to Catchy Go!" else "Uploaded to Cloud",
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = Color.White
                    )
                    Text(
                      text = if (isPublished) "Live on Catchy Go Feed & Reels" else "Saved to Database as Unpublished Draft",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (isPublished) Color(0xFF10B981) else CatchyCyan
                    )
                  }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Metadata Details Card
                Surface(
                  shape = RoundedCornerShape(14.dp),
                  color = Color(0xFF141824),
                  border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        text = "PERSISTED VIDEO RECORD",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = CatchyGoPink
                      )
                      Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isPublished) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFFEAB308).copy(alpha = 0.2f)
                      ) {
                        Text(
                          text = if (isPublished) "● LIVE ON FEED" else "● UNPUBLISHED DRAFT",
                          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                          color = if (isPublished) Color(0xFF10B981) else Color(0xFFEAB308),
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    MetadataRow(label = "Title", value = savedUploadedRecord?.title ?: title)
                    MetadataRow(label = "Category", value = savedUploadedRecord?.category ?: selectedCategory)
                    MetadataRow(label = "Visibility", value = savedUploadedRecord?.visibility ?: selectedVisibility)
                    MetadataRow(label = "Creator", value = currentUser?.fullName ?: "Catchy Creator")
                    MetadataRow(label = "Creator ID", value = savedUploadedRecord?.creatorId ?: (currentUser?.id ?: "N/A"))
                    MetadataRow(label = "Duration", value = formatVideoDuration(savedUploadedRecord?.duration ?: videoDurationMs))
                    MetadataRow(
                      label = "Upload Time",
                      value = SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.US).format(Date(savedUploadedRecord?.createdTime ?: System.currentTimeMillis()))
                    )
                    if (isPublished && savedUploadedRecord?.publishedTime != null) {
                      MetadataRow(
                        label = "Published Time",
                        value = SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.US).format(Date(savedUploadedRecord!!.publishedTime!!))
                      )
                    }
                    MetadataRow(
                      label = "Feed Status",
                      value = if (isPublished) "Published (Visible in Feed)" else "Unpublished Draft (Hidden)"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = "Storage URL:",
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = Color(0xFF94A3B8)
                    )
                    Text(
                      text = savedUploadedRecord?.storageUrl ?: "",
                      style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                      color = CatchyCyan,
                      modifier = Modifier.testTag("uploaded_storage_url")
                    )
                  }
                }

                // Publish Error Message Banner
                if (publishErrorMessage != null) {
                  Spacer(modifier = Modifier.height(14.dp))
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFEF4444).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier.padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(20.dp)
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = publishErrorMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFEF4444),
                        modifier = Modifier.weight(1f)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                if (isPublished) {
                  // Already published: Show confirmation and prevent duplicate publishing
                  Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("upload_success_done_btn")
                  ) {
                    Icon(
                      imageVector = Icons.Default.Check,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                      tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Done (View in Catchy Go)", fontWeight = FontWeight.Bold, color = Color.White)
                  }
                } else {
                  // Not published yet: Allow user to publish to feed or keep as draft
                  Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                  ) {
                    Button(
                      onClick = { publishCurrentVideo() },
                      enabled = !isPublishing,
                      colors = ButtonDefaults.buttonColors(containerColor = CatchyGoRed),
                      shape = RoundedCornerShape(16.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("catchy_go_publish_btn")
                    ) {
                      if (isPublishing) {
                        CircularProgressIndicator(
                          strokeWidth = 2.dp,
                          color = Color.White,
                          modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Publishing to Feed...", fontWeight = FontWeight.Bold, color = Color.White)
                      } else {
                        Icon(
                          imageVector = Icons.Default.Public,
                          contentDescription = null,
                          modifier = Modifier.size(18.dp),
                          tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Publish Video to Feed", fontWeight = FontWeight.Bold, color = Color.White)
                      }
                    }

                    OutlinedButton(
                      onClick = onDismiss,
                      enabled = !isPublishing,
                      border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                      shape = RoundedCornerShape(16.dp),
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("keep_draft_btn")
                    ) {
                      Text("Keep as Unpublished Draft", color = Color(0xFF94A3B8))
                    }
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(30.dp))
      }
    }
  }
}

@Composable
private fun MetadataRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = Color(0xFF94A3B8)
    )
    Text(
      text = value,
      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
      color = Color.White
    )
  }
}
