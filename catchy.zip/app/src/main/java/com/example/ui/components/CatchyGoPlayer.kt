package com.example.ui.components

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

// Catchy Go Visual Palette
val CatchyGoRed = Color(0xFFFF2247)
val CatchyGoPink = Color(0xFFFF2E93)
val CatchyGoOrange = Color(0xFFFF7A00)
val CatchyGoDarkSurface = Color(0xFF0D0F15)

/**
 * Formats milliseconds into mm:ss format
 */
fun formatVideoDuration(millis: Long): String {
  if (millis <= 0) return "00:00"
  val totalSec = millis / 1000
  val min = totalSec / 60
  val sec = totalSec % 60
  return String.format(Locale.getDefault(), "%02d:%02d", min, sec)
}

/**
 * Real Media3 / ExoPlayer Composable for Catchy Go & Reels.
 * Supports play, pause, seek, duration, mute/volume, fullscreen toggle,
 * buffering state, error state, and retry.
 */
@OptIn(UnstableApi::class)
@Composable
fun CatchyGoPlayer(
  videoUri: String,
  modifier: Modifier = Modifier,
  autoPlay: Boolean = false,
  isFullscreen: Boolean = false,
  onToggleFullscreen: (() -> Unit)? = null,
  onPlayerClick: (() -> Unit)? = null
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  var isPlaying by remember { mutableStateOf(autoPlay) }
  var isLoading by remember { mutableStateOf(true) }
  var playbackError by remember { mutableStateOf<String?>(null) }
  var isMuted by remember { mutableStateOf(false) }

  var durationMs by remember { mutableLongStateOf(0L) }
  var currentPositionMs by remember { mutableLongStateOf(0L) }
  var isSeeking by remember { mutableStateOf(false) }
  var seekPositionMs by remember { mutableLongStateOf(0L) }

  var showControls by remember { mutableStateOf(true) }

  // Initialize ExoPlayer safely
  val exoPlayer = remember {
    ExoPlayer.Builder(context).build().apply {
      repeatMode = Player.REPEAT_MODE_ALL
      playWhenReady = autoPlay
    }
  }

  // Bind MediaItem and Listeners
  LaunchedEffect(videoUri) {
    try {
      isLoading = true
      playbackError = null
      val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
      exoPlayer.setMediaItem(mediaItem)
      exoPlayer.prepare()
      if (autoPlay) {
        exoPlayer.play()
      }
    } catch (e: Exception) {
      isLoading = false
      playbackError = e.localizedMessage ?: "Failed to initialize video playback"
    }
  }

  // Player Listener for Real State Feedback
  DisposableEffect(exoPlayer) {
    val listener = object : Player.Listener {
      override fun onPlaybackStateChanged(playbackState: Int) {
        when (playbackState) {
          Player.STATE_BUFFERING -> {
            isLoading = true
            playbackError = null
          }
          Player.STATE_READY -> {
            isLoading = false
            playbackError = null
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
          }
          Player.STATE_ENDED -> {
            isLoading = false
            isPlaying = false
          }
          Player.STATE_IDLE -> {
            isLoading = false
          }
        }
      }

      override fun onPlayerError(error: PlaybackException) {
        isLoading = false
        isPlaying = false
        playbackError = error.message ?: "Network error loading video"
      }

      override fun onIsPlayingChanged(playing: Boolean) {
        isPlaying = playing
      }
    }

    exoPlayer.addListener(listener)

    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.stop()
      exoPlayer.clearMediaItems()
      exoPlayer.release()
    }
  }

  // Lifecycle observer to pause playback when activity backgrounded
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE -> {
          exoPlayer.pause()
        }
        Lifecycle.Event.ON_RESUME -> {
          if (isPlaying) {
            exoPlayer.play()
          }
        }
        else -> {}
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  // Periodic position ticker
  LaunchedEffect(isPlaying, isSeeking) {
    while (isPlaying && !isSeeking) {
      currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
      durationMs = exoPlayer.duration.coerceAtLeast(0L)
      delay(300)
    }
  }

  // Auto-hide controls timer
  LaunchedEffect(showControls, isPlaying) {
    if (showControls && isPlaying) {
      delay(3500)
      showControls = false
    }
  }

  Box(
    modifier = modifier
      .clip(if (isFullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(20.dp))
      .background(CatchyGoDarkSurface)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) {
        showControls = !showControls
        onPlayerClick?.invoke()
      }
      .testTag("catchy_go_player_surface")
  ) {
    // 1. AndroidView wrapping Media3 PlayerView
    AndroidView(
      factory = { ctx ->
        PlayerView(ctx).apply {
          player = exoPlayer
          useController = false // Custom Catchy Go UI
          resizeMode = if (isFullscreen) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT
          } else {
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
          }
          layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
        }
      },
      update = { playerView ->
        playerView.player = exoPlayer
        playerView.resizeMode = if (isFullscreen) {
          AspectRatioFrameLayout.RESIZE_MODE_FIT
        } else {
          AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        }
      },
      modifier = Modifier.fillMaxSize()
    )

    // 2. Loading State: Circular indicator with Catchy Pink/Red
    if (isLoading && playbackError == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center
      ) {
        CircularProgressIndicator(
          color = CatchyGoPink,
          strokeWidth = 3.dp,
          modifier = Modifier.size(44.dp)
        )
      }
    }

    // 3. Playback Error State with Retry Button
    if (playbackError != null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.85f))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.ErrorOutline,
            contentDescription = "Playback error",
            tint = CatchyGoRed,
            modifier = Modifier.size(42.dp)
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "Video Playback Error",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = playbackError ?: "Unable to stream video",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF94A3B8),
            maxLines = 2
          )
          Spacer(modifier = Modifier.height(14.dp))
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = CatchyGoRed,
            modifier = Modifier
              .clickable {
                playbackError = null
                isLoading = true
                exoPlayer.prepare()
                exoPlayer.play()
              }
              .testTag("player_retry_button")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Retry",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Retry",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
          }
        }
      }
    }

    // 4. Custom Cinematic Overlay Controls (Animated Fade)
    AnimatedVisibility(
      visible = showControls && playbackError == null,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.fillMaxSize()
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Black.copy(alpha = 0.55f),
                Color.Transparent,
                Color.Black.copy(alpha = 0.75f)
              )
            )
          )
      ) {
        // Top row: Quick mute and fullscreen actions
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter)
            .padding(horizontal = 12.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Volume / Mute button
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.45f))
              .clickable {
                isMuted = !isMuted
                exoPlayer.volume = if (isMuted) 0f else 1f
              },
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
              contentDescription = if (isMuted) "Unmute" else "Mute",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
          }

          // Fullscreen toggle button
          if (onToggleFullscreen != null) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable { onToggleFullscreen() },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                contentDescription = if (isFullscreen) "Exit Fullscreen" else "Fullscreen",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }

        // Center: Primary Play / Pause Button with red-to-pink glow
        Box(
          modifier = Modifier
            .size(60.dp)
            .align(Alignment.Center)
            .shadow(
              elevation = 8.dp,
              shape = CircleShape,
              spotColor = CatchyGoRed,
              ambientColor = CatchyGoPink
            )
            .clip(CircleShape)
            .background(
              brush = Brush.linearGradient(
                listOf(CatchyGoRed, CatchyGoPink)
              )
            )
            .clickable {
              if (exoPlayer.isPlaying) {
                exoPlayer.pause()
                isPlaying = false
              } else {
                exoPlayer.play()
                isPlaying = true
              }
            }
            .testTag("catchy_go_play_pause_btn"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlaying) "Pause" else "Play",
            tint = Color.White,
            modifier = Modifier.size(32.dp)
          )
        }

        // Bottom Controls: Time & Seek Bar
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
          // Time details (Current / Total)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = formatVideoDuration(if (isSeeking) seekPositionMs else currentPositionMs),
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
              color = Color.White
            )
            Text(
              text = formatVideoDuration(durationMs),
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
              color = Color(0xFF94A3B8)
            )
          }

          // Modern Seek Scrub Slider
          val activePos = (if (isSeeking) seekPositionMs else currentPositionMs).toFloat()
          val maxPos = durationMs.coerceAtLeast(1L).toFloat()

          Slider(
            value = activePos.coerceIn(0f, maxPos),
            onValueChange = { newPos ->
              isSeeking = true
              seekPositionMs = newPos.toLong()
            },
            onValueChangeFinished = {
              exoPlayer.seekTo(seekPositionMs)
              isSeeking = false
            },
            valueRange = 0f..maxPos,
            colors = SliderDefaults.colors(
              thumbColor = CatchyGoPink,
              activeTrackColor = CatchyGoRed,
              inactiveTrackColor = Color.White.copy(alpha = 0.25f)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(24.dp)
              .testTag("player_seek_slider")
          )
        }
      }
    }
  }
}
