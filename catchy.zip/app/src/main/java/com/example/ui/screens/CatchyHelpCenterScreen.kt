package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyCommunityGuidelines
import com.example.data.model.CatchyHelpAnswer
import com.example.data.model.CatchyHelpArticles
import com.example.data.model.CatchyHelpCategories
import com.example.data.model.CatchyHelpPost
import com.example.data.model.HelpCategory
import com.example.data.model.HelpCenterArticle
import com.example.data.model.SupportTicket
import com.example.data.model.UserAccount
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.HelpCenterTab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Full-screen Dialog for Catchy Help & Community Support.
 * Accessible from the top header "?" icon and the ☰ Catchy Menu.
 */
@Composable
fun CatchyHelpCenterDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val currentTab by viewModel.helpCenterTab.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val activeHelpPost by viewModel.activeHelpPost.collectAsState()
  val activeHelpAnswers by viewModel.activeHelpAnswers.collectAsState()
  val helpAnswerInput by viewModel.helpAnswerInput.collectAsState()
  val isCreatingHelpPost by viewModel.isCreatingHelpPost.collectAsState()
  val editingHelpPost by viewModel.editingHelpPost.collectAsState()
  val showReportDialog by viewModel.showReportDialog.collectAsState()
  val reportTargetType by viewModel.reportTargetType.collectAsState()
  val reportTargetTitle by viewModel.reportTargetTitle.collectAsState()
  val showCreateTicketSheet by viewModel.showCreateTicketSheet.collectAsState()
  val selectedArticle by viewModel.selectedArticle.collectAsState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("catchy_help_center_screen"),
      color = MaterialTheme.colorScheme.background
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // 1. Top Bar: Back/Close, Catchy Logo, Help Title, Ask Button
        HelpCenterTopBar(
          onDismiss = onDismiss,
          onAskClick = { viewModel.openCreateHelpPost() }
        )

        // 2. Tab Navigation
        HelpCenterNavigationTabs(
          currentTab = currentTab,
          onSelectTab = { viewModel.setHelpCenterTab(it) }
        )

        // 3. Tab Content
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          when (currentTab) {
            HelpCenterTab.COMMUNITY_FEED -> CommunityFeedTab(viewModel = viewModel)
            HelpCenterTab.MY_HELP -> MyHelpTab(viewModel = viewModel)
            HelpCenterTab.CATEGORIES -> CategoriesTab(viewModel = viewModel)
            HelpCenterTab.NEARBY -> NearbyHelpTab(viewModel = viewModel)
            HelpCenterTab.SAVED -> SavedHelpTab(viewModel = viewModel)
            HelpCenterTab.SUPPORT_TICKETS -> OfficialSupportTab(viewModel = viewModel)
            HelpCenterTab.ARTICLES -> HelpArticlesTab(viewModel = viewModel)
            HelpCenterTab.GUIDELINES -> CommunityGuidelinesTab()
          }
        }
      }
    }

    // Modal: Help Post Detail & Answers
    if (activeHelpPost != null) {
      HelpPostDetailDialog(
        post = activeHelpPost!!,
        answers = activeHelpAnswers,
        answerInput = helpAnswerInput,
        replyToAnswerId = viewModel.replyToAnswerId.collectAsState().value,
        currentUser = currentUser,
        onAnswerInputChange = { viewModel.onHelpAnswerInputChange(it) },
        onSetReplyTo = { viewModel.setReplyToAnswerId(it) },
        onSubmitAnswer = { viewModel.submitHelpAnswer() },
        onToggleHelpful = { viewModel.toggleAnswerHelpful(it) },
        onMarkBestSolution = { viewModel.markAnswerBestSolution(it) },
        onToggleSave = { viewModel.toggleSaveHelpPost(activeHelpPost!!.id) },
        isSaved = viewModel.savedHelpPostIds.collectAsState().value.contains(activeHelpPost!!.id),
        onStatusChange = { status -> viewModel.markHelpPostStatus(activeHelpPost!!.id, status) },
        onEdit = { viewModel.startEditingHelpPost(activeHelpPost!!) },
        onDelete = { viewModel.deleteHelpPost(activeHelpPost!!.id) },
        onReportPost = {
          viewModel.openReportDialog("post", activeHelpPost!!.id, activeHelpPost!!.problemTitle)
        },
        onReportAnswer = { answer ->
          viewModel.openReportDialog("answer", answer.id, "Answer by ${answer.authorName}")
        },
        onBlockUser = { userId -> viewModel.blockUser(userId) },
        onDismiss = { viewModel.closeHelpDetail() }
      )
    }

    // Modal: Create Help Post
    if (isCreatingHelpPost) {
      CreateHelpPostDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeCreateHelpPost() }
      )
    }

    // Modal: Edit Help Post
    if (editingHelpPost != null) {
      EditHelpPostDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.cancelEditingHelpPost() }
      )
    }

    // Modal: Report Dialog
    if (showReportDialog) {
      ReportDialog(
        targetType = reportTargetType,
        targetTitle = reportTargetTitle,
        onSubmit = { reason, details, blockUser ->
          viewModel.submitReport(reason, details)
          if (blockUser && viewModel.reportTargetId.value.isNotBlank()) {
            viewModel.blockUser(viewModel.reportTargetId.value)
          }
        },
        onDismiss = { viewModel.closeReportDialog() }
      )
    }

    // Modal: Create Support Ticket
    if (showCreateTicketSheet) {
      CreateSupportTicketDialog(
        viewModel = viewModel,
        onDismiss = { viewModel.closeCreateSupportTicket() }
      )
    }

    // Modal: Help Article Detail
    if (selectedArticle != null) {
      HelpArticleDetailDialog(
        article = selectedArticle!!,
        onDismiss = { viewModel.selectArticle(null) },
        onContactSupport = {
          viewModel.selectArticle(null)
          viewModel.openCreateSupportTicket(
            presetSubject = "Question regarding ${selectedArticle!!.title}",
            presetCategory = "General Inquiry",
            relatedRef = selectedArticle!!.id
          )
        }
      )
    }
  }
}

/**
 * Top Header of Catchy Help & Community Support
 */
@Composable
private fun HelpCenterTopBar(
  onDismiss: () -> Unit,
  onAskClick: () -> Unit
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    shadowElevation = 1.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("help_center_close_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back to Catchy",
            tint = MaterialTheme.colorScheme.onSurface
          )
        }

        Spacer(modifier = Modifier.width(6.dp))

        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan)))
            .padding(1.5.dp),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(9.dp))
              .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.HelpOutline,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = "Catchy Help",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.onBackground
          )
          Text(
            text = "Community Support & Help Center",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Button(
        onClick = onAskClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
        modifier = Modifier.testTag("help_center_ask_button")
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Ask for Help",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        )
      }
    }
  }
}

/**
 * Scrollable Navigation Tabs for Help Center
 */
@Composable
private fun HelpCenterNavigationTabs(
  currentTab: HelpCenterTab,
  onSelectTab: (HelpCenterTab) -> Unit
) {
  val tabs = listOf(
    HelpCenterTab.COMMUNITY_FEED to "Community",
    HelpCenterTab.MY_HELP to "My Help",
    HelpCenterTab.CATEGORIES to "Categories",
    HelpCenterTab.NEARBY to "Nearby",
    HelpCenterTab.SAVED to "Saved",
    HelpCenterTab.SUPPORT_TICKETS to "Official Support",
    HelpCenterTab.ARTICLES to "Help & FAQs",
    HelpCenterTab.GUIDELINES to "Guidelines"
  )

  val selectedIndex = tabs.indexOfFirst { it.first == currentTab }.coerceAtLeast(0)

  ScrollableTabRow(
    selectedTabIndex = selectedIndex,
    edgePadding = 12.dp,
    containerColor = MaterialTheme.colorScheme.surface,
    contentColor = CatchyCyan,
    indicator = { tabPositions ->
      if (selectedIndex < tabPositions.size) {
        TabRowDefaults.SecondaryIndicator(
          Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
          color = CatchyCyan,
          height = 3.dp
        )
      }
    },
    divider = {
      Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    }
  ) {
    tabs.forEachIndexed { index, (tab, title) ->
      val isSelected = currentTab == tab
      Tab(
        selected = isSelected,
        onClick = { onSelectTab(tab) },
        modifier = Modifier.testTag("help_tab_${tab.name.lowercase()}"),
        text = {
          Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) CatchyCyan else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      )
    }
  }
}

/**
 * TAB 1: COMMUNITY FEED
 * Search, Categories Filter, Status Filter, Sort, and Help Requests List.
 */
@Composable
private fun CommunityFeedTab(viewModel: AccountViewModel) {
  val posts by viewModel.filteredHelpPosts.collectAsState()
  val searchQuery by viewModel.helpSearchQuery.collectAsState()
  val selectedCat by viewModel.helpSelectedCategory.collectAsState()
  val statusFilter by viewModel.helpStatusFilter.collectAsState()
  val sortOrder by viewModel.helpSortOrder.collectAsState()
  val savedPostIds by viewModel.savedHelpPostIds.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))

      // Search Field
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { viewModel.onHelpSearchQueryChange(it) },
        placeholder = {
          Text("Search help posts, keywords, tags or city...")
        },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(20.dp)
          )
        },
        trailingIcon = {
          if (searchQuery.isNotBlank()) {
            IconButton(onClick = { viewModel.clearHelpSearchQuery() }) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Clear search",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        },
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = CatchyCyan,
          unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        ),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("help_search_input")
      )
    }

    // Categories filter horizontal chips
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(CatchyHelpCategories.NAMES) { catName ->
          val isSelected = selectedCat.equals(catName, ignoreCase = true)
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isSelected) CatchyIndigo else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = BorderStroke(
              1.dp,
              if (isSelected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
            ),
            modifier = Modifier
              .clickable { viewModel.selectHelpCategory(catName) }
              .testTag("help_cat_chip_$catName")
          ) {
            Text(
              text = catName,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
            )
          }
        }
      }
    }

    // Status and Sort row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Status chips: All / Open / Resolved
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("All", "Open", "Resolved").forEach { status ->
            val isSelected = statusFilter.equals(status, ignoreCase = true)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) CatchyCyan.copy(alpha = 0.2f) else Color.Transparent,
              border = BorderStroke(
                1.dp,
                if (isSelected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
              ),
              modifier = Modifier.clickable { viewModel.setHelpStatusFilter(status) }
            ) {
              Text(
                text = status,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) CatchyCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
              )
            }
          }
        }

        // Sort selector
        var showSortMenu by remember { mutableStateOf(false) }
        Box {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
            modifier = Modifier.clickable { showSortMenu = true }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = sortOrder,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          DropdownMenu(
            expanded = showSortMenu,
            onDismissRequest = { showSortMenu = false }
          ) {
            listOf("Newest", "Most Helpful", "Most Answers").forEach { option ->
              DropdownMenuItem(
                text = { Text(option) },
                onClick = {
                  viewModel.setHelpSortOrder(option)
                  showSortMenu = false
                }
              )
            }
          }
        }
      }
    }

    // Ask banner card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Need Assistance?",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
            Text(
              text = "Reach thousands of community members nearby and across Catchy.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Button(
            onClick = { viewModel.openCreateHelpPost(selectedCat.takeIf { it != "All" }) },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
          ) {
            Text("Ask Now", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
          }
        }
      }
    }

    // Posts count indicator
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${posts.size} Community Help Requests",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Empty state
    if (posts.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.HelpOutline,
              contentDescription = null,
              tint = CatchyCyan.copy(alpha = 0.6f),
              modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "No help requests found",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Try clearing search filters or be the first to ask in this category!",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = {
                viewModel.clearHelpSearchQuery()
                viewModel.selectHelpCategory("All")
                viewModel.setHelpStatusFilter("All")
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan)
            ) {
              Text("Reset Filters", color = Color.Black)
            }
          }
        }
      }
    } else {
      items(posts, key = { it.id }) { post ->
        HelpPostCard(
          post = post,
          isSaved = savedPostIds.contains(post.id),
          isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
          onCardClick = { viewModel.openHelpDetail(post) },
          onToggleSave = { viewModel.toggleSaveHelpPost(post.id) },
          onStatusToggle = {
            val nextStatus = if (post.status == "Resolved") "Open" else "Resolved"
            viewModel.markHelpPostStatus(post.id, nextStatus)
          },
          onEdit = { viewModel.startEditingHelpPost(post) },
          onDelete = { viewModel.deleteHelpPost(post.id) },
          onReport = { viewModel.openReportDialog("post", post.id, post.problemTitle) },
          onBlock = { viewModel.blockUser(post.authorUserId) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * Help Post Card in Community List
 */
@Composable
private fun HelpPostCard(
  post: CatchyHelpPost,
  isSaved: Boolean,
  isOwner: Boolean,
  onCardClick: () -> Unit,
  onToggleSave: () -> Unit,
  onStatusToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onReport: () -> Unit,
  onBlock: () -> Unit
) {
  var showMenu by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onCardClick() }
      .testTag("help_post_card_${post.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Top row: Author Info, Badges, and Overflow menu
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          // Author Avatar
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = post.authorName.take(2).uppercase(),
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = post.authorName,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
              if (post.isVerifiedAuthor) {
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.Verified,
                  contentDescription = "Verified",
                  tint = CatchyCyan,
                  modifier = Modifier.size(15.dp)
                )
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "@${post.authorUserId}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = CatchyCyan
              )
              Text(
                text = " • ",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(post.timestamp))
              Text(
                text = dateStr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Bookmark & Overflow
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onToggleSave,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = if (isSaved) "Saved" else "Save",
              tint = if (isSaved) CatchyCyan else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
          }

          Box {
            IconButton(
              onClick = { showMenu = true },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Options",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
              )
            }

            DropdownMenu(
              expanded = showMenu,
              onDismissRequest = { showMenu = false }
            ) {
              if (isOwner) {
                DropdownMenuItem(
                  text = { Text(if (post.status == "Resolved") "Mark as Open" else "Mark as Resolved") },
                  onClick = {
                    onStatusToggle()
                    showMenu = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Edit Request") },
                  onClick = {
                    onEdit()
                    showMenu = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Delete Request", color = Color(0xFFEF4444)) },
                  onClick = {
                    onDelete()
                    showMenu = false
                  }
                )
              } else {
                DropdownMenuItem(
                  text = { Text("Report Post") },
                  onClick = {
                    onReport()
                    showMenu = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Block @${post.authorUserId}") },
                  onClick = {
                    onBlock()
                    showMenu = false
                  }
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Badges: Category, Status, Location
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
      ) {
        // Category Badge
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = CatchyIndigo.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, CatchyIndigo.copy(alpha = 0.35f))
        ) {
          Text(
            text = post.category,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CatchyIndigoLight,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        // Status Badge
        val isResolved = post.status.equals("Resolved", ignoreCase = true)
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = if (isResolved) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f),
          border = BorderStroke(
            1.dp,
            if (isResolved) Color(0xFF10B981).copy(alpha = 0.4f) else Color(0xFFF59E0B).copy(alpha = 0.4f)
          )
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = if (isResolved) Icons.Default.CheckCircle else Icons.Default.HelpOutline,
              contentDescription = null,
              tint = if (isResolved) Color(0xFF10B981) else Color(0xFFF59E0B),
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isResolved) "Resolved" else "Open Request",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = if (isResolved) Color(0xFF10B981) else Color(0xFFF59E0B)
            )
          }
        }

        // Location Badge
        if (!post.location.isNullOrBlank()) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = post.location!!,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Problem Title
      Text(
        text = post.problemTitle,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Problem Description
      Text(
        text = post.problemDescription,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 3,
        overflow = TextOverflow.Ellipsis
      )

      // Media / Attachment Label
      if (!post.mediaLabel.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = CatchyCyan.copy(alpha = 0.1f),
          border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.25f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Attachment: ${post.mediaLabel}",
              style = MaterialTheme.typography.labelSmall,
              color = CatchyCyan
            )
          }
        }
      }

      // Tags
      if (post.tags.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
          post.tags.split(" ").filter { it.isNotBlank() }.forEach { tag ->
            val displayTag = if (tag.startsWith("#")) tag else "#$tag"
            Text(
              text = displayTag,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
              color = CatchyCyan
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
      Spacer(modifier = Modifier.height(10.dp))

      // Bottom Row: Answers Count & Helpful Count
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.QuestionAnswer,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${post.answersCount} Answers",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.width(16.dp))

          Icon(
            imageVector = Icons.Default.ThumbUp,
            contentDescription = null,
            tint = Color(0xFFF59E0B),
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "${post.helpfulCount} Helpful",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        TextButton(
          onClick = onCardClick,
          modifier = Modifier.height(32.dp)
        ) {
          Text(
            text = "View & Answer",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CatchyCyan
          )
        }
      }
    }
  }
}

/**
 * TAB 2: MY HELP
 * Sub-tabs: "My Requests" (created by me) and "Help I Gave" (answered by me).
 */
@Composable
private fun MyHelpTab(viewModel: AccountViewModel) {
  var selectedSubTab by remember { mutableStateOf(0) } // 0 = My Requests, 1 = Help I Gave
  val myPosts by viewModel.myHelpPosts.collectAsState()
  val myAnswered by viewModel.myAnsweredHelpPosts.collectAsState()
  val savedPostIds by viewModel.savedHelpPostIds.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = { selectedSubTab = 0 },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (selectedSubTab == 0) CatchyIndigo else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
          ),
          modifier = Modifier.weight(1f)
        ) {
          Text(
            text = "My Requests (${myPosts.size})",
            color = if (selectedSubTab == 0) Color.White else MaterialTheme.colorScheme.onSurface
          )
        }

        Button(
          onClick = { selectedSubTab = 1 },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (selectedSubTab == 1) CatchyIndigo else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
          ),
          modifier = Modifier.weight(1f)
        ) {
          Text(
            text = "Help I Gave (${myAnswered.size})",
            color = if (selectedSubTab == 1) Color.White else MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    if (selectedSubTab == 0) {
      if (myPosts.isEmpty()) {
        item {
          EmptyCardNotice(
            title = "You haven't posted any help requests",
            description = "Whenever you need advice, lost item tracking, or community assistance, tap 'Ask for Help'.",
            actionLabel = "Ask for Help",
            onAction = { viewModel.openCreateHelpPost() }
          )
        }
      } else {
        items(myPosts, key = { it.id }) { post ->
          HelpPostCard(
            post = post,
            isSaved = savedPostIds.contains(post.id),
            isOwner = true,
            onCardClick = { viewModel.openHelpDetail(post) },
            onToggleSave = { viewModel.toggleSaveHelpPost(post.id) },
            onStatusToggle = {
              val nextStatus = if (post.status == "Resolved") "Open" else "Resolved"
              viewModel.markHelpPostStatus(post.id, nextStatus)
            },
            onEdit = { viewModel.startEditingHelpPost(post) },
            onDelete = { viewModel.deleteHelpPost(post.id) },
            onReport = {},
            onBlock = {}
          )
        }
      }
    } else {
      if (myAnswered.isEmpty()) {
        item {
          EmptyCardNotice(
            title = "No answers submitted yet",
            description = "Browse open requests in the Community Feed and share your knowledge or local tips!",
            actionLabel = "Browse Community Requests",
            onAction = { viewModel.setHelpCenterTab(HelpCenterTab.COMMUNITY_FEED) }
          )
        }
      } else {
        items(myAnswered, key = { it.id }) { post ->
          HelpPostCard(
            post = post,
            isSaved = savedPostIds.contains(post.id),
            isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
            onCardClick = { viewModel.openHelpDetail(post) },
            onToggleSave = { viewModel.toggleSaveHelpPost(post.id) },
            onStatusToggle = {
              val nextStatus = if (post.status == "Resolved") "Open" else "Resolved"
              viewModel.markHelpPostStatus(post.id, nextStatus)
            },
            onEdit = { viewModel.startEditingHelpPost(post) },
            onDelete = { viewModel.deleteHelpPost(post.id) },
            onReport = { viewModel.openReportDialog("post", post.id, post.problemTitle) },
            onBlock = { viewModel.blockUser(post.authorUserId) }
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * TAB 3: CATEGORIES BROWSER
 */
@Composable
private fun CategoriesTab(viewModel: AccountViewModel) {
  val categories = CatchyHelpCategories.ALL

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "Explore Support Categories",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Select any category to filter community inquiries or submit a targeted help request.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
    }

    items(categories) { category ->
      CategoryRowCard(
        category = category,
        onClick = {
          viewModel.selectHelpCategory(category.name)
          viewModel.setHelpCenterTab(HelpCenterTab.COMMUNITY_FEED)
        },
        onAskInCategory = {
          viewModel.openCreateHelpPost(presetCategory = category.name)
        }
      )
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun CategoryRowCard(
  category: HelpCategory,
  onClick: () -> Unit,
  onAskInCategory: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(category.colorHex).copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        val icon = getCategoryIcon(category.iconName)
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = Color(category.colorHex),
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = category.name,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
        Text(
          text = category.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      IconButton(
        onClick = onAskInCategory,
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Add,
          contentDescription = "Ask in ${category.name}",
          tint = CatchyCyan,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

/**
 * TAB 4: NEARBY HELP (Location-based support)
 */
@Composable
private fun NearbyHelpTab(viewModel: AccountViewModel) {
  val nearbyPosts by viewModel.nearbyHelpPosts.collectAsState()
  val locationQuery by viewModel.helpNearbyLocationQuery.collectAsState()
  val savedPostIds by viewModel.savedHelpPostIds.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  val popularLocations = listOf("Dhaka", "Chittagong", "Sylhet", "Rajshahi", "Khulna", "Dhanmondi", "Gulshan")

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Nearby Community Inquiries",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Connect with neighbors and local members needing assistance around your area.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(8.dp))

      // Location search input
      OutlinedTextField(
        value = locationQuery,
        onValueChange = { viewModel.onNearbyLocationQueryChange(it) },
        placeholder = { Text("Filter by neighborhood or city...") },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(20.dp)
          )
        },
        trailingIcon = {
          if (locationQuery.isNotBlank()) {
            IconButton(onClick = { viewModel.onNearbyLocationQueryChange("") }) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Clear",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Quick location chips
      LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(popularLocations) { loc ->
          val isSelected = locationQuery.equals(loc, ignoreCase = true)
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) CatchyCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            border = BorderStroke(
              1.dp,
              if (isSelected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
            ),
            modifier = Modifier.clickable { viewModel.onNearbyLocationQueryChange(loc) }
          ) {
            Text(
              text = loc,
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              ),
              color = if (isSelected) CatchyCyan else MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            )
          }
        }
      }
    }

    if (nearbyPosts.isEmpty()) {
      item {
        EmptyCardNotice(
          title = "No requests nearby in \"$locationQuery\"",
          description = "Be the first to post a neighborhood help request in your area!",
          actionLabel = "Ask in $locationQuery",
          onAction = { viewModel.openCreateHelpPost() }
        )
      }
    } else {
      items(nearbyPosts, key = { it.id }) { post ->
        HelpPostCard(
          post = post,
          isSaved = savedPostIds.contains(post.id),
          isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
          onCardClick = { viewModel.openHelpDetail(post) },
          onToggleSave = { viewModel.toggleSaveHelpPost(post.id) },
          onStatusToggle = {
            val nextStatus = if (post.status == "Resolved") "Open" else "Resolved"
            viewModel.markHelpPostStatus(post.id, nextStatus)
          },
          onEdit = { viewModel.startEditingHelpPost(post) },
          onDelete = { viewModel.deleteHelpPost(post.id) },
          onReport = { viewModel.openReportDialog("post", post.id, post.problemTitle) },
          onBlock = { viewModel.blockUser(post.authorUserId) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * TAB 5: SAVED HELP POSTS
 */
@Composable
private fun SavedHelpTab(viewModel: AccountViewModel) {
  val savedPosts by viewModel.savedHelpPosts.collectAsState()
  val savedPostIds by viewModel.savedHelpPostIds.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Saved Help Posts",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Quickly reference community answers, helpful advice, or ongoing requests.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
    }

    if (savedPosts.isEmpty()) {
      item {
        EmptyCardNotice(
          title = "No saved posts yet",
          description = "Tap the bookmark icon on any community help request to keep it handy here.",
          actionLabel = "Explore Community Feed",
          onAction = { viewModel.setHelpCenterTab(HelpCenterTab.COMMUNITY_FEED) }
        )
      }
    } else {
      items(savedPosts, key = { it.id }) { post ->
        HelpPostCard(
          post = post,
          isSaved = true,
          isOwner = currentUser != null && post.authorUserId == currentUser!!.userId,
          onCardClick = { viewModel.openHelpDetail(post) },
          onToggleSave = { viewModel.toggleSaveHelpPost(post.id) },
          onStatusToggle = {
            val nextStatus = if (post.status == "Resolved") "Open" else "Resolved"
            viewModel.markHelpPostStatus(post.id, nextStatus)
          },
          onEdit = { viewModel.startEditingHelpPost(post) },
          onDelete = { viewModel.deleteHelpPost(post.id) },
          onReport = { viewModel.openReportDialog("post", post.id, post.problemTitle) },
          onBlock = { viewModel.blockUser(post.authorUserId) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * TAB 6: OFFICIAL CATCHY SUPPORT
 * Support ticket submission, My Tickets list, and direct official channels.
 */
@Composable
private fun OfficialSupportTab(viewModel: AccountViewModel) {
  val myTickets by viewModel.mySupportTickets.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(CatchyCyan.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.SupportAgent,
                contentDescription = null,
                tint = CatchyCyan,
                modifier = Modifier.size(24.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Catchy Official Support",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
              Text(
                text = "Direct assistance for account, security & platform questions",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = "Need personal support from the Catchy Operations Team? Open a secure support ticket below.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(14.dp))
          Button(
            onClick = { viewModel.openCreateSupportTicket() },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("open_support_ticket_button")
          ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Open Support Ticket")
          }
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "My Support Tickets (${myTickets.size})",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }
    }

    if (myTickets.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "No open support tickets",
              style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "Your submitted tickets and support resolutions will appear here.",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(myTickets, key = { it.id }) { ticket ->
        TicketCard(ticket = ticket)
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun TicketCard(ticket: SupportTicket) {
  var isExpanded by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { isExpanded = !isExpanded }
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "#${ticket.id.take(8).uppercase()}",
          style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
          color = CatchyCyan
        )

        val statusColor = when (ticket.status.lowercase()) {
          "resolved" -> Color(0xFF10B981)
          "in review" -> CatchyCyan
          else -> Color(0xFFF59E0B)
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = statusColor.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
        ) {
          Text(
            text = ticket.status,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = statusColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = ticket.subject,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(4.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = ticket.category,
          style = MaterialTheme.typography.labelSmall,
          color = CatchyIndigoLight
        )
        Text(
          text = " • ",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ticket.createdAt))
        Text(
          text = dateStr,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      AnimatedVisibility(visible = isExpanded) {
        Column(modifier = Modifier.padding(top = 10.dp)) {
          Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Details:",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = ticket.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
          )
          if (!ticket.attachmentLabel.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Attached: ${ticket.attachmentLabel}",
              style = MaterialTheme.typography.labelSmall,
              color = CatchyCyan
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = CatchyCyan.copy(alpha = 0.1f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "Ticket Status: ${ticket.status}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CatchyCyan
              )
              Text(
                text = if (ticket.status.equals("Resolved", ignoreCase = true)) {
                  "This inquiry has been reviewed and resolved by Catchy Support."
                } else {
                  "Our support team reviews tickets within 24 hours. Updates will appear in your notifications."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }
  }
}

/**
 * TAB 7: HELP ARTICLES & FAQs
 */
@Composable
private fun HelpArticlesTab(viewModel: AccountViewModel) {
  val articles by viewModel.filteredArticles.collectAsState()
  val query by viewModel.articleSearchQuery.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Catchy Knowledge Base & FAQs",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Official guides on security, accounts, posting, messaging, and community standards.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(8.dp))

      OutlinedTextField(
        value = query,
        onValueChange = { viewModel.onArticleSearchQueryChange(it) },
        placeholder = { Text("Search help articles or topics...") },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = CatchyCyan,
            modifier = Modifier.size(20.dp)
          )
        },
        trailingIcon = {
          if (query.isNotBlank()) {
            IconButton(onClick = { viewModel.onArticleSearchQueryChange("") }) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Clear",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      )
    }

    items(articles, key = { it.id }) { article ->
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { viewModel.selectArticle(article) }
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = CatchyCyan.copy(alpha = 0.15f)
            ) {
              Text(
                text = article.topic,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CatchyCyan,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = article.title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = article.summary,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * TAB 8: COMMUNITY GUIDELINES
 */
@Composable
private fun CommunityGuidelinesTab() {
  val guidelines = CatchyCommunityGuidelines.RULES

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Catchy Community Standards",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Catchy is built on authentic identity, safety, and constructive community assistance.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
    }

    items(guidelines) { rule ->
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(CatchyIndigo.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = CatchyIndigoLight,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = rule.first,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = rule.second,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CatchyCyan.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "Enforcement & Fair Appeals",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = CatchyCyan
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Violations of Community Guidelines result in content removal, warnings, or account suspension. If you believe an action was taken in error, you can submit an appeal through Catchy Official Support.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

/**
 * MODAL: Help Post Detail & Answers Thread
 */
@Composable
private fun HelpPostDetailDialog(
  post: CatchyHelpPost,
  answers: List<CatchyHelpAnswer>,
  answerInput: String,
  replyToAnswerId: String?,
  currentUser: UserAccount?,
  onAnswerInputChange: (String) -> Unit,
  onSetReplyTo: (String?) -> Unit,
  onSubmitAnswer: () -> Unit,
  onToggleHelpful: (CatchyHelpAnswer) -> Unit,
  onMarkBestSolution: (CatchyHelpAnswer) -> Unit,
  onToggleSave: () -> Unit,
  isSaved: Boolean,
  onStatusChange: (String) -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onReportPost: () -> Unit,
  onReportAnswer: (CatchyHelpAnswer) -> Unit,
  onBlockUser: (String) -> Unit,
  onDismiss: () -> Unit
) {
  val isAuthor = currentUser != null && currentUser.userId == post.authorUserId
  var showPostMenu by remember { mutableStateOf(false) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = MaterialTheme.colorScheme.background
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Header
        Surface(
          color = MaterialTheme.colorScheme.surface,
          tonalElevation = 2.dp
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = onDismiss) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                  contentDescription = "Back",
                  tint = MaterialTheme.colorScheme.onSurface
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Help Request",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = onToggleSave) {
                Icon(
                  imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                  contentDescription = if (isSaved) "Saved" else "Save",
                  tint = if (isSaved) CatchyCyan else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              Box {
                IconButton(onClick = { showPostMenu = true }) {
                  Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                DropdownMenu(
                  expanded = showPostMenu,
                  onDismissRequest = { showPostMenu = false }
                ) {
                  if (isAuthor) {
                    DropdownMenuItem(
                      text = { Text(if (post.status == "Resolved") "Reopen Request" else "Mark as Resolved") },
                      onClick = {
                        onStatusChange(if (post.status == "Resolved") "Open" else "Resolved")
                        showPostMenu = false
                      }
                    )
                    DropdownMenuItem(
                      text = { Text("Edit Request") },
                      onClick = {
                        onEdit()
                        showPostMenu = false
                      }
                    )
                    DropdownMenuItem(
                      text = { Text("Delete Request", color = Color(0xFFEF4444)) },
                      onClick = {
                        onDelete()
                        showPostMenu = false
                      }
                    )
                  } else {
                    DropdownMenuItem(
                      text = { Text("Report Request") },
                      onClick = {
                        onReportPost()
                        showPostMenu = false
                      }
                    )
                    DropdownMenuItem(
                      text = { Text("Block @${post.authorUserId}") },
                      onClick = {
                        onBlockUser(post.authorUserId)
                        showPostMenu = false
                      }
                    )
                  }
                }
              }
            }
          }
        }

        // Post & Answers Thread
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          item {
            Spacer(modifier = Modifier.height(10.dp))

            // Author Header
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(Brush.linearGradient(listOf(CatchyIndigo, CatchyCyan))),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = post.authorName.take(2).uppercase(),
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
              }

              Spacer(modifier = Modifier.width(10.dp))

              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = post.authorName,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                  )
                  if (post.isVerifiedAuthor) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                      imageVector = Icons.Default.Verified,
                      contentDescription = "Verified",
                      tint = CatchyCyan,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
                Text(
                  text = "@${post.authorUserId}",
                  style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                  color = CatchyCyan
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category & Status Chips
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = CatchyIndigo.copy(alpha = 0.15f)
              ) {
                Text(
                  text = post.category,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = CatchyIndigoLight,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }

              val isResolved = post.status.equals("Resolved", ignoreCase = true)
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isResolved) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f)
              ) {
                Text(
                  text = if (isResolved) "Resolved" else "Open Request",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = if (isResolved) Color(0xFF10B981) else Color(0xFFF59E0B),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }

              if (!post.location.isNullOrBlank()) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = CatchyCyan, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = post.location!!, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = post.problemTitle,
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = post.problemDescription,
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurface
            )

            if (!post.mediaLabel.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(12.dp))
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = CatchyCyan.copy(alpha = 0.1f),
                border = BorderStroke(1.dp, CatchyCyan.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = CatchyCyan, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Attached Document/Photo: ${post.mediaLabel}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = CatchyCyan
                  )
                }
              }
            }

            if (post.tags.isNotBlank()) {
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = post.tags,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = CatchyCyan
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Contact Preference: ${post.contactPreference}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = "Community Answers (${answers.size})",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          if (answers.isEmpty()) {
            item {
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Icon(
                    imageVector = Icons.Default.QuestionAnswer,
                    contentDescription = null,
                    tint = CatchyCyan.copy(alpha = 0.6f),
                    modifier = Modifier.size(32.dp)
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(
                    text = "No answers yet",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = "Share helpful guidance or local advice below!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          } else {
            items(answers, key = { it.id }) { answer ->
              AnswerItemCard(
                answer = answer,
                isPostAuthor = isAuthor,
                onToggleHelpful = { onToggleHelpful(answer) },
                onMarkBestSolution = { onMarkBestSolution(answer) },
                onReply = { onSetReplyTo(answer.id) },
                onReport = { onReportAnswer(answer) }
              )
            }
          }

          item {
            Spacer(modifier = Modifier.height(20.dp))
          }
        }

        // Bottom Answer Composer
        Surface(
          color = MaterialTheme.colorScheme.surface,
          tonalElevation = 4.dp
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            if (replyToAnswerId != null) {
              val replyingToAnswer = answers.find { it.id == replyToAnswerId }
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = Icons.Default.Reply, contentDescription = null, tint = CatchyCyan, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "Replying to ${replyingToAnswer?.authorName ?: "Answer"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CatchyCyan
                  )
                }
                IconButton(onClick = { onSetReplyTo(null) }, modifier = Modifier.size(20.dp)) {
                  Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel reply", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = answerInput,
                onValueChange = onAnswerInputChange,
                placeholder = { Text("Write a solution or answer...") },
                modifier = Modifier
                  .weight(1f)
                  .testTag("help_detail_answer_input"),
                maxLines = 3,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = CatchyCyan,
                  unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
              )

              Spacer(modifier = Modifier.width(8.dp))

              IconButton(
                onClick = onSubmitAnswer,
                enabled = answerInput.isNotBlank(),
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(if (answerInput.isNotBlank()) CatchyIndigo else CatchyIndigo.copy(alpha = 0.3f))
                  .testTag("help_detail_submit_answer_button")
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Send,
                  contentDescription = "Send",
                  tint = Color.White,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AnswerItemCard(
  answer: CatchyHelpAnswer,
  isPostAuthor: Boolean,
  onToggleHelpful: () -> Unit,
  onMarkBestSolution: () -> Unit,
  onReply: () -> Unit,
  onReport: () -> Unit
) {
  var showMenu by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (answer.isBestSolution) Color(0xFF10B981).copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
    ),
    border = BorderStroke(
      1.dp,
      if (answer.isBestSolution) Color(0xFF10B981).copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
    ),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      if (answer.isBestSolution) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Best Solution Selected by Author",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFF10B981)
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(CatchyIndigoLight, CatchyCyan))),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = answer.authorName.take(2).uppercase(),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color.White)
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Column {
            Text(
              text = answer.authorName,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
            val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(answer.timestamp))
            Text(
              text = dateStr,
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Box {
          IconButton(onClick = { showMenu = true }, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.MoreVert, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
          }
          DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
            if (isPostAuthor) {
              DropdownMenuItem(
                text = { Text(if (answer.isBestSolution) "Unmark Best Solution" else "Mark as Best Solution") },
                onClick = {
                  onMarkBestSolution()
                  showMenu = false
                }
              )
            }
            DropdownMenuItem(
              text = { Text("Report Answer") },
              onClick = {
                onReport()
                showMenu = false
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = answer.content,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Bottom Actions for answer
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onToggleHelpful, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = Icons.Default.ThumbUp,
              contentDescription = "Helpful",
              tint = if (answer.isVerifiedSolution) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(15.dp)
            )
          }
          Text(
            text = "${answer.helpfulVotes} Helpful",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.width(12.dp))

          TextButton(onClick = onReply, modifier = Modifier.height(28.dp)) {
            Icon(imageVector = Icons.Default.Reply, contentDescription = null, tint = CatchyCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Reply", style = MaterialTheme.typography.labelSmall, color = CatchyCyan)
          }
        }

        if (isPostAuthor && !answer.isBestSolution) {
          TextButton(onClick = onMarkBestSolution, modifier = Modifier.height(28.dp)) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Accept Solution", style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981))
          }
        }
      }
    }
  }
}

/**
 * MODAL: Create Rich Help Post
 */
@Composable
private fun CreateHelpPostDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val titleInput by viewModel.helpPostTitleInput.collectAsState()
  val descInput by viewModel.helpPostDescInput.collectAsState()
  val locInput by viewModel.helpPostLocationInput.collectAsState()
  val catInput by viewModel.helpPostCategoryInput.collectAsState()
  val mediaLabel by viewModel.helpPostMediaLabel.collectAsState()
  val contactPref by viewModel.helpPostContactPref.collectAsState()
  val tagsInput by viewModel.helpPostTagsInput.collectAsState()
  val visibility by viewModel.helpPostVisibilityInput.collectAsState()

  var showCategoryDropdown by remember { mutableStateOf(false) }
  val categories = CatchyHelpCategories.ALL

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = MaterialTheme.colorScheme.background
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Header
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = onDismiss) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurface)
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Ask the Catchy Community",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
            }

            Button(
              onClick = { viewModel.publishHelpPost() },
              enabled = titleInput.isNotBlank() && descInput.isNotBlank(),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo),
              modifier = Modifier.testTag("publish_help_post_button")
            ) {
              Text("Publish")
            }
          }
        }

        // Form Fields
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Category Picker
          item {
            Text(text = "Category", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Box {
              OutlinedTextField(
                value = catInput,
                onValueChange = {},
                readOnly = true,
                trailingIcon = {
                  IconButton(onClick = { showCategoryDropdown = true }) {
                    Icon(imageVector = Icons.Default.MoreVert, contentDescription = null)
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { showCategoryDropdown = true },
                shape = RoundedCornerShape(12.dp)
              )

              DropdownMenu(
                expanded = showCategoryDropdown,
                onDismissRequest = { showCategoryDropdown = false }
              ) {
                categories.forEach { cat ->
                  DropdownMenuItem(
                    text = { Text(cat.name) },
                    onClick = {
                      viewModel.onHelpCategoryChange(cat.name)
                      showCategoryDropdown = false
                    }
                  )
                }
              }
            }
          }

          // Problem Title
          item {
            Text(text = "Title / Problem Summary", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = titleInput,
              onValueChange = { viewModel.onHelpTitleChange(it) },
              placeholder = { Text("e.g. Lost national ID near Dhanmondi Lake") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("help_form_title_input"),
              singleLine = true,
              shape = RoundedCornerShape(12.dp)
            )
          }

          // Problem Description
          item {
            Text(text = "Details & Context", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = descInput,
              onValueChange = { viewModel.onHelpDescChange(it) },
              placeholder = { Text("Provide specific context, what you have tried, and how members can help...") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("help_form_desc_input"),
              minLines = 4,
              maxLines = 7,
              shape = RoundedCornerShape(12.dp)
            )
          }

          // Location
          item {
            Text(text = "Location (Optional)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = locInput,
              onValueChange = { viewModel.onHelpLocationChange(it) },
              placeholder = { Text("e.g. Dhanmondi, Dhaka") },
              leadingIcon = {
                Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = CatchyCyan)
              },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true,
              shape = RoundedCornerShape(12.dp)
            )
          }

          // Media Attachment Label
          item {
            Text(text = "Document or Photo Label (Optional)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = mediaLabel,
              onValueChange = { viewModel.onHelpMediaLabelChange(it) },
              placeholder = { Text("e.g. Screenshot_Receipt.png or Photo_Keys.jpg") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true,
              shape = RoundedCornerShape(12.dp)
            )
          }

          // Contact Preference
          item {
            Text(text = "Contact Preference", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf("In-App Chat", "Public Answers Only", "Phone/WhatsApp").forEach { pref ->
                val isSelected = contactPref == pref
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (isSelected) CatchyIndigo else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                  border = BorderStroke(1.dp, if (isSelected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                  modifier = Modifier.clickable { viewModel.onHelpContactPrefChange(pref) }
                ) {
                  Text(
                    text = pref,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal),
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                  )
                }
              }
            }
          }

          // Tags
          item {
            Text(text = "Keywords / Tags (Space-separated)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = tagsInput,
              onValueChange = { viewModel.onHelpTagsChange(it) },
              placeholder = { Text("e.g. #Dhaka #LostID #Urgent") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true,
              shape = RoundedCornerShape(12.dp)
            )
          }

          // Visibility
          item {
            Text(text = "Audience Visibility", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf("Public", "Community Members Only").forEach { vis ->
                val isSelected = visibility == vis
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (isSelected) CatchyCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                  border = BorderStroke(1.dp, if (isSelected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                  modifier = Modifier.clickable { viewModel.onHelpVisibilityChange(vis) }
                ) {
                  Text(
                    text = vis,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal),
                    color = if (isSelected) CatchyCyan else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                  )
                }
              }
            }
          }

          item {
            Spacer(modifier = Modifier.height(40.dp))
          }
        }
      }
    }
  }
}

/**
 * MODAL: Edit Help Post
 */
@Composable
private fun EditHelpPostDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val title by viewModel.editHelpTitleInput.collectAsState()
  val desc by viewModel.editHelpDescInput.collectAsState()
  val cat by viewModel.editHelpCategoryInput.collectAsState()
  val loc by viewModel.editHelpLocationInput.collectAsState()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Edit Help Request") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { viewModel.onEditHelpTitleChange(it) },
          label = { Text("Title") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
        OutlinedTextField(
          value = desc,
          onValueChange = { viewModel.onEditHelpDescChange(it) },
          label = { Text("Description") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 3,
          maxLines = 5
        )
        OutlinedTextField(
          value = loc,
          onValueChange = { viewModel.onEditHelpLocationChange(it) },
          label = { Text("Location") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { viewModel.saveEditedHelpPost() },
        enabled = title.isNotBlank() && desc.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
      ) {
        Text("Save Changes")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

/**
 * MODAL: Report Dialog
 */
@Composable
private fun ReportDialog(
  targetType: String,
  targetTitle: String,
  onSubmit: (reason: String, details: String, blockUser: Boolean) -> Unit,
  onDismiss: () -> Unit
) {
  var selectedReason by remember { mutableStateOf("Spam or Scam") }
  var details by remember { mutableStateOf("") }
  var blockUser by remember { mutableStateOf(false) }

  val reasons = listOf(
    "Spam or Scam",
    "Harassment or Hate Speech",
    "Misleading Information",
    "Inappropriate Content",
    "Other Safety Concern"
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Report $targetType")
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Reporting: $targetTitle",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(text = "Select Reason:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))

        reasons.forEach { reason ->
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (selectedReason == reason) CatchyIndigo.copy(alpha = 0.15f) else Color.Transparent,
            border = BorderStroke(1.dp, if (selectedReason == reason) CatchyIndigo else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { selectedReason = reason }
          ) {
            Text(
              text = reason,
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (selectedReason == reason) FontWeight.Bold else FontWeight.Normal
              ),
              color = if (selectedReason == reason) CatchyIndigoLight else MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
            )
          }
        }

        OutlinedTextField(
          value = details,
          onValueChange = { details = it },
          label = { Text("Additional context (optional)") },
          modifier = Modifier.fillMaxWidth(),
          maxLines = 3
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .clickable { blockUser = !blockUser }
        ) {
          Checkbox(
            checked = blockUser,
            onCheckedChange = { blockUser = it },
            colors = CheckboxDefaults.colors(checkedColor = CatchyCyan)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "Also block this author", style = MaterialTheme.typography.bodySmall)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSubmit(selectedReason, details, blockUser) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
      ) {
        Text("Submit Report")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

/**
 * MODAL: Create Support Ticket
 */
@Composable
private fun CreateSupportTicketDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit
) {
  val subject by viewModel.ticketSubjectInput.collectAsState()
  val category by viewModel.ticketCategoryInput.collectAsState()
  val desc by viewModel.ticketDescInput.collectAsState()
  val attachment by viewModel.ticketAttachmentLabel.collectAsState()

  var showCatMenu by remember { mutableStateOf(false) }
  val ticketCategories = listOf("Account & Login", "Bug Report", "Feature Request", "Safety & Reporting", "General Inquiry")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.SupportAgent, contentDescription = null, tint = CatchyCyan)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Contact Catchy Support")
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box {
          OutlinedTextField(
            value = category,
            onValueChange = {},
            readOnly = true,
            label = { Text("Support Category") },
            trailingIcon = {
              IconButton(onClick = { showCatMenu = true }) {
                Icon(imageVector = Icons.Default.MoreVert, contentDescription = null)
              }
            },
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showCatMenu = true }
          )

          DropdownMenu(expanded = showCatMenu, onDismissRequest = { showCatMenu = false }) {
            ticketCategories.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  viewModel.onTicketCategoryChange(cat)
                  showCatMenu = false
                }
              )
            }
          }
        }

        OutlinedTextField(
          value = subject,
          onValueChange = { viewModel.onTicketSubjectChange(it) },
          label = { Text("Subject") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = desc,
          onValueChange = { viewModel.onTicketDescChange(it) },
          label = { Text("Explain your issue or question") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 3,
          maxLines = 5
        )

        OutlinedTextField(
          value = attachment,
          onValueChange = { viewModel.onTicketAttachmentChange(it) },
          label = { Text("Attachment reference (optional)") },
          placeholder = { Text("e.g. error_screenshot.png") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { viewModel.submitSupportTicket() },
        enabled = subject.isNotBlank() && desc.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
      ) {
        Text("Submit Ticket")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

/**
 * MODAL: Help Article Detail Dialog
 */
@Composable
private fun HelpArticleDetailDialog(
  article: HelpCenterArticle,
  onDismiss: () -> Unit,
  onContactSupport: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Column {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = CatchyCyan.copy(alpha = 0.15f)
        ) {
          Text(
            text = article.topic,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CatchyCyan,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = article.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = article.content,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(text = "Did this help answer your question?", style = MaterialTheme.typography.labelSmall)
          TextButton(onClick = onContactSupport) {
            Text("Contact Support", color = CatchyCyan, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)) {
        Text("Done")
      }
    }
  )
}

/**
 * Helper: Empty state card
 */
@Composable
private fun EmptyCardNotice(
  title: String,
  description: String,
  actionLabel: String,
  onAction: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Icon(
        imageVector = Icons.Default.HelpOutline,
        contentDescription = null,
        tint = CatchyCyan.copy(alpha = 0.5f),
        modifier = Modifier.size(38.dp)
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(14.dp))
      Button(
        onClick = onAction,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CatchyIndigo)
      ) {
        Text(actionLabel)
      }
    }
  }
}

/**
 * Helper: map category iconName to ImageVector
 */
private fun getCategoryIcon(iconName: String): ImageVector {
  return when (iconName) {
    "search" -> Icons.Default.Search
    "people" -> Icons.Default.People
    "school" -> Icons.Default.School
    "computer" -> Icons.Default.Computer
    "work" -> Icons.Default.Work
    "business" -> Icons.Default.Business
    "directions_car" -> Icons.Default.DirectionsCar
    "shopping_bag" -> Icons.Default.ShoppingBag
    "health_and_safety" -> Icons.Default.HealthAndSafety
    "warning" -> Icons.Default.Warning
    else -> Icons.Default.HelpOutline
  }
}
