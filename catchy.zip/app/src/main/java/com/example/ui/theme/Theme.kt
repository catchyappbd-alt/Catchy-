package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CatchyDarkColorScheme = darkColorScheme(
  primary = CatchyIndigoLight,
  onPrimary = Color.White,
  primaryContainer = CatchyIndigoDark,
  onPrimaryContainer = Color.White,
  secondary = CatchyCyan,
  onSecondary = Color.Black,
  secondaryContainer = CatchyViolet,
  onSecondaryContainer = Color.White,
  tertiary = CatchyCyanGlow,
  background = CatchyDarkBg,
  onBackground = CatchyTextPrimaryDark,
  surface = CatchyDarkSurface,
  onSurface = CatchyTextPrimaryDark,
  surfaceVariant = CatchyDarkSurfaceVariant,
  onSurfaceVariant = CatchyTextSecondaryDark,
  outline = CatchyDarkBorder,
  error = CatchyError,
  onError = Color.White
)

private val CatchyLightColorScheme = lightColorScheme(
  primary = CatchyIndigo,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFEEF2FF),
  onPrimaryContainer = CatchyIndigoDark,
  secondary = CatchyCyan,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFF3E8FF),
  onSecondaryContainer = CatchyViolet,
  tertiary = CatchyCyanGlow,
  background = CatchyLightBg,
  onBackground = CatchyTextPrimaryLight,
  surface = CatchyLightSurface,
  onSurface = CatchyTextPrimaryLight,
  surfaceVariant = CatchyLightSurfaceVariant,
  onSurfaceVariant = CatchyTextSecondaryLight,
  outline = CatchyLightBorder,
  error = CatchyError,
  onError = Color.White
)

@Composable
fun CatchyTheme(
  darkTheme: Boolean = true, // Default to Catchy's signature dark aesthetic
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) CatchyDarkColorScheme else CatchyLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
