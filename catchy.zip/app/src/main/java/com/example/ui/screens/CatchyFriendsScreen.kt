package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.UserAccount
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.theme.CatchyIndigoLight
import com.example.ui.theme.CatchySuccess
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.AccountViewModel.FriendsTab

/**
 * Catchy Friends and Following Experience.
 * Accessible from Catchy Menu.
 *
 * Provides:
 * - Real User Discovery & Search
 * - Following list
 * - Followers list
 * - Mutual Friends
 * - Follow / Following management with instant Room database persistence
 * - Direct profile and chat navigation
 */
@Composable
fun CatchyFriendsDialog(
  viewModel: AccountViewModel,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val allOtherUsers by viewModel.otherUsers.collectAsState()
  val followingIds by viewModel.followingUserIds.collectAsState()
  val followerIds by viewModel.followerUserIds.collectAsState()
  val selectedTab by viewModel.friendsSelectedTab.collectAsState()
  val searchQuery by viewModel.friendsSearchQuery.collectAsState()

  // Filter according to active tab
  val tabFilteredUsers = when (selectedTab) {
    FriendsTab.DISCOVER -> allOtherUsers
    FriendsTab.FOLLOWING -> allOtherUsers.filter { it.userId in followingIds }
    FriendsTab.FOLLOWERS -> allOtherUsers.filter { it.userId in followerIds }
    FriendsTab.FRIENDS -> allOtherUsers.filter { it.userId in followingIds && it.userId in followerIds }
  }

  // Filter according to search query
  val displayUsers = if (searchQuery.isBlank()) {
    tabFilteredUsers
  } else {
    val q = searchQuery.trim().lowercase()
    tabFilteredUsers.filter { user ->
      user.fullName.lowercase().contains(q) ||
        user.userId.lowercase().contains(q) ||
        user.bio.lowercase().contains(q) ||
        user.addressLocation.lowercase().contains(q)
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background),
      color = MaterialTheme.colorScheme.background
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        // Top Navigation Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .clickable { onDismiss() }
              .padding(4.dp)
              .testTag("friends_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = CatchyCyan
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Back",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.People,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Friends & Community",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          Box(modifier = Modifier.size(36.dp)) // balance spacer
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search bar
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.onFriendsSearchQueryChange(it) },
          placeholder = {
            Text(
              "Search by name, @CTY ID, or bio...",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(20.dp)
            )
          },
          trailingIcon = {
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { viewModel.onFriendsSearchQueryChange("") }) {
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = "Clear search",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CatchyCyan,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("friends_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category / Filter Chips: Discover, Following, Followers, Friends
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          item {
            FriendFilterChip(
              label = "Discover (${allOtherUsers.size})",
              selected = selectedTab == FriendsTab.DISCOVER,
              onClick = { viewModel.setFriendsTab(FriendsTab.DISCOVER) },
              testTag = "tab_discover"
            )
          }
          item {
            FriendFilterChip(
              label = "Following (${followingIds.size})",
              selected = selectedTab == FriendsTab.FOLLOWING,
              onClick = { viewModel.setFriendsTab(FriendsTab.FOLLOWING) },
              testTag = "tab_following"
            )
          }
          item {
            FriendFilterChip(
              label = "Followers (${followerIds.size})",
              selected = selectedTab == FriendsTab.FOLLOWERS,
              onClick = { viewModel.setFriendsTab(FriendsTab.FOLLOWERS) },
              testTag = "tab_followers"
            )
          }
          item {
            val mutualCount = allOtherUsers.count { it.userId in followingIds && it.userId in followerIds }
            FriendFilterChip(
              label = "Friends ($mutualCount)",
              selected = selectedTab == FriendsTab.FRIENDS,
              onClick = { viewModel.setFriendsTab(FriendsTab.FRIENDS) },
              testTag = "tab_mutual_friends"
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Content Area
        if (displayUsers.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(bottom = 32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(24.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(64.dp)
                  .clip(CircleShape)
                  .background(CatchyCyan.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.People,
                  contentDescription = null,
                  tint = CatchyCyan,
                  modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = when {
                  searchQuery.isNotBlank() -> "No users match '$searchQuery'"
                  selectedTab == FriendsTab.FOLLOWING -> "You are not following anyone yet."
                  selectedTab == FriendsTab.FOLLOWERS -> "No followers yet."
                  selectedTab == FriendsTab.FRIENDS -> "No mutual friends yet."
                  else -> "No Catchy members found."
                },
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Connect with members across Catchy to build authentic relationships.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
              if (selectedTab != FriendsTab.DISCOVER) {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                  onClick = { viewModel.setFriendsTab(FriendsTab.DISCOVER) },
                  colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan),
                  shape = RoundedCornerShape(12.dp)
                ) {
                  Text("Explore Community", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        } else {
          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
          ) {
            items(displayUsers, key = { it.userId }) { user ->
              val isFollowing = user.userId in followingIds
              val isFollower = user.userId in followerIds
              val isMutual = isFollowing && isFollower

              CatchyUserCard(
                user = user,
                isFollowing = isFollowing,
                isFollower = isFollower,
                isMutual = isMutual,
                onToggleFollow = { viewModel.toggleFollowUser(user.userId) },
                onViewProfile = {
                  viewModel.openUserProfile(user)
                  onDismiss()
                },
                onMessageUser = {
                  viewModel.openChatWithUser(user)
                  onDismiss()
                }
              )
            }
            item {
              Spacer(modifier = Modifier.height(24.dp))
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FriendFilterChip(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  testTag: String
) {
  FilterChip(
    selected = selected,
    onClick = onClick,
    label = {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
      )
    },
    shape = RoundedCornerShape(20.dp),
    colors = FilterChipDefaults.filterChipColors(
      selectedContainerColor = CatchyCyan,
      selectedLabelColor = Color(0xFF0F172A),
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
      labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    ),
    border = BorderStroke(
      1.dp,
      if (selected) CatchyCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    ),
    modifier = Modifier.testTag(testTag)
  )
}

/**
 * User card for community discovery, follower, following, and friend lists.
 */
@Composable
private fun CatchyUserCard(
  user: UserAccount,
  isFollowing: Boolean,
  isFollower: Boolean,
  isMutual: Boolean,
  onToggleFollow: () -> Unit,
  onViewProfile: () -> Unit,
  onMessageUser: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("user_card_${user.userId}")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Avatar + Name + UserID + Location
        Row(
          modifier = Modifier
            .weight(1f)
            .clickable { onViewProfile() }
        ) {
          val avatarGradients = when (user.profilePhotoUri) {
            "avatar_1" -> listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
            "avatar_2" -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
            "avatar_3" -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
            else -> listOf(Color(0xFF10B981), Color(0xFF059669))
          }

          Box(
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(avatarGradients))
              .border(2.dp, CatchyCyan.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = user.fullName.take(2).uppercase(),
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = user.fullName,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
              text = "@${user.userId}",
              style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
              ),
              color = CatchyCyan
            )

            if (user.addressLocation.isNotBlank()) {
              Spacer(modifier = Modifier.height(2.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.LocationOn,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                  text = user.addressLocation,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
              }
            }
          }
        }

        // Relationship badge
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = when {
            isMutual -> CatchySuccess.copy(alpha = 0.15f)
            isFollower -> CatchyIndigo.copy(alpha = 0.15f)
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          },
          border = BorderStroke(
            1.dp,
            when {
              isMutual -> CatchySuccess.copy(alpha = 0.4f)
              isFollower -> CatchyIndigoLight.copy(alpha = 0.4f)
              else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            }
          )
        ) {
          Text(
            text = when {
              isMutual -> "Mutual"
              isFollower -> "Follows you"
              isFollowing -> "Following"
              else -> "Catchy User"
            },
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.SemiBold,
              fontSize = 11.sp
            ),
            color = when {
              isMutual -> CatchySuccess
              isFollower -> CatchyCyan
              isFollowing -> MaterialTheme.colorScheme.onSurfaceVariant
              else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      // Bio snippet
      if (user.bio.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = user.bio,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bottom Action Buttons: Follow/Following, View Profile, Direct Message
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Follow / Following toggle
        if (isFollowing) {
          OutlinedButton(
            onClick = onToggleFollow,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            modifier = Modifier
              .weight(1f)
              .testTag("unfollow_button_${user.userId}")
          ) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = null,
              tint = CatchyCyan,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Following",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = CatchyCyan
            )
          }
        } else {
          Button(
            onClick = onToggleFollow,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CatchyCyan),
            modifier = Modifier
              .weight(1f)
              .testTag("follow_button_${user.userId}")
          ) {
            Icon(
              imageVector = Icons.Default.PersonAdd,
              contentDescription = null,
              tint = Color(0xFF0F172A),
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isFollower) "Follow Back" else "Follow",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = Color(0xFF0F172A)
            )
          }
        }

        // Direct Message button
        OutlinedButton(
          onClick = onMessageUser,
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          border = BorderStroke(1.dp, CatchyIndigoLight.copy(alpha = 0.4f)),
          modifier = Modifier.testTag("chat_user_button_${user.userId}")
        ) {
          Icon(
            imageVector = Icons.Default.ChatBubble,
            contentDescription = "Message",
            tint = CatchyIndigoLight,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Chat",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = CatchyIndigoLight
          )
        }

        // View Profile action
        OutlinedButton(
          onClick = onViewProfile,
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
          modifier = Modifier.testTag("view_profile_button_${user.userId}")
        ) {
          Text(
            text = "Profile",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
