package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CatchyGoVideo
import com.example.ui.components.CatchyGoDarkSurface
import com.example.ui.components.CatchyGoOrange
import com.example.ui.components.CatchyGoPink
import com.example.ui.components.CatchyGoPlayer
import com.example.ui.components.CatchyGoRed
import com.example.ui.theme.CatchyCyan
import com.example.ui.theme.CatchyIndigo
import com.example.ui.viewmodel.AccountViewModel

/**
 * Catchy Go & Reels Screen.
 * Features real Media3/ExoPlayer video streaming, interactive engagement controls
 * (like, comment, share, save, follow), fullscreen playback, and cinematic dark styling.
 */
@Composable
fun CatchyReelsScreen(
  viewModel: AccountViewModel,
  modifier: Modifier = Modifier
) {
  val otherUsers by viewModel.otherUsers.collectAsState()
  val videos by viewModel.catchyGoVideos.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val context = LocalContext.current

  // State for active fullscreen video
  var fullscreenVideo by remember { mutableStateOf<CatchyGoVideo?>(null) }
  // State for video comments dialog
  var commentVideo by remember { mutableStateOf<CatchyGoVideo?>(null) }
  var commentInput by remember { mutableStateOf("") }
  // State for video upload dialog
  var showUploadDialog by remember { mutableStateOf(false) }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(horizontal = 14.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
      // Header: Catchy GO Branding & Subtitle
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Video Icon badge
            Box(
              modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(
                  brush = Brush.linearGradient(listOf(CatchyGoRed, CatchyGoPink))
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
              text = "Catchy",
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Emphasized GO badge
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(
                  brush = Brush.horizontalGradient(listOf(CatchyGoRed, CatchyGoPink, CatchyGoOrange))
                )
                .padding(horizontal = 8.dp, vertical = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "GO",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp
                ),
                color = Color.White
              )
            }
          }

          // Header Actions: Upload Video & Video count badge
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = CatchyGoRed,
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable { showUploadDialog = true }
                .testTag("catchy_go_upload_action_btn")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.CloudUpload,
                  contentDescription = "Upload Video",
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "Upload",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color.White
                )
              }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
              text = "${videos.size} Shorts & Reels",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
          }
        }
      }

      // Empty Feed State when no videos have been published yet
      if (videos.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 24.dp)
              .testTag("catchy_go_empty_feed_card")
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                modifier = Modifier
                  .size(60.dp)
                  .clip(CircleShape)
                  .background(CatchyGoRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.PlayArrow,
                  contentDescription = null,
                  tint = CatchyGoPink,
                  modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                text = "Catchy Go Feed",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "No videos published yet. Upload and publish your video to appear in the live feed. Unpublished drafts stay hidden.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center
              )
              Spacer(modifier = Modifier.height(18.dp))
              Button(
                onClick = { showUploadDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CatchyGoRed),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("catchy_go_empty_upload_btn")
              ) {
                Icon(
                  imageVector = Icons.Default.CloudUpload,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Upload & Publish Video", fontWeight = FontWeight.Bold, color = Color.White)
              }
            }
          }
        }
      }

      // Vertical List of Real Playable Catchy Go Video Cards
      itemsIndexed(
        items = videos,
        key = { _, video -> video.id }
      ) { index, video ->
        CatchyGoVideoCard(
          video = video,
          autoPlay = (index == 0),
          onLike = { viewModel.toggleLikeVideo(video.id) },
          onComment = {
            commentVideo = video
            commentInput = ""
          },
          onShare = {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_SUBJECT, video.title)
              putExtra(Intent.EXTRA_TEXT, "${video.title}\nWatch on Catchy Go:\n${video.videoUri}")
            }
            val chooser = Intent.createChooser(sendIntent, "Share Video")
            context.startActivity(chooser)
          },
          onSave = { viewModel.toggleSaveVideo(video.id) },
          onFollow = { viewModel.toggleFollowCreator(video.creatorUserId) },
          onClickCreator = {
            val user = otherUsers.find { it.userId == video.creatorUserId }
            if (user != null) viewModel.openUserProfile(user)
          },
          onToggleFullscreen = {
            fullscreenVideo = video
          }
        )
      }

      item {
        Spacer(modifier = Modifier.height(90.dp))
      }
    }

    // Fullscreen Playback Modal
    fullscreenVideo?.let { activeVideo ->
      CatchyGoFullscreenDialog(
        video = activeVideo,
        onDismiss = { fullscreenVideo = null }
      )
    }

    // Video Comments Sheet/Dialog
    commentVideo?.let { activeVideo ->
      CatchyVideoCommentsDialog(
        video = activeVideo,
        commentInput = commentInput,
        onCommentChange = { commentInput = it },
        onSubmit = {
          viewModel.addCommentToVideo(activeVideo.id, commentInput)
          commentVideo = null
          commentInput = ""
        },
        onDismiss = {
          commentVideo = null
          commentInput = ""
        }
      )
    }

    // Video Upload (Step 2: Upload to Cloud Storage & Database Persistence)
    if (showUploadDialog) {
      CatchyGoUploadDialog(
        currentUser = currentUser,
        viewModel = viewModel,
        onDismiss = { showUploadDialog = false }
      )
    }
  }
}

/**
 * Dedicated Card containing real Media3 video player and engagement interactions.
 */
@Composable
private fun CatchyGoVideoCard(
  video: CatchyGoVideo,
  autoPlay: Boolean,
  onLike: () -> Unit,
  onComment: () -> Unit,
  onShare: () -> Unit,
  onSave: () -> Unit,
  onFollow: () -> Unit,
  onClickCreator: () -> Unit,
  onToggleFullscreen: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = CatchyGoDarkSurface),
    border = BorderStroke(
      width = 1.dp,
      brush = Brush.horizontalGradient(
        listOf(
          CatchyGoRed.copy(alpha = 0.5f),
          CatchyGoPink.copy(alpha = 0.4f),
          CatchyCyan.copy(alpha = 0.2f)
        )
      )
    ),
    modifier = Modifier
      .fillMaxWidth()
      .height(420.dp)
      .testTag("catchy_go_card_${video.id}")
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // 1. Real Media3/ExoPlayer Video Engine
      CatchyGoPlayer(
        videoUri = video.videoUri,
        autoPlay = autoPlay,
        isFullscreen = false,
        onToggleFullscreen = onToggleFullscreen,
        modifier = Modifier.fillMaxSize()
      )

      // 2. Floating Engagement Actions (Right Column)
      Column(
        modifier = Modifier
          .align(Alignment.CenterEnd)
          .padding(end = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Like Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.clickable { onLike() }
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (video.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
              contentDescription = "Like",
              tint = if (video.isLiked) CatchyGoRed else Color.White,
              modifier = Modifier.size(24.dp)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = formatEngagementCount(video.likesCount),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }

        // Comments Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.clickable { onComment() }
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.ModeComment,
              contentDescription = "Comments",
              tint = Color.White,
              modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = formatEngagementCount(video.commentsCount),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }

        // Bookmark / Save Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.clickable { onSave() }
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (video.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Save",
              tint = if (video.isSaved) CatchyGoOrange else Color.White,
              modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Save",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }

        // Share Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.clickable { onShare() }
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "Share",
              tint = Color.White,
              modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Share",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White
          )
        }
      }

      // 3. Bottom Creator & Metadata Overlay
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .fillMaxWidth(0.76f)
          .padding(start = 14.dp, bottom = 44.dp)
      ) {
        // Creator row with Follow action
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onClickCreator() }
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                  brush = Brush.linearGradient(listOf(CatchyGoRed, CatchyGoPink))
                ),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = video.creatorName.take(2).uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column {
              Text(
                text = video.creatorName,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
              Text(
                text = "@${video.creatorUserId}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = CatchyGoPink
              )
            }
          }

          Spacer(modifier = Modifier.width(10.dp))

          // Follow / Following pill button
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (video.isFollowing) Color.White.copy(alpha = 0.15f) else CatchyGoRed,
            border = if (video.isFollowing) BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)) else null,
            modifier = Modifier
              .clickable { onFollow() }
              .testTag("follow_creator_${video.creatorUserId}")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Icon(
                imageVector = if (video.isFollowing) Icons.Default.Check else Icons.Default.PersonAdd,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (video.isFollowing) "Following" else "Follow",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Title
        Text(
          text = video.title,
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
          color = Color.White.copy(alpha = 0.95f),
          maxLines = 2
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Audio track & Category indicator
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.MusicNote,
              contentDescription = null,
              tint = CatchyGoPink,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = video.audioTrack,
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
              color = Color.White.copy(alpha = 0.75f)
            )
          }

          if (video.category.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color.White.copy(alpha = 0.15f)
            ) {
              Text(
                text = video.category,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                color = CatchyCyan,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
      }
    }
  }
}

/**
 * Fullscreen dialog for immersive video playback.
 */
@Composable
private fun CatchyGoFullscreenDialog(
  video: CatchyGoVideo,
  onDismiss: () -> Unit
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      usePlatformDefaultWidth = false,
      dismissOnBackPress = true
    )
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
    ) {
      // Real Fullscreen Player
      CatchyGoPlayer(
        videoUri = video.videoUri,
        autoPlay = true,
        isFullscreen = true,
        onToggleFullscreen = onDismiss,
        modifier = Modifier.fillMaxSize()
      )

      // Top Close Button
      IconButton(
        onClick = onDismiss,
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(16.dp)
          .size(36.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.5f))
      ) {
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = "Close fullscreen",
          tint = Color.White
        )
      }
    }
  }
}

/**
 * Video Comments Bottom Sheet / Dialog.
 */
@Composable
private fun CatchyVideoCommentsDialog(
  video: CatchyGoVideo,
  commentInput: String,
  onCommentChange: (String) -> Unit,
  onSubmit: () -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, CatchyGoPink.copy(alpha = 0.4f)),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("catchy_video_comments_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.ModeComment,
              contentDescription = null,
              tint = CatchyGoPink,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Comments (${video.commentsCount})",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onBackground
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = video.title,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Comment composer
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = commentInput,
            onValueChange = onCommentChange,
            placeholder = { Text("Add a comment...", style = MaterialTheme.typography.bodySmall) },
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CatchyGoPink,
              unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            ),
            modifier = Modifier
              .weight(1f)
              .testTag("video_comment_input")
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = onSubmit,
            enabled = commentInput.isNotBlank(),
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(if (commentInput.isNotBlank()) CatchyGoRed else Color.Gray.copy(alpha = 0.3f))
              .testTag("submit_video_comment")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Post Comment",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }
}

/**
 * Format count to K/M format (e.g. 3.4K)
 */
private fun formatEngagementCount(count: Int): String {
  return when {
    count >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format(java.util.Locale.US, "%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}
