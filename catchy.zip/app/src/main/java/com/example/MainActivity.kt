package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.CatchyMainScreen
import com.example.ui.screens.ForgotPasswordScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SignUpScreen
import com.example.ui.theme.CatchyTheme
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyScreen

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      CatchyTheme {
        CatchyApp()
      }
    }
  }
}

@Composable
fun CatchyApp(
  viewModel: AccountViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  val currentScreen by viewModel.currentScreen.collectAsState()

  Surface(modifier = modifier.fillMaxSize()) {
    AnimatedContent(
      targetState = currentScreen,
      transitionSpec = { fadeIn() togetherWith fadeOut() },
      label = "screen_transition"
    ) { screen ->
      when (screen) {
        CatchyScreen.LOGIN -> LoginScreen(viewModel = viewModel)
        CatchyScreen.SIGN_UP -> SignUpScreen(viewModel = viewModel)
        CatchyScreen.FORGOT_PASSWORD,
        CatchyScreen.RESET_PASSWORD -> ForgotPasswordScreen(viewModel = viewModel)
        CatchyScreen.ACCOUNT_IDENTITY -> CatchyMainScreen(viewModel = viewModel)
      }
    }
  }
}
