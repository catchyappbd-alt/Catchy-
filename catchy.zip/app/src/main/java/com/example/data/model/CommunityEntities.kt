package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Real Room Database Model for Catchy Community.
 *
 * Requirements:
 * - Community name, description, photo, category, and privacy
 * - Public/private community setting
 * - Real authenticated user as creator/owner
 * - Member count
 * - Prevent duplicate membership and unauthorized ownership changes
 */
@Entity(
  tableName = "communities",
  indices = [
    Index(value = ["creatorUserId"]),
    Index(value = ["category"])
  ]
)
data class CatchyCommunity(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val name: String,
  val description: String,
  val photo: String = "", // Photo URI, custom avatar badge identifier, or photo URL
  val category: String = "General",
  val isPrivate: Boolean = false, // false = Public, true = Private
  val creatorUserId: String, // Authenticated user's real user identifier (e.g. CTY-...)
  val creatorName: String,
  val creatorAvatar: String? = null,
  val memberCount: Int = 1,
  val coverGradientIndex: Int = 0,
  val rules: String = "1. Be respectful and supportive.\n2. No spam or deceptive content.\n3. Respect privacy and authentic expression.",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Tracks community memberships.
 * Enforces uniqueness on (communityId, userId) to physically prevent duplicate membership at DB level.
 */
@Entity(
  tableName = "community_members",
  primaryKeys = ["communityId", "userId"],
  indices = [
    Index(value = ["communityId"]),
    Index(value = ["userId"])
  ]
)
data class CatchyCommunityMember(
  val communityId: String,
  val userId: String,
  val userName: String,
  val userAvatar: String? = null,
  val role: String = "MEMBER", // "OWNER", "ADMIN", "MEMBER"
  val joinedAt: Long = System.currentTimeMillis()
)

/**
 * Standard predefined community categories for Catchy.
 */
object CatchyCommunityCategories {
  val ALL = listOf(
    "Technology & AI",
    "Creative & Arts",
    "Music & Entertainment",
    "Gaming & Esports",
    "Business & Startups",
    "Education & Science",
    "Fitness & Health",
    "Lifestyle & Travel",
    "Local & Neighborhood"
  )
}

/**
 * Community Post entity supporting rich text, photo, and video attachments.
 */
@Entity(
  tableName = "community_posts",
  indices = [
    Index(value = ["communityId"]),
    Index(value = ["authorUserId"])
  ]
)
data class CatchyCommunityPost(
  @PrimaryKey
  val postId: String = UUID.randomUUID().toString(),
  val communityId: String,
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val content: String,
  val mediaUrl: String = "",
  val mediaType: String? = null, // "photo", "video", or null
  val mediaLabel: String? = null,
  val likesCount: Int = 0,
  val commentsCount: Int = 0,
  val sharesCount: Int = 0,
  val isPinned: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Community Post Likes tracking for instant toggling and persistence.
 */
@Entity(
  tableName = "community_post_likes",
  primaryKeys = ["postId", "userId"],
  indices = [
    Index(value = ["postId"]),
    Index(value = ["userId"])
  ]
)
data class CatchyCommunityPostLike(
  val postId: String,
  val userId: String,
  val likedAt: Long = System.currentTimeMillis()
)

/**
 * Community Post Comment entity with optional parentCommentId for threaded replies.
 */
@Entity(
  tableName = "community_post_comments",
  indices = [
    Index(value = ["postId"]),
    Index(value = ["communityId"])
  ]
)
data class CatchyCommunityPostComment(
  @PrimaryKey
  val commentId: String = UUID.randomUUID().toString(),
  val postId: String,
  val communityId: String,
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val content: String,
  val parentCommentId: String? = null,
  val createdAt: Long = System.currentTimeMillis()
)

/**
 * Community Safety Report entity for reporting posts or inappropriate members.
 */
@Entity(
  tableName = "community_reports",
  indices = [
    Index(value = ["communityId"]),
    Index(value = ["reporterUserId"])
  ]
)
data class CatchyCommunityReport(
  @PrimaryKey
  val reportId: String = UUID.randomUUID().toString(),
  val communityId: String,
  val targetType: String, // "POST" or "MEMBER"
  val targetId: String,
  val reporterUserId: String,
  val reason: String,
  val status: String = "PENDING", // "PENDING", "RESOLVED", "DISMISSED"
  val createdAt: Long = System.currentTimeMillis()
)

enum class CatchyCommunityTab {
  EXPLORE,
  MY_COMMUNITIES
}

enum class CommunityDetailTab {
  POSTS,
  MEMBERS,
  ABOUT
}
