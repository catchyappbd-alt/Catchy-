package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Catchy Career / Job Posting Entity.
 * Supports Full-time, Part-time, Internship, Apprenticeship, Freelance, Remote, and Local opportunities.
 */
@Entity(
  tableName = "catchy_job_postings",
  indices = [
    Index(value = ["employerId"]),
    Index(value = ["category"]),
    Index(value = ["employmentType"]),
    Index(value = ["status"])
  ]
)
data class CatchyJobPosting(
  @PrimaryKey
  val jobId: String = UUID.randomUUID().toString(),
  val employerId: String,
  val employerName: String,
  val employerAvatar: String? = null,
  val title: String,
  val companyName: String,
  val description: String,
  val category: String, // "Engineering & Tech", "Design & Creative", "Marketing & Growth", "Sales & Ops", "Content & Media", "Other"
  val skillsRequired: String,
  val location: String, // e.g. "Dhaka, Bangladesh" or "Remote"
  val isRemote: Boolean = false,
  val employmentType: String, // "Full-time", "Part-time", "Internship", "Apprenticeship", "Freelance", "Remote"
  val experienceLevel: String = "Any", // "Entry / Junior", "Mid-Level", "Senior", "Lead / Director"
  val salaryRange: String = "Negotiable",
  val applicationInstructions: String = "",
  val status: String = "ACTIVE", // "ACTIVE", "CLOSED", "DRAFT"
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Catchy Job Application Entity.
 * Guarantees uniqueness per applicant per job to prevent duplicate applications.
 */
@Entity(
  tableName = "catchy_job_applications",
  indices = [
    Index(value = ["jobId", "applicantId"], unique = true),
    Index(value = ["applicantId"]),
    Index(value = ["jobId"])
  ]
)
data class CatchyJobApplication(
  @PrimaryKey
  val applicationId: String = UUID.randomUUID().toString(),
  val jobId: String,
  val jobTitle: String,
  val companyName: String,
  val employerId: String,
  val applicantId: String,
  val applicantName: String,
  val applicantEmail: String,
  val applicantAvatar: String? = null,
  val coverNote: String,
  val resumeOrPortfolioLink: String,
  val applicantSkills: String,
  val applicantExperience: String,
  val applicantLocation: String,
  val status: String = "PENDING", // "PENDING", "REVIEWED", "SHORTLISTED", "REJECTED", "ACCEPTED"
  val appliedAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Catchy Job Seeker Profile.
 * Stores skills, experience, location, career goal and CV/portfolio information.
 */
@Entity(
  tableName = "catchy_job_seeker_profiles",
  indices = [Index(value = ["userId"], unique = true)]
)
data class CatchyJobSeekerProfile(
  @PrimaryKey
  val userId: String,
  val headline: String = "",
  val careerGoal: String = "",
  val skills: String = "",
  val experienceYears: String = "",
  val experienceSummary: String = "",
  val education: String = "",
  val location: String = "",
  val cvSummaryOrUrl: String = "",
  val preferredJobTypes: String = "Full-time, Remote",
  val isAvailableForHire: Boolean = true,
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Catchy Employer / Business Profile.
 * Stores company details, industry, size, and verification status.
 */
@Entity(
  tableName = "catchy_employer_profiles",
  indices = [Index(value = ["userId"], unique = true)]
)
data class CatchyEmployerProfile(
  @PrimaryKey
  val userId: String,
  val companyName: String = "",
  val industry: String = "",
  val companyWebsite: String = "",
  val companyLocation: String = "",
  val companySize: String = "1-10 employees",
  val companyBio: String = "",
  val verifiedEmployer: Boolean = false,
  val updatedAt: Long = System.currentTimeMillis()
)
