package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Core User Account Entity for Catchy Social App.
 *
 * Guarantees uniqueness for both the internal ID, the registered Email,
 * and the automatically generated Unique User ID (CTY-XXXXXX).
 */
@Entity(
  tableName = "users",
  indices = [
    Index(value = ["userId"], unique = true),
    Index(value = ["email"], unique = true)
  ]
)
data class UserAccount(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),

  // Automatic Unique User ID (Permanently linked, Fixed, Non-editable)
  val userId: String,

  // Fixed Core Account Identity
  val email: String,
  val dateOfBirth: String,
  val gender: String,
  val addressLocation: String,
  val educationStatus: String,
  val occupationStatus: String,
  val skills: String,
  val maritalStatus: String,

  // Editable Profile Information
  val fullName: String,
  val profilePhotoUri: String? = null,
  val bio: String = "Connecting authentically on Catchy.",

  // Security Credentials (Salted hashes, never plain text)
  val passwordHash: String,
  val passwordSalt: String,

  // Email Verification Lifecycle
  val isEmailVerified: Boolean = false,
  val emailVerificationCode: String? = null,
  val emailVerificationToken: String? = null,
  val emailVerificationTokenExpiry: Long? = null,

  // Password Reset Lifecycle (Time-limited, single-use)
  val passwordResetToken: String? = null,
  val passwordResetTokenExpiry: Long? = null,

  // Audit Timestamps
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)
