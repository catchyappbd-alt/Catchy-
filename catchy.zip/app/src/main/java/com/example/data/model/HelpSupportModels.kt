package com.example.data.model

import java.util.UUID

/**
 * Help Category definition.
 * Configurable categories for Catchy Help & Community Support.
 */
data class HelpCategory(
  val id: String,
  val name: String,
  val iconName: String,
  val description: String,
  val colorHex: Long = 0xFF6366F1
)

object CatchyHelpCategories {
  val ALL = listOf(
    HelpCategory(
      id = "general",
      name = "General Help",
      iconName = "help",
      description = "Everyday assistance, advice, and general community inquiries",
      colorHex = 0xFF6366F1
    ),
    HelpCategory(
      id = "lost_found",
      name = "Lost & Found",
      iconName = "search",
      description = "Lost or discovered documents, gadgets, keys, bags, and valuables",
      colorHex = 0xFFEC4899
    ),
    HelpCategory(
      id = "community",
      name = "Local Community",
      iconName = "people",
      description = "Neighborhood updates, local volunteering, area utilities, and social initiatives",
      colorHex = 0xFF10B981
    ),
    HelpCategory(
      id = "education",
      name = "Education",
      iconName = "school",
      description = "Study materials, university admission advice, tutoring, and course guidance",
      colorHex = 0xFF3B82F6
    ),
    HelpCategory(
      id = "technology",
      name = "Technology",
      iconName = "computer",
      description = "Software, mobile apps, coding help, hardware troubleshooting, and IT support",
      colorHex = 0xFF06B6D4
    ),
    HelpCategory(
      id = "jobs",
      name = "Jobs & Career",
      iconName = "work",
      description = "Career mentorship, interview prep, resume reviews, and verified job postings",
      colorHex = 0xFF8B5CF6
    ),
    HelpCategory(
      id = "business",
      name = "Business",
      iconName = "business",
      description = "Entrepreneurship, supplier connections, trade advice, and market insights",
      colorHex = 0xFFF59E0B
    ),
    HelpCategory(
      id = "transport",
      name = "Transportation",
      iconName = "directions_car",
      description = "Commute routes, carpooling advice, public transit info, and traffic updates",
      colorHex = 0xFF14B8A6
    ),
    HelpCategory(
      id = "services",
      name = "Shopping & Services",
      iconName = "shopping_bag",
      description = "Trusted local service recommendations, repairs, mechanics, and artisans",
      colorHex = 0xFFF97316
    ),
    HelpCategory(
      id = "health_safety",
      name = "Health & Safety Information",
      iconName = "health_and_safety",
      description = "Verified wellness centers, fitness tips, safety hotlines, and first aid tips",
      colorHex = 0xFFEF4444
    ),
    HelpCategory(
      id = "emergency",
      name = "Emergency Information",
      iconName = "warning",
      description = "Civic safety alerts, blood donor requests, utility outages, and emergency hotlines",
      colorHex = 0xFFDC2626
    ),
    HelpCategory(
      id = "other",
      name = "Other",
      iconName = "more_horiz",
      description = "Miscellaneous inquiries and niche community requests",
      colorHex = 0xFF64748B
    )
  )

  val NAMES = listOf("All") + ALL.map { it.name }
}

/**
 * Help Center Article model for searchable Catchy guidance.
 */
data class HelpCenterArticle(
  val id: String,
  val topic: String,
  val title: String,
  val summary: String,
  val content: String,
  val keywords: List<String>
)

object CatchyHelpArticles {
  val ARTICLES = listOf(
    HelpCenterArticle(
      id = "art_acc_01",
      topic = "Account",
      title = "Managing Your Catchy Account & User ID",
      summary = "How your permanently linked @CTY-XXXXXX User ID functions and what can be edited.",
      content = "Every Catchy user receives an automatically generated, permanently unique User ID in the format @CTY-XXXXXX upon account creation. This ID is uniquely bound to your account and cannot be modified. You can freely edit your Full Name, Profile Photo Avatar, and Bio from the Profile screen at any time. Your Date of Birth, Gender, Location, and Education remain securely stored in your account identity.",
      keywords = listOf("account", "user id", "id", "profile", "edit", "name", "identity")
    ),
    HelpCenterArticle(
      id = "art_login_02",
      topic = "Login & Password",
      title = "Password Security & Resetting Forgotten Passwords",
      summary = "How to securely reset your Catchy password using verified email tokens.",
      content = "If you forget your Catchy password, navigate to the Login screen and tap 'Forgot Password?'. Enter your registered email to receive a secure password reset link with a 15-minute token expiry. Catchy uses cryptographic PBKDF2 hashing with unique salts for every password. Never share your password or verification codes with anyone.",
      keywords = listOf("login", "password", "forgot", "reset", "token", "security", "credentials")
    ),
    HelpCenterArticle(
      id = "art_post_03",
      topic = "Posts",
      title = "Publishing and Managing Posts on Catchy",
      summary = "How to share updates, attach photos or videos, and format with hashtags.",
      content = "You can share posts directly from the Home screen post composer. Use 📷 Photo or 🎥 Video to attach media, or publish text-only posts. Include hashtags (e.g. #Tech, #Jobs, #Bangladesh) to appear in Catchy Trending topics. You can edit or delete your own posts using the three-dot menu on any of your cards.",
      keywords = listOf("posts", "publish", "photo", "video", "share", "hashtag", "trending", "feed")
    ),
    HelpCenterArticle(
      id = "art_chat_04",
      topic = "Chat",
      title = "Using Catchy Direct Messages, Voice Notes, and Calls",
      summary = "Private, end-to-end user communication with rich bubbles and audio/video calling.",
      content = "Catchy Chat provides direct 1-on-1 messaging between members. You can send rich text, quick emojis, photo attachments, and recorded voice notes. Tap the phone or video icon in the chat header to initiate direct calling. You can reply to specific messages, copy message text, or delete messages.",
      keywords = listOf("chat", "messages", "voice note", "calls", "audio", "video call", "direct message")
    ),
    HelpCenterArticle(
      id = "art_reels_05",
      topic = "Reels",
      title = "Catchy Reels & Vertical Video Experience",
      summary = "Discover engaging vertical short-form videos created by Catchy community members.",
      content = "Access Reels via the ▶️ bottom navigation icon. Enjoy full-screen vertical short videos with double-tap liking, comment threads, creator following, and audio tracking. Swipe vertically to explore trending reels across the platform.",
      keywords = listOf("reels", "video", "short video", "watch", "creator", "like")
    ),
    HelpCenterArticle(
      id = "art_notif_06",
      topic = "Notifications",
      title = "Understanding Catchy Activity Notifications",
      summary = "Stay updated with likes, comments, friends, solutions, and community events.",
      content = "Tap the 🔔 icon in the Home header to view all notifications. Catchy notifies you when someone likes your post, comments on your updates, follows your profile, provides an answer to your Help post, or marks your solution as helpful. Tap 'Mark all as read' to clear unread badges.",
      keywords = listOf("notifications", "bell", "alerts", "activity", "unread")
    ),
    HelpCenterArticle(
      id = "art_priv_07",
      topic = "Privacy",
      title = "Catchy Privacy Standards & Location Sharing",
      summary = "How Catchy protects your identity, location data, and communication.",
      content = "Catchy never tracks or shares your precise GPS coordinates. When you add a location to a post or Help request, only broad neighborhood, city, or district names are attached. Your private personal details (email, verification tokens, password hash) are strictly guarded and never exposed to other community members.",
      keywords = listOf("privacy", "location", "gps", "personal data", "security", "protection")
    ),
    HelpCenterArticle(
      id = "art_report_08",
      topic = "Reporting",
      title = "Reporting Content, Inappropriate Posts, and Scams",
      summary = "Keep Catchy clean and safe by reporting spam, harassment, or illegal content.",
      content = "Every post, Help request, comment, and chat message includes a 'Report' option in its more menu. Select the appropriate reason (Spam, Harassment, Fraud/scam, Dangerous content, Illegal activity, Misleading information, or Privacy violation). Catchy moderation reviews all reports to uphold community standards.",
      keywords = listOf("reporting", "report", "spam", "harassment", "scam", "fraud", "moderation")
    ),
    HelpCenterArticle(
      id = "art_block_09",
      topic = "Blocking",
      title = "Blocking Users and Managing Safety",
      summary = "How to block problematic users from interacting with your profile.",
      content = "If a user is harassing you or sending unsolicited messages, open their profile or chat menu and tap 'Block User'. Once blocked, the user cannot send you direct messages, see your posts in their feed, or reply to your community help posts.",
      keywords = listOf("blocking", "block", "safety", "restrict", "prevent")
    ),
    HelpCenterArticle(
      id = "art_rules_10",
      topic = "Community Rules",
      title = "Catchy Community Standards & Code of Conduct",
      summary = "The essential principles that keep Catchy welcoming, respectful, and productive.",
      content = "Catchy is built for authentic community connection. All members must follow our core rules: 1) Be respectful and polite. 2) Provide accurate, genuine information. 3) Never attempt fraud, impersonation, or financial scams. 4) Protect your own and others' privacy. 5) Keep Help discussions safe and supportive.",
      keywords = listOf("rules", "community", "conduct", "guidelines", "standards", "policy")
    ),
    HelpCenterArticle(
      id = "art_reach_11",
      topic = "Catchy Reach",
      title = "Catchy Reach & Post Promotion Policy",
      summary = "Promoting your social media posts to a wider audience through verified promotion.",
      content = "Catchy Reach is our separate promotional feature designed for businesses and creators to boost organic post visibility. Standard Help and Community Support features are 100% free and never charge users. Official payment channels for Reach promotions are bKash (01921229109) and Nagad (01974950103). Promotions become active only after server verification.",
      keywords = listOf("reach", "promotion", "payment", "bkash", "nagad", "boost", "ads", "monetization", "advertising")
    ),
    HelpCenterArticle(
      id = "art_del_12",
      topic = "Account Deletion",
      title = "Account Deletion & Data Retention Policy",
      summary = "How to request permanent removal of your Catchy account and data.",
      content = "You have full ownership of your data on Catchy. To request account deletion, navigate to 'Contact Support' in the Help Center and submit a ticket with subject 'Account Deletion Request'. All associated posts, chat messages, and profile information will be securely removed from our databases.",
      keywords = listOf("delete", "deletion", "account deletion", "data", "remove", "gdpr")
    )
  )
}

/**
 * Community Guidelines Principles
 */
object CatchyCommunityGuidelines {
  val RULES = listOf(
    "Be Respectful & Empathetic" to "Treat fellow community members with kindness and courtesy. Personal attacks, hate speech, and harassment are strictly prohibited.",
    "Provide Honest & Accurate Help" to "When answering community questions, ensure your advice is truthful, constructive, and helpful. Do not disseminate unverified rumors or misleading claims.",
    "Zero Tolerance for Scams & Fraud" to "Never solicit money, credentials, or personal banking information under the guise of community help. Report fraudulent activity immediately.",
    "Protect Personal Privacy" to "Never publicly post phone numbers, national IDs, passwords, OTPs, or financial details. Keep communication within Catchy.",
    "Respect Location Boundaries" to "Share general neighborhoods or cities rather than private personal addresses. Protect the physical safety of yourself and others.",
    "Keep Help Posts Constructive" to "Use clear titles and honest descriptions so fellow members can assist effectively. Mark helpful answers and close requests when resolved."
  )
}
