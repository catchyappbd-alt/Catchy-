package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

  @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
  fun observeUserById(id: String): Flow<UserAccount?>

  @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
  suspend fun getUserById(id: String): UserAccount?

  @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1")
  suspend fun getUserByEmail(email: String): UserAccount?

  @Query("SELECT * FROM users WHERE UPPER(userId) = UPPER(:userId) LIMIT 1")
  suspend fun getUserByUserId(userId: String): UserAccount?

  /**
   * Supports login by Email or User ID (e.g. rahim@gmail.com or CTY-8F42K7)
   */
  @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:identifier) OR UPPER(userId) = UPPER(:identifier) LIMIT 1")
  suspend fun findByIdentifier(identifier: String): UserAccount?

  @Query("SELECT COUNT(*) FROM users WHERE UPPER(userId) = UPPER(:userId)")
  suspend fun countByUserId(userId: String): Int

  @Query("SELECT COUNT(*) FROM users WHERE LOWER(email) = LOWER(:email)")
  suspend fun countByEmail(email: String): Int

  @Query("SELECT * FROM users WHERE passwordResetToken = :token LIMIT 1")
  suspend fun getUserByPasswordResetToken(token: String): UserAccount?

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertUser(user: UserAccount)

  @Update
  suspend fun updateUser(user: UserAccount)

  /**
   * Only Full Name, Profile Photo, and Bio are editable in standard profile lifecycle.
   * Fixed account information is preserved.
   */
  @Query("UPDATE users SET fullName = :fullName, profilePhotoUri = :photoUri, bio = :bio, updatedAt = :timestamp WHERE id = :id")
  suspend fun updateEditableProfile(id: String, fullName: String, photoUri: String?, bio: String, timestamp: Long)

  @Query("SELECT * FROM users WHERE userId != :currentUserId ORDER BY createdAt ASC")
  fun getAllUsersExcept(currentUserId: String): Flow<List<UserAccount>>

  @Query("SELECT * FROM users WHERE userId != :currentUserId ORDER BY createdAt ASC")
  suspend fun getAllUsersExceptSync(currentUserId: String): List<UserAccount>

  @Query("SELECT * FROM users ORDER BY createdAt ASC")
  fun getAllUsers(): Flow<List<UserAccount>>

  @Query("UPDATE users SET isEmailVerified = :isVerified, emailVerificationCode = NULL, emailVerificationToken = NULL, emailVerificationTokenExpiry = NULL, updatedAt = :timestamp WHERE id = :id")
  suspend fun updateEmailVerified(id: String, isVerified: Boolean, timestamp: Long)

  @Query("UPDATE users SET passwordHash = :passwordHash, passwordSalt = :passwordSalt, passwordResetToken = NULL, passwordResetTokenExpiry = NULL, updatedAt = :timestamp WHERE id = :id")
  suspend fun updatePassword(id: String, passwordHash: String, passwordSalt: String, timestamp: Long)

  @Query("UPDATE users SET passwordResetToken = :token, passwordResetTokenExpiry = :expiry, updatedAt = :timestamp WHERE id = :id")
  suspend fun setPasswordResetToken(id: String, token: String?, expiry: Long?, timestamp: Long)

  @Query("SELECT COUNT(*) FROM users")
  suspend fun getTotalUserCount(): Int
}
