package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Public posts shared on Catchy.
 * Connected seamlessly across Profile and Feed.
 */
@Entity(tableName = "posts")
data class CatchyPost(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val authorUserId: String, // e.g. "CTY-8F42K7"
  val authorAccountId: String, // UUID
  val authorName: String,
  val authorAvatar: String? = null,
  val content: String,
  val attachmentType: String? = null, // "photo", "video", etc.
  val attachmentLabel: String? = null,
  val hashtags: String? = null,
  val location: String? = null,
  val timestamp: Long = System.currentTimeMillis(),
  val likesCount: Int = 0,
  val commentsCount: Int = 0
)

/**
 * Comments on Catchy posts.
 */
@Entity(tableName = "post_comments")
data class CatchyPostComment(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val postId: String,
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val content: String,
  val timestamp: Long = System.currentTimeMillis()
)

/**
 * Tracks post likes per user.
 */
@Entity(
  tableName = "post_likes",
  primaryKeys = ["postId", "userId"]
)
data class PostLike(
  val postId: String,
  val userId: String,
  val likedAt: Long = System.currentTimeMillis()
)

/**
 * Help posts shared by community in Catchy Help ("People Need Help").
 */
@Entity(tableName = "help_posts")
data class CatchyHelpPost(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val problemTitle: String,
  val problemDescription: String,
  val location: String? = null,
  val answersCount: Int = 0,
  val timestamp: Long = System.currentTimeMillis(),
  val category: String = "General Help",
  val mediaType: String? = null, // "photo", "video"
  val mediaLabel: String? = null,
  val contactPreference: String = "In-App Chat",
  val tags: String = "",
  val visibility: String = "Public",
  val status: String = "Open", // "Open", "Resolved", "Closed"
  val helpfulCount: Int = 0,
  val isVerifiedAuthor: Boolean = false
)

/**
 * Solutions and answers for Catchy Help posts.
 */
@Entity(tableName = "help_answers")
data class CatchyHelpAnswer(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val helpPostId: String,
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val isVerifiedSolution: Boolean = false,
  val parentAnswerId: String? = null,
  val helpfulVotes: Int = 0,
  val isBestSolution: Boolean = false
)

/**
 * Saved Help posts for quick community reference.
 */
@Entity(
  tableName = "saved_help_posts",
  primaryKeys = ["userId", "helpPostId"]
)
data class SavedHelpPost(
  val userId: String,
  val helpPostId: String,
  val savedAt: Long = System.currentTimeMillis()
)

/**
 * Moderation reports for Help posts, answers, or users.
 */
@Entity(tableName = "help_reports")
data class HelpPostReport(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val targetType: String, // "post", "answer", "user"
  val targetId: String,
  val reporterUserId: String,
  val reason: String,
  val details: String = "",
  val status: String = "pending", // "pending", "reviewed"
  val timestamp: Long = System.currentTimeMillis()
)

/**
 * Blocked users.
 */
@Entity(
  tableName = "blocked_users",
  primaryKeys = ["blockerUserId", "blockedUserId"]
)
data class BlockedUser(
  val blockerUserId: String,
  val blockedUserId: String,
  val blockedAt: Long = System.currentTimeMillis()
)

/**
 * Support tickets submitted to Catchy Support.
 */
@Entity(tableName = "support_tickets")
data class SupportTicket(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val userId: String,
  val subject: String,
  val category: String,
  val description: String,
  val attachmentLabel: String? = null,
  val relatedContentRef: String? = null,
  val status: String = "Open", // "Open", "In Review", "Resolved", "Closed"
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Catchy 24-hour Stories.
 */
@Entity(tableName = "user_stories")
data class CatchyStory(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val authorUserId: String,
  val authorName: String,
  val authorAvatar: String? = null,
  val storyText: String,
  val mediaLabel: String? = null,
  val gradientIndex: Int = 0,
  val timestamp: Long = System.currentTimeMillis()
)

/**
 * Trending topic model for Catchy
 */
data class TrendingTopic(
  val tag: String,
  val category: String,
  val postCount: String
)

/**
 * Follow relationship between two Catchy accounts.
 */
@Entity(
  tableName = "follows",
  primaryKeys = ["followerUserId", "followingUserId"]
)
data class FollowRelation(
  val followerUserId: String,
  val followingUserId: String,
  val followedAt: Long = System.currentTimeMillis()
)

/**
 * 1-on-1 Chat message between two Catchy users.
 */
@Entity(tableName = "direct_messages")
data class CatchyDirectMessage(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val conversationId: String,
  val senderUserId: String,
  val receiverUserId: String,
  val content: String,
  val sentAt: Long = System.currentTimeMillis(),
  val mediaType: String? = null, // "photo", "camera", "voice"
  val mediaLabel: String? = null,
  val status: String = "delivered", // "sent", "delivered", "seen"
  val replyToMessageId: String? = null,
  val replyToText: String? = null,
  val replyToSenderName: String? = null,
  val isDeleted: Boolean = false
)

/**
 * Chat conversation between two Catchy users.
 */
@Entity(tableName = "chat_conversations")
data class CatchyConversation(
  @PrimaryKey
  val conversationId: String,
  val user1Id: String,
  val user2Id: String,
  val lastMessage: String,
  val lastMessageTimestamp: Long = System.currentTimeMillis()
)

/**
 * Catchy Go Uploaded Video (Step 2).
 * Persisted in the existing CatchyDatabase with real cloud storage metadata.
 * Note: Kept unpublished from the public feed until subsequent publishing phase.
 */
@Entity(tableName = "catchy_go_uploaded_videos")
data class CatchyGoUploadedVideo(
  @PrimaryKey
  val id: String = UUID.randomUUID().toString(),
  val title: String,
  val description: String = "",
  val category: String,
  val tags: String = "",
  val visibility: String = "Public",
  val creatorId: String, // Authenticated user's real account ID (UserAccount.id)
  val storageUrl: String,
  val localUri: String? = null,
  val duration: Long, // Video duration in milliseconds
  val createdTime: Long = System.currentTimeMillis(),
  val isPublishedToFeed: Boolean = false,
  val publishedTime: Long? = null,
  val likesCount: Int = 0,
  val commentsCount: Int = 0,
  val sharesCount: Int = 0,
  val savesCount: Int = 0,
  val audioTrack: String = "Original Audio • Catchy Go"
)

