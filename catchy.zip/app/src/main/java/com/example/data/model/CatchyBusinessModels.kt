package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
  tableName = "catchy_business_pages",
  indices = [Index(value = ["handle"], unique = true)]
)
data class CatchyBusinessPage(
  @PrimaryKey
  val pageId: String = "BIZ-${UUID.randomUUID().toString().take(8).uppercase()}",
  val ownerUserId: String,
  val name: String,
  val handle: String,
  val category: String, // Technology & Software, Retail & E-commerce, Food & Restaurant, Media & Agency, Education & Training, Healthcare, Consulting & Services, Creative & Design, Other
  val tagline: String = "",
  val description: String = "",
  val email: String = "",
  val phone: String = "",
  val website: String = "",
  val location: String = "",
  val operatingHours: String = "",
  val isVerified: Boolean = true,
  val followersCount: Int = 0,
  val status: String = "ACTIVE", // ACTIVE, UNPUBLISHED
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
  tableName = "catchy_business_posts",
  indices = [Index(value = ["pageId"])]
)
data class CatchyBusinessPost(
  @PrimaryKey
  val postId: String = "BPOST-${UUID.randomUUID().toString().take(8).uppercase()}",
  val pageId: String,
  val authorUserId: String,
  val content: String,
  val mediaUrl: String = "",
  val likesCount: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(
  tableName = "catchy_business_follows",
  indices = [Index(value = ["pageId", "userId"], unique = true)]
)
data class CatchyBusinessPageFollow(
  @PrimaryKey
  val followId: String = UUID.randomUUID().toString(),
  val pageId: String,
  val userId: String,
  val followedAt: Long = System.currentTimeMillis()
)

@Entity(
  tableName = "catchy_business_inquiries",
  indices = [Index(value = ["pageId"])]
)
data class CatchyBusinessInquiry(
  @PrimaryKey
  val inquiryId: String = "INQ-${UUID.randomUUID().toString().take(8).uppercase()}",
  val pageId: String,
  val pageName: String,
  val senderUserId: String,
  val senderName: String,
  val senderEmail: String,
  val subject: String,
  val message: String,
  val status: String = "NEW", // NEW, REPLIED, ARCHIVED
  val createdAt: Long = System.currentTimeMillis()
)
