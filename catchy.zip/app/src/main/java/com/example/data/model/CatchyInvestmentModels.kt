package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "catchy_investment_opportunities")
data class CatchyInvestmentOpportunity(
  @PrimaryKey
  val opportunityId: String = "INV-${UUID.randomUUID().toString().take(8).uppercase()}",
  val creatorUserId: String,
  val companyName: String,
  val tagline: String,
  val industry: String, // FinTech, AgriTech, AI & Tech, HealthTech, E-Commerce, CleanTech, Logistics, EdTech, Other
  val stage: String, // Pre-seed, Seed, Pre-Series A, Series A, Growth, Bootstrapped
  val targetAmount: String, // e.g. "$100,000", "৳1.5 Crore"
  val raisedSoFar: String = "$0",
  val instrumentType: String = "Equity", // Equity, SAFE, Convertible Note, Revenue Share, Debt
  val equityOffered: String = "", // e.g. "5% - 8%"
  val minTicket: String = "$5,000", // Minimum investment ticket
  val location: String, // e.g. "Dhaka, Bangladesh"
  val pitchSummary: String,
  val tractionAndMetrics: String = "", // Users, MRR, GMV, MoM growth
  val useOfFunds: String = "",
  val pitchDeckUrl: String = "",
  val status: String = "ACTIVE", // ACTIVE, FUNDED, CLOSED
  val privacyLevel: String = "PUBLIC", // PUBLIC, VERIFIED_INVESTORS_ONLY
  val isVerified: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catchy_investment_requests")
data class CatchyInvestmentRequest(
  @PrimaryKey
  val requestId: String = "REQ-${UUID.randomUUID().toString().take(8).uppercase()}",
  val opportunityId: String,
  val opportunityTitle: String,
  val companyName: String,
  val founderUserId: String,
  val investorUserId: String,
  val investorName: String,
  val investorEmail: String,
  val investorType: String = "Angel Investor", // Angel Investor, VC, Syndicate, Family Office, Mentor
  val proposedAmount: String,
  val messageNote: String,
  val termsOrInquiry: String = "",
  val status: String = "PENDING", // PENDING, DISCUSSING, ACCEPTED, DECLINED
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catchy_investor_profiles")
data class CatchyInvestorProfile(
  @PrimaryKey
  val userId: String,
  val investorName: String,
  val investorType: String = "Angel Investor", // Angel Investor, VC Partner, Syndicate Lead, Family Office
  val ticketSizeRange: String = "$10k - $50k",
  val preferredIndustries: String = "Tech, FinTech, AI",
  val preferredStages: String = "Pre-seed, Seed",
  val investmentGeography: String = "Bangladesh & Global",
  val portfolioSummary: String = "",
  val bio: String = "",
  val isAccredited: Boolean = false,
  val isPubliclyDiscoverable: Boolean = true,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catchy_founder_profiles")
data class CatchyFounderProfile(
  @PrimaryKey
  val userId: String,
  val founderName: String,
  val ventureName: String,
  val legalEntityStatus: String = "Private Limited",
  val industry: String = "Tech",
  val stage: String = "Seed",
  val headquarters: String = "Dhaka, Bangladesh",
  val websiteUrl: String = "",
  val elevatorPitch: String = "",
  val teamOverview: String = "",
  val isVerifiedVenture: Boolean = false,
  val updatedAt: Long = System.currentTimeMillis()
)
