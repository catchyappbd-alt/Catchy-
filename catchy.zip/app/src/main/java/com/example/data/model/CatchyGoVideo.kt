package com.example.data.model

/**
 * Model representing a Catchy Go / Reel video entry.
 * Contains video media URI, creator metadata, and engagement states.
 */
data class CatchyGoVideo(
  val id: String,
  val creatorName: String,
  val creatorUserId: String,
  val title: String,
  val description: String = "",
  val audioTrack: String = "Original Audio • Catchy Go",
  val videoUri: String,
  val thumbnailUri: String? = null,
  val likesCount: Int = 0,
  val commentsCount: Int = 0,
  val sharesCount: Int = 0,
  val savesCount: Int = 0,
  val isLiked: Boolean = false,
  val isSaved: Boolean = false,
  val isFollowing: Boolean = false,
  val creatorAvatar: String? = null,
  val category: String = "General",
  val duration: Long = 0L,
  val publishedTime: Long = 0L
)
