package com.example.data.security

import java.util.regex.Pattern

/**
 * First AI Security Layer for Catchy Social App.
 *
 * Enforces strict security boundaries before any data can reach an AI system:
 * 1. AI is completely decoupled and barred from direct database access.
 * 2. Sensitive data (passwords, hashes, tokens, payment data, private messages) is strictly blocked.
 * 3. Enforces data minimization - accepting only explicitly allowed, minimal fields.
 * 4. Demands a real remote server-side AI Gateway with server-side authorization.
 * 5. Fails closed: Never uses fake security, fake backends, or embedded AI API keys.
 */

/**
 * Explicit whitelist of permitted AI tasks.
 * Any unlisted task is strictly rejected.
 */
enum class AiPermittedTask {
  CONTENT_MODERATION_CHECK,
  CAPTION_RECOMMENDATION,
  TAG_SUGGESTION,
  HELP_ARTICLE_SUMMARIZATION
}

/**
 * Data-minimized payload container.
 * AI requests can ONLY accept these minimal, non-sensitive fields.
 * Raw database entities (UserAccount, CatchyDirectMessage, etc.) are strictly forbidden.
 */
data class MinimizedAiPayload(
  val task: AiPermittedTask,
  val content: String,
  val contextCategory: String? = null
)

/**
 * Client authorization token container for server-side verification.
 * The server-side gateway validates user identity and strips auth tokens
 * prior to dispatching minimal prompt data to the AI model.
 */
data class AiClientAuthorization(
  val requesterUserId: String,
  val sessionToken: String,
  val isElevatedAdminRequest: Boolean = false
)

/**
 * Validation result indicating whether a payload passes security screening.
 */
sealed class AiSecurityResult {
  data class Allowed(val sanitizedPayload: MinimizedAiPayload) : AiSecurityResult()
  data class Rejected(val reason: String, val violationType: ViolationType) : AiSecurityResult()

  enum class ViolationType {
    SENSITIVE_CREDENTIAL,
    PAYMENT_DATA,
    PRIVATE_MESSAGE_CONTENT,
    DIRECT_DATABASE_ENTITY,
    UNAUTHORIZED_PRIVILEGED_ACCESS,
    OWNER_CREDENTIAL_ACCESS,
    PRIVILEGE_ESCALATION_ATTEMPT,
    SECURITY_RULE_TAMPERING,
    EXCESSIVE_DATA,
    BACKEND_REQUIRED
  }
}

/**
 * Dedicated Security Inspector that scans and sanitizes outbound AI requests.
 */
object AiSecurityInspector {

  // Credit card regex (Visa, MasterCard, Amex, Discover)
  private val PAYMENT_CARD_REGEX = Pattern.compile(
    "\\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\\b"
  )

  // CVV / CVC code patterns
  private val CVV_REGEX = Pattern.compile("(?i)\\b(cvv|cvc|security code)[:\\s]*([0-9]{3,4})\\b")

  // Password / Secret / API Key patterns
  private val CREDENTIAL_REGEX = Pattern.compile(
    "(?i)\\b(password|passwd|pwd|hash|salt|secret|api_key|apikey|bearer\\s+[a-zA-Z0-9._\\-]+|ghp_[a-zA-Z0-9]+)\\b"
  )

  // Owner credential & master secrets patterns
  private val OWNER_CREDENTIAL_REGEX = Pattern.compile(
    "(?i)\\b(owner_key|owner_credential|master_secret|master_key|signing_secret|root_secret|owner_token|admin_token)\\b"
  )

  // Privilege escalation / promotion / impersonation patterns
  private val PRIVILEGE_ESCALATION_REGEX = Pattern.compile(
    "(?i)\\b(make_owner|grant_admin|promote_to_admin|impersonate_owner|escalate_privilege|bypass_security|override_permission|modify_rule|disable_guard)\\b"
  )

  // Token / Session key patterns
  private val TOKEN_REGEX = Pattern.compile(
    "(?i)\\b(token|auth_token|session_id|jwt|verification_code)[:\\s]*[=:]?\\s*([a-zA-Z0-9_\\-.]{6,})\\b"
  )

  // Private message transcript or direct chat markers
  private val PRIVATE_MESSAGE_REGEX = Pattern.compile(
    "(?i)\\b(direct_message|private_chat|dm_thread|chat_history|conversation_id)\\b"
  )

  /**
   * Validates and screens data prior to sending to an AI service.
   * Rejects any sensitive data, credentials, tokens, payment info, or private messages.
   */
  fun inspectAndSanitize(
    payload: MinimizedAiPayload,
    authorization: AiClientAuthorization
  ): AiSecurityResult {
    // 1. Enforce authorization boundary: Prevent unauthorized access to privileged/admin data
    if (authorization.isElevatedAdminRequest) {
      return AiSecurityResult.Rejected(
        reason = "AI requests cannot access privileged user, admin, or Owner data.",
        violationType = AiSecurityResult.ViolationType.UNAUTHORIZED_PRIVILEGED_ACCESS
      )
    }

    if (authorization.requesterUserId.isBlank() || authorization.sessionToken.isBlank()) {
      return AiSecurityResult.Rejected(
        reason = "Valid user authorization is mandatory for all AI operations.",
        violationType = AiSecurityResult.ViolationType.UNAUTHORIZED_PRIVILEGED_ACCESS
      )
    }

    // 2. Reject payload if text is excessively large (prevent memory exhaustion or prompt injection)
    if (payload.content.length > 2000) {
      return AiSecurityResult.Rejected(
        reason = "Data payload exceeds maximum allowed size (2000 characters) for minimal AI processing.",
        violationType = AiSecurityResult.ViolationType.EXCESSIVE_DATA
      )
    }

    val textToInspect = "${payload.content} ${payload.contextCategory ?: ""}"

    // 3. Scan for Owner credentials, master secrets, and signing keys
    if (OWNER_CREDENTIAL_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: AI cannot access Owner credentials, master secrets, or signing keys.",
        violationType = AiSecurityResult.ViolationType.OWNER_CREDENTIAL_ACCESS
      )
    }

    // 4. Scan for privilege escalation or impersonation attempts
    if (PRIVILEGE_ESCALATION_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: AI cannot create, promote, or impersonate an Owner/Admin, or tamper with security rules.",
        violationType = AiSecurityResult.ViolationType.PRIVILEGE_ESCALATION_ATTEMPT
      )
    }

    // 5. Scan for general credentials, passwords, salts, and secret keys
    if (CREDENTIAL_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: Passwords, salts, hashes, and secrets must never be exposed to AI.",
        violationType = AiSecurityResult.ViolationType.SENSITIVE_CREDENTIAL
      )
    }

    // 6. Scan for authentication tokens and verification codes
    if (TOKEN_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: Auth tokens and verification codes must never be exposed to AI.",
        violationType = AiSecurityResult.ViolationType.SENSITIVE_CREDENTIAL
      )
    }

    // 7. Scan for payment information (Credit cards, CVV)
    if (PAYMENT_CARD_REGEX.matcher(textToInspect).find() || CVV_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: Financial and payment data must never be exposed to AI.",
        violationType = AiSecurityResult.ViolationType.PAYMENT_DATA
      )
    }

    // 8. Scan for private message markers or direct chat transcripts
    if (PRIVATE_MESSAGE_REGEX.matcher(textToInspect).find()) {
      return AiSecurityResult.Rejected(
        reason = "Security violation: Private messages and direct chats are strictly prohibited from AI processing.",
        violationType = AiSecurityResult.ViolationType.PRIVATE_MESSAGE_CONTENT
      )
    }

    // Payload is verified and minimized
    val sanitizedContent = payload.content
      .replace(Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"), "") // Strip control characters
      .trim()

    return AiSecurityResult.Allowed(
      sanitizedPayload = payload.copy(content = sanitizedContent)
    )
  }
}

/**
 * Exception thrown when an AI request violates security boundaries.
 */
class AiSecurityViolationException(message: String) : SecurityException(message)

/**
 * Exception thrown when no real server-side AI Gateway backend is deployed.
 * Fails closed safely: Never allows direct client AI execution or fake backends.
 */
class AiBackendRequiredException(
  message: String = "A real server-side AI Gateway backend is required. Direct client-side AI execution is strictly prohibited."
) : IllegalStateException(message)

/**
 * Client interface for the server-side AI Gateway.
 *
 * Mandates:
 * 1. AI API keys (e.g. Gemini, OpenAI) must NEVER reside in the Android app.
 * 2. Requests must be screened by [AiSecurityInspector] before dispatch.
 * 3. Requires a real remote server backend; fails closed if none exists.
 */
class AiGatewayClient(
  private val backendGatewayUrl: String? = null
) {

  /**
   * Dispatches a sanitized, data-minimized AI request to the server-side gateway.
   *
   * @throws AiSecurityViolationException if the payload contains prohibited sensitive data.
   * @throws AiBackendRequiredException if no real server-side backend is configured.
   */
  suspend fun executeMinimallyScopedRequest(
    payload: MinimizedAiPayload,
    authorization: AiClientAuthorization
  ): Result<String> {
    // Step 1: Client-side Security Boundary Inspection
    val securityCheck = AiSecurityInspector.inspectAndSanitize(payload, authorization)
    if (securityCheck is AiSecurityResult.Rejected) {
      return Result.failure(
        AiSecurityViolationException("AI Request Blocked: ${securityCheck.reason}")
      )
    }

    // Step 2: Verify Real Server-Side Backend Existence
    // Strict requirement: Never use fake security or fake backend behavior.
    if (backendGatewayUrl.isNullOrBlank() || !backendGatewayUrl.startsWith("https://")) {
      return Result.failure(
        AiBackendRequiredException(
          "Server-side AI Gateway is required but not configured. " +
          "AI features remain strictly dormant until a dedicated backend gateway service is deployed."
        )
      )
    }

    // If a real backend URL is configured, outbound requests would proceed to the HTTPS endpoint.
    // However, because no backend service exists yet in the workspace, we do not fake responses.
    return Result.failure(
      AiBackendRequiredException(
        "Remote backend endpoint ($backendGatewayUrl) is not currently reachable. Real backend service required."
      )
    )
  }
}
