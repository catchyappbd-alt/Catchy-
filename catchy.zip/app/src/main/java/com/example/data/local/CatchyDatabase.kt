package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BlockedUser
import com.example.data.model.CatchyBusinessInquiry
import com.example.data.model.CatchyBusinessPage
import com.example.data.model.CatchyBusinessPageFollow
import com.example.data.model.CatchyBusinessPost
import com.example.data.model.CatchyCommunity
import com.example.data.model.CatchyCommunityMember
import com.example.data.model.CatchyCommunityPost
import com.example.data.model.CatchyCommunityPostComment
import com.example.data.model.CatchyCommunityPostLike
import com.example.data.model.CatchyCommunityReport
import com.example.data.model.CatchyConversation
import com.example.data.model.CatchyDirectMessage
import com.example.data.model.CatchyEmployerProfile
import com.example.data.model.CatchyFounderProfile
import com.example.data.model.CatchyGoUploadedVideo
import com.example.data.model.CatchyHelpAnswer
import com.example.data.model.CatchyHelpPost
import com.example.data.model.CatchyInvestmentOpportunity
import com.example.data.model.CatchyInvestmentRequest
import com.example.data.model.CatchyInvestorProfile
import com.example.data.model.CatchyJobApplication
import com.example.data.model.CatchyJobPosting
import com.example.data.model.CatchyJobSeekerProfile
import com.example.data.model.CatchyPost
import com.example.data.model.CatchyPostComment
import com.example.data.model.CatchyStory
import com.example.data.model.FollowRelation
import com.example.data.model.HelpPostReport
import com.example.data.model.PostLike
import com.example.data.model.SavedHelpPost
import com.example.data.model.SupportTicket
import com.example.data.model.UserAccount

@Database(
  entities = [
    UserAccount::class,
    CatchyPost::class,
    FollowRelation::class,
    CatchyDirectMessage::class,
    CatchyConversation::class,
    CatchyPostComment::class,
    PostLike::class,
    CatchyHelpPost::class,
    CatchyHelpAnswer::class,
    CatchyStory::class,
    SavedHelpPost::class,
    HelpPostReport::class,
    BlockedUser::class,
    SupportTicket::class,
    CatchyGoUploadedVideo::class,
    CatchyCommunity::class,
    CatchyCommunityMember::class,
    CatchyCommunityPost::class,
    CatchyCommunityPostLike::class,
    CatchyCommunityPostComment::class,
    CatchyCommunityReport::class,
    CatchyJobPosting::class,
    CatchyJobApplication::class,
    CatchyJobSeekerProfile::class,
    CatchyEmployerProfile::class,
    CatchyInvestmentOpportunity::class,
    CatchyInvestmentRequest::class,
    CatchyInvestorProfile::class,
    CatchyFounderProfile::class,
    CatchyBusinessPage::class,
    CatchyBusinessPost::class,
    CatchyBusinessPageFollow::class,
    CatchyBusinessInquiry::class
  ],
  version = 13,
  exportSchema = false
)
abstract class CatchyDatabase : RoomDatabase() {

  abstract fun userDao(): UserDao
  abstract fun socialDao(): SocialDao

  companion object {
    @Volatile
    private var INSTANCE: CatchyDatabase? = null

    fun getInstance(context: Context): CatchyDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          CatchyDatabase::class.java,
          "catchy_accounts.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
