package com.example.data.model

/**
 * Account Data Architecture - Future Extensibility Hooks
 *
 * Prepared for future Catchy features:
 * - Profile
 * - Friends
 * - Following
 * - Chat
 * - Messages
 * - Notifications
 * - Reels
 * - Communities
 * - Catchy Help
 * - Catchy Solutions
 */

data class CatchyProfileReference(
  val accountId: String,
  val catchyUserId: String,
  val bio: String = "",
  val website: String = "",
  val followerCount: Int = 0,
  val followingCount: Int = 0
)

data class CatchyFriendshipRelation(
  val requesterAccountId: String,
  val targetAccountId: String,
  val status: FriendshipStatus,
  val createdAt: Long = System.currentTimeMillis()
)

enum class FriendshipStatus {
  PENDING, ACCEPTED, DECLINED, BLOCKED
}

data class CatchyFollowingRelation(
  val followerAccountId: String,
  val followedAccountId: String,
  val followedAt: Long = System.currentTimeMillis()
)

data class CatchyChatConversation(
  val conversationId: String,
  val participantAccountIds: List<String>,
  val lastMessageTimestamp: Long = System.currentTimeMillis()
)

data class CatchyChatMessage(
  val messageId: String,
  val conversationId: String,
  val senderAccountId: String,
  val content: String,
  val sentAt: Long = System.currentTimeMillis()
)

data class CatchyNotification(
  val notificationId: String,
  val recipientAccountId: String,
  val title: String,
  val body: String,
  val type: String,
  val isRead: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

data class CatchyReel(
  val reelId: String,
  val authorAccountId: String,
  val mediaUrl: String,
  val caption: String,
  val likesCount: Int = 0,
  val commentsCount: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)

data class CatchyHelpTicket(
  val ticketId: String,
  val userAccountId: String,
  val subject: String,
  val queryText: String,
  val status: String = "OPEN"
)

data class CatchySolutionArticle(
  val articleId: String,
  val title: String,
  val category: String,
  val solutionContent: String
)
