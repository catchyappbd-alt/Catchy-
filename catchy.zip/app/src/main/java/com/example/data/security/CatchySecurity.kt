package com.example.data.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

object CatchySecurity {
  private val secureRandom = SecureRandom()
  private const val ALPHANUMERIC = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ" // Avoid ambiguous chars 0, 1, I, O

  /**
   * Generates a Catchy Unique User ID format: CTY-XXXXXX (e.g. CTY-8F42K7)
   */
  fun generateUserId(): String {
    val sb = StringBuilder("CTY-")
    for (i in 0 until 6) {
      val index = secureRandom.nextInt(ALPHANUMERIC.length)
      sb.append(ALPHANUMERIC[index])
    }
    return sb.toString()
  }

  /**
   * Generates a random cryptographic salt
   */
  fun generateSalt(): String {
    val saltBytes = ByteArray(16)
    secureRandom.nextBytes(saltBytes)
    return Base64.getEncoder().encodeToString(saltBytes)
  }

  /**
   * Securely hashes a plain-text password using SHA-256 and salt.
   * Never stores plain-text passwords.
   */
  fun hashPassword(password: String, salt: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    md.update(salt.toByteArray(Charsets.UTF_8))
    val hashedBytes = md.digest(password.toByteArray(Charsets.UTF_8))
    return Base64.getEncoder().encodeToString(hashedBytes)
  }

  /**
   * Verifies an input password against stored hash and salt
   */
  fun verifyPassword(password: String, salt: String, expectedHash: String): Boolean {
    val computedHash = hashPassword(password, salt)
    return computedHash == expectedHash
  }

  /**
   * Generates a time-limited secure token for email verification or password reset
   */
  fun generateSecureToken(): String {
    val tokenBytes = ByteArray(24)
    secureRandom.nextBytes(tokenBytes)
    return Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes)
  }

  /**
   * Generates a clean 6-digit numeric verification code
   */
  fun generateVerificationCode(): String {
    val code = 100000 + secureRandom.nextInt(900000)
    return code.toString()
  }
}
