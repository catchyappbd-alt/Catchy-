package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BlockedUser
import com.example.data.model.CatchyBusinessInquiry
import com.example.data.model.CatchyBusinessPage
import com.example.data.model.CatchyBusinessPageFollow
import com.example.data.model.CatchyBusinessPost
import com.example.data.model.CatchyCommunity
import com.example.data.model.CatchyCommunityMember
import com.example.data.model.CatchyCommunityPost
import com.example.data.model.CatchyCommunityPostComment
import com.example.data.model.CatchyCommunityPostLike
import com.example.data.model.CatchyCommunityReport
import com.example.data.model.CatchyConversation
import com.example.data.model.CatchyDirectMessage
import com.example.data.model.CatchyEmployerProfile
import com.example.data.model.CatchyFounderProfile
import com.example.data.model.CatchyGoUploadedVideo
import com.example.data.model.CatchyHelpAnswer
import com.example.data.model.CatchyHelpPost
import com.example.data.model.CatchyInvestmentOpportunity
import com.example.data.model.CatchyInvestmentRequest
import com.example.data.model.CatchyInvestorProfile
import com.example.data.model.CatchyJobApplication
import com.example.data.model.CatchyJobPosting
import com.example.data.model.CatchyJobSeekerProfile
import com.example.data.model.CatchyPost
import com.example.data.model.CatchyPostComment
import com.example.data.model.CatchyStory
import com.example.data.model.FollowRelation
import com.example.data.model.HelpPostReport
import com.example.data.model.PostLike
import com.example.data.model.SavedHelpPost
import com.example.data.model.SupportTicket
import kotlinx.coroutines.flow.Flow

@Dao
interface SocialDao {

  // --- Posts ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPost(post: CatchyPost)

  @Query("UPDATE posts SET content = :newContent, hashtags = :newHashtags, location = :newLocation WHERE id = :postId")
  suspend fun updatePostContent(postId: String, newContent: String, newHashtags: String?, newLocation: String?)

  @Query("DELETE FROM posts WHERE id = :postId")
  suspend fun deletePost(postId: String)

  @Query("SELECT * FROM posts WHERE id = :postId LIMIT 1")
  suspend fun getPostById(postId: String): CatchyPost?

  @Query("SELECT * FROM posts WHERE authorUserId = :authorUserId ORDER BY timestamp DESC")
  fun getPostsForUser(authorUserId: String): Flow<List<CatchyPost>>

  @Query("SELECT * FROM posts WHERE authorUserId = :authorUserId ORDER BY timestamp DESC")
  suspend fun getPostsForUserSync(authorUserId: String): List<CatchyPost>

  @Query("SELECT * FROM posts ORDER BY timestamp DESC")
  fun getAllPosts(): Flow<List<CatchyPost>>

  @Query("SELECT * FROM posts ORDER BY timestamp DESC")
  suspend fun getAllPostsSync(): List<CatchyPost>

  @Query("SELECT COUNT(*) FROM posts WHERE authorUserId = :authorUserId")
  suspend fun getPostCountForUser(authorUserId: String): Int

  @Query("SELECT COUNT(*) FROM posts")
  suspend fun getTotalPostCount(): Int

  // --- Post Likes ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPostLike(postLike: PostLike)

  @Query("DELETE FROM post_likes WHERE postId = :postId AND userId = :userId")
  suspend fun deletePostLike(postId: String, userId: String)

  @Query("SELECT COUNT(*) > 0 FROM post_likes WHERE postId = :postId AND userId = :userId")
  fun isPostLiked(postId: String, userId: String): Flow<Boolean>

  @Query("SELECT COUNT(*) > 0 FROM post_likes WHERE postId = :postId AND userId = :userId")
  suspend fun isPostLikedSync(postId: String, userId: String): Boolean

  @Query("SELECT postId FROM post_likes WHERE userId = :userId")
  fun getLikedPostIds(userId: String): Flow<List<String>>

  @Query("UPDATE posts SET likesCount = :likesCount WHERE id = :postId")
  suspend fun updatePostLikesCount(postId: String, likesCount: Int)

  // --- Post Comments ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertComment(comment: CatchyPostComment)

  @Query("SELECT * FROM post_comments WHERE postId = :postId ORDER BY timestamp ASC")
  fun getCommentsForPost(postId: String): Flow<List<CatchyPostComment>>

  @Query("SELECT * FROM post_comments WHERE postId = :postId ORDER BY timestamp ASC")
  suspend fun getCommentsForPostSync(postId: String): List<CatchyPostComment>

  @Query("UPDATE posts SET commentsCount = :commentsCount WHERE id = :postId")
  suspend fun updatePostCommentsCount(postId: String, commentsCount: Int)

  // --- Catchy Help Posts ("People Need Help") ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHelpPost(helpPost: CatchyHelpPost)

  @Query("SELECT * FROM help_posts ORDER BY timestamp DESC")
  fun getAllHelpPosts(): Flow<List<CatchyHelpPost>>

  @Query("SELECT * FROM help_posts WHERE id = :id LIMIT 1")
  fun getHelpPost(id: String): Flow<CatchyHelpPost?>

  @Query("SELECT * FROM help_posts WHERE id = :id LIMIT 1")
  suspend fun getHelpPostSync(id: String): CatchyHelpPost?

  @Query("""
    SELECT * FROM help_posts 
    WHERE (:category = 'All' OR category = :category)
    AND (:query = '' OR problemTitle LIKE '%' || :query || '%' OR problemDescription LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' OR location LIKE '%' || :query || '%')
    ORDER BY timestamp DESC
  """)
  fun searchHelpPosts(query: String, category: String): Flow<List<CatchyHelpPost>>

  @Query("SELECT * FROM help_posts WHERE category = :category ORDER BY timestamp DESC")
  fun getHelpPostsByCategory(category: String): Flow<List<CatchyHelpPost>>

  @Query("SELECT * FROM help_posts WHERE location IS NOT NULL AND location != '' AND location LIKE '%' || :locationQuery || '%' ORDER BY timestamp DESC")
  fun getNearbyHelpPosts(locationQuery: String): Flow<List<CatchyHelpPost>>

  @Query("SELECT * FROM help_posts WHERE authorUserId = :userId ORDER BY timestamp DESC")
  fun getUserHelpPosts(userId: String): Flow<List<CatchyHelpPost>>

  @Query("UPDATE help_posts SET answersCount = :count WHERE id = :helpPostId")
  suspend fun updateHelpAnswersCount(helpPostId: String, count: Int)

  @Query("UPDATE help_posts SET status = :status WHERE id = :postId")
  suspend fun updateHelpPostStatus(postId: String, status: String)

  @Query("UPDATE help_posts SET problemTitle = :title, problemDescription = :desc, category = :category, location = :location WHERE id = :postId")
  suspend fun updateHelpPostDetails(postId: String, title: String, desc: String, category: String, location: String?)

  @Query("DELETE FROM help_posts WHERE id = :postId")
  suspend fun deleteHelpPost(postId: String)

  @Query("UPDATE help_posts SET helpfulCount = helpfulCount + 1 WHERE id = :postId")
  suspend fun incrementHelpfulCount(postId: String)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHelpAnswer(answer: CatchyHelpAnswer)

  @Query("SELECT * FROM help_answers WHERE helpPostId = :helpPostId ORDER BY timestamp ASC")
  fun getHelpAnswers(helpPostId: String): Flow<List<CatchyHelpAnswer>>

  @Query("SELECT * FROM help_answers WHERE helpPostId = :helpPostId ORDER BY timestamp ASC")
  suspend fun getHelpAnswersSync(helpPostId: String): List<CatchyHelpAnswer>

  @Query("UPDATE help_answers SET helpfulVotes = helpfulVotes + (CASE WHEN :isHelpful THEN 1 ELSE -1 END), isVerifiedSolution = :isHelpful WHERE id = :answerId")
  suspend fun updateAnswerHelpful(answerId: String, isHelpful: Boolean)

  @Query("UPDATE help_answers SET isBestSolution = :isBest WHERE id = :answerId")
  suspend fun updateAnswerBestSolution(answerId: String, isBest: Boolean)

  @Query("DELETE FROM help_answers WHERE id = :answerId")
  suspend fun deleteHelpAnswer(answerId: String)

  // --- Saved Help Posts ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSavedHelpPost(saved: SavedHelpPost)

  @Query("DELETE FROM saved_help_posts WHERE userId = :userId AND helpPostId = :helpPostId")
  suspend fun deleteSavedHelpPost(userId: String, helpPostId: String)

  @Query("SELECT COUNT(*) > 0 FROM saved_help_posts WHERE userId = :userId AND helpPostId = :helpPostId")
  fun isHelpPostSaved(userId: String, helpPostId: String): Flow<Boolean>

  @Query("SELECT COUNT(*) > 0 FROM saved_help_posts WHERE userId = :userId AND helpPostId = :helpPostId")
  suspend fun isHelpPostSavedSync(userId: String, helpPostId: String): Boolean

  @Query("""
    SELECT h.* FROM help_posts h 
    INNER JOIN saved_help_posts s ON h.id = s.helpPostId 
    WHERE s.userId = :userId 
    ORDER BY s.savedAt DESC
  """)
  fun getSavedHelpPosts(userId: String): Flow<List<CatchyHelpPost>>

  @Query("SELECT helpPostId FROM saved_help_posts WHERE userId = :userId")
  fun getSavedHelpPostIds(userId: String): Flow<List<String>>

  @Query("""
    SELECT DISTINCT h.* FROM help_posts h
    INNER JOIN help_answers a ON h.id = a.helpPostId
    WHERE a.authorUserId = :userId
    ORDER BY h.timestamp DESC
  """)
  fun getHelpPostsAnsweredByUser(userId: String): Flow<List<CatchyHelpPost>>

  // --- Moderation Reports ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHelpReport(report: HelpPostReport)

  @Query("SELECT * FROM help_reports ORDER BY timestamp DESC")
  fun getAllReports(): Flow<List<HelpPostReport>>

  // --- Blocked Users ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBlockedUser(blocked: BlockedUser)

  @Query("DELETE FROM blocked_users WHERE blockerUserId = :blockerId AND blockedUserId = :blockedId")
  suspend fun deleteBlockedUser(blockerId: String, blockedId: String)

  @Query("SELECT blockedUserId FROM blocked_users WHERE blockerUserId = :userId")
  fun getBlockedUserIds(userId: String): Flow<List<String>>

  @Query("SELECT COUNT(*) > 0 FROM blocked_users WHERE blockerUserId = :blockerId AND blockedUserId = :blockedId")
  suspend fun isUserBlockedSync(blockerId: String, blockedId: String): Boolean

  // --- Support Tickets ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSupportTicket(ticket: SupportTicket)

  @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY createdAt DESC")
  fun getUserSupportTickets(userId: String): Flow<List<SupportTicket>>

  // --- Catchy Stories ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStory(story: CatchyStory)

  @Query("SELECT * FROM user_stories ORDER BY timestamp DESC")
  fun getAllStories(): Flow<List<CatchyStory>>

  @Query("DELETE FROM user_stories WHERE id = :storyId")
  suspend fun deleteStory(storyId: String)

  // --- Follows ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFollow(relation: FollowRelation)

  @Query("DELETE FROM follows WHERE followerUserId = :followerUserId AND followingUserId = :followingUserId")
  suspend fun deleteFollow(followerUserId: String, followingUserId: String)

  @Query("SELECT COUNT(*) > 0 FROM follows WHERE followerUserId = :followerUserId AND followingUserId = :followingUserId")
  fun isFollowing(followerUserId: String, followingUserId: String): Flow<Boolean>

  @Query("SELECT COUNT(*) > 0 FROM follows WHERE followerUserId = :followerUserId AND followingUserId = :followingUserId")
  suspend fun isFollowingSync(followerUserId: String, followingUserId: String): Boolean

  @Query("SELECT COUNT(*) FROM follows WHERE followingUserId = :userId")
  fun getFollowerCount(userId: String): Flow<Int>

  @Query("SELECT COUNT(*) FROM follows WHERE followerUserId = :userId")
  fun getFollowingCount(userId: String): Flow<Int>

  @Query("SELECT COUNT(*) FROM follows WHERE followingUserId = :userId")
  suspend fun getFollowerCountSync(userId: String): Int

  @Query("SELECT COUNT(*) FROM follows WHERE followerUserId = :userId")
  suspend fun getFollowingCountSync(userId: String): Int

  @Query("SELECT followingUserId FROM follows WHERE followerUserId = :userId")
  fun getFollowingUserIds(userId: String): Flow<List<String>>

  @Query("SELECT followerUserId FROM follows WHERE followingUserId = :userId")
  fun getFollowerUserIds(userId: String): Flow<List<String>>

  @Query("SELECT followingUserId FROM follows WHERE followerUserId = :userId")
  suspend fun getFollowingUserIdsSync(userId: String): List<String>

  @Query("SELECT followerUserId FROM follows WHERE followingUserId = :userId")
  suspend fun getFollowerUserIdsSync(userId: String): List<String>

  // --- Chat & Messages ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: CatchyDirectMessage)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateConversation(conv: CatchyConversation)

  @Query("SELECT * FROM chat_conversations WHERE conversationId = :conversationId LIMIT 1")
  suspend fun getConversation(conversationId: String): CatchyConversation?

  @Query("SELECT * FROM chat_conversations WHERE user1Id = :userId OR user2Id = :userId ORDER BY lastMessageTimestamp DESC")
  fun getConversationsForUser(userId: String): Flow<List<CatchyConversation>>

  @Query("SELECT * FROM direct_messages WHERE conversationId = :conversationId ORDER BY sentAt ASC")
  fun getMessagesForConversation(conversationId: String): Flow<List<CatchyDirectMessage>>

  @Query("SELECT * FROM direct_messages WHERE conversationId = :conversationId ORDER BY sentAt ASC")
  suspend fun getMessagesForConversationSync(conversationId: String): List<CatchyDirectMessage>

  @Query("DELETE FROM direct_messages WHERE id = :messageId")
  suspend fun deleteMessage(messageId: String)

  @Query("UPDATE direct_messages SET status = :status WHERE id = :messageId")
  suspend fun updateMessageStatus(messageId: String, status: String)

  @Query("UPDATE direct_messages SET status = 'seen' WHERE conversationId = :conversationId AND receiverUserId = :currentUserId AND status != 'seen'")
  suspend fun markMessagesAsSeen(conversationId: String, currentUserId: String)

  @Query("SELECT COUNT(*) FROM direct_messages WHERE conversationId = :conversationId AND receiverUserId = :currentUserId AND status != 'seen'")
  fun getUnreadMessageCount(conversationId: String, currentUserId: String): Flow<Int>

  @Query("DELETE FROM chat_conversations WHERE conversationId = :conversationId")
  suspend fun deleteConversation(conversationId: String)

  @Query("DELETE FROM direct_messages WHERE conversationId = :conversationId")
  suspend fun deleteMessagesForConversation(conversationId: String)

  // --- Catchy Go Uploaded & Published Videos (Step 2 & 3) ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCatchyGoUploadedVideo(video: CatchyGoUploadedVideo)

  @Query("SELECT * FROM catchy_go_uploaded_videos WHERE id = :id LIMIT 1")
  suspend fun getCatchyGoUploadedVideoById(id: String): CatchyGoUploadedVideo?

  @Query("SELECT * FROM catchy_go_uploaded_videos WHERE creatorId = :creatorId ORDER BY createdTime DESC")
  fun getCatchyGoUploadedVideosForCreator(creatorId: String): Flow<List<CatchyGoUploadedVideo>>

  @Query("SELECT * FROM catchy_go_uploaded_videos WHERE creatorId = :creatorId ORDER BY createdTime DESC")
  suspend fun getCatchyGoUploadedVideosForCreatorSync(creatorId: String): List<CatchyGoUploadedVideo>

  @Query("SELECT COUNT(*) FROM catchy_go_uploaded_videos WHERE creatorId = :creatorId")
  suspend fun getCatchyGoUploadedVideoCount(creatorId: String): Int

  @Query("SELECT * FROM catchy_go_uploaded_videos WHERE isPublishedToFeed = 1 ORDER BY CASE WHEN publishedTime IS NOT NULL THEN publishedTime ELSE createdTime END DESC")
  fun getPublishedCatchyGoVideos(): Flow<List<CatchyGoUploadedVideo>>

  @Query("SELECT * FROM catchy_go_uploaded_videos WHERE isPublishedToFeed = 1 ORDER BY CASE WHEN publishedTime IS NOT NULL THEN publishedTime ELSE createdTime END DESC")
  suspend fun getPublishedCatchyGoVideosSync(): List<CatchyGoUploadedVideo>

  @Query("UPDATE catchy_go_uploaded_videos SET isPublishedToFeed = 1, publishedTime = :publishedTime WHERE id = :videoId")
  suspend fun markCatchyGoVideoAsPublished(videoId: String, publishedTime: Long): Int

  @Query("UPDATE catchy_go_uploaded_videos SET likesCount = :likes WHERE id = :videoId")
  suspend fun updateCatchyGoVideoLikes(videoId: String, likes: Int)

  @Query("UPDATE catchy_go_uploaded_videos SET commentsCount = :comments WHERE id = :videoId")
  suspend fun updateCatchyGoVideoComments(videoId: String, comments: Int)

  @Query("UPDATE catchy_go_uploaded_videos SET savesCount = :saves WHERE id = :videoId")
  suspend fun updateCatchyGoVideoSaves(videoId: String, saves: Int)

  // --- Real Community Database Foundation ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunity(community: CatchyCommunity)

  @Update
  suspend fun updateCommunity(community: CatchyCommunity): Int

  @Query("DELETE FROM communities WHERE id = :communityId")
  suspend fun deleteCommunity(communityId: String): Int

  @Query("SELECT * FROM communities ORDER BY createdAt DESC")
  fun getAllCommunities(): Flow<List<CatchyCommunity>>

  @Query("SELECT * FROM communities ORDER BY createdAt DESC")
  suspend fun getAllCommunitiesSync(): List<CatchyCommunity>

  @Query("SELECT * FROM communities WHERE id = :communityId LIMIT 1")
  fun getCommunityById(communityId: String): Flow<CatchyCommunity?>

  @Query("SELECT * FROM communities WHERE id = :communityId LIMIT 1")
  suspend fun getCommunityByIdSync(communityId: String): CatchyCommunity?

  @Query("SELECT * FROM communities WHERE category = :category ORDER BY createdAt DESC")
  fun getCommunitiesByCategory(category: String): Flow<List<CatchyCommunity>>

  @Query("SELECT * FROM communities WHERE name LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY createdAt DESC")
  fun searchCommunities(query: String): Flow<List<CatchyCommunity>>

  @Query("""
    SELECT c.* FROM communities c
    INNER JOIN community_members m ON c.id = m.communityId
    WHERE m.userId = :userId
    ORDER BY m.joinedAt DESC
  """)
  fun getCommunitiesJoinedByUser(userId: String): Flow<List<CatchyCommunity>>

  @Query("SELECT COUNT(*) FROM communities")
  suspend fun getCommunityCount(): Int

  // --- Community Membership Operations ---
  // OnConflictStrategy.ABORT strictly prevents duplicate membership at SQLite level
  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertCommunityMember(member: CatchyCommunityMember): Long

  @Query("DELETE FROM community_members WHERE communityId = :communityId AND userId = :userId")
  suspend fun deleteCommunityMember(communityId: String, userId: String): Int

  @Query("DELETE FROM community_members WHERE communityId = :communityId")
  suspend fun deleteAllMembersForCommunity(communityId: String): Int

  @Query("SELECT COUNT(*) > 0 FROM community_members WHERE communityId = :communityId AND userId = :userId")
  fun isUserCommunityMember(communityId: String, userId: String): Flow<Boolean>

  @Query("SELECT COUNT(*) > 0 FROM community_members WHERE communityId = :communityId AND userId = :userId")
  suspend fun isUserCommunityMemberSync(communityId: String, userId: String): Boolean

  @Query("SELECT * FROM community_members WHERE communityId = :communityId ORDER BY CASE role WHEN 'OWNER' THEN 1 WHEN 'ADMIN' THEN 2 ELSE 3 END, joinedAt ASC")
  fun getCommunityMembers(communityId: String): Flow<List<CatchyCommunityMember>>

  @Query("SELECT * FROM community_members WHERE communityId = :communityId ORDER BY joinedAt ASC")
  suspend fun getCommunityMembersSync(communityId: String): List<CatchyCommunityMember>

  @Query("SELECT COUNT(*) FROM community_members WHERE communityId = :communityId")
  fun getCommunityMemberCount(communityId: String): Flow<Int>

  @Query("SELECT COUNT(*) FROM community_members WHERE communityId = :communityId")
  suspend fun getCommunityMemberCountSync(communityId: String): Int

  @Query("UPDATE communities SET memberCount = :count WHERE id = :communityId")
  suspend fun updateCommunityMemberCount(communityId: String, count: Int): Int

  @Query("SELECT role FROM community_members WHERE communityId = :communityId AND userId = :userId LIMIT 1")
  suspend fun getMemberRole(communityId: String, userId: String): String?

  @Query("UPDATE community_members SET role = :newRole WHERE communityId = :communityId AND userId = :userId")
  suspend fun updateMemberRole(communityId: String, userId: String, newRole: String): Int

  // --- Community Posts ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunityPost(post: CatchyCommunityPost): Long

  @Update
  suspend fun updateCommunityPost(post: CatchyCommunityPost): Int

  @Query("DELETE FROM community_posts WHERE postId = :postId")
  suspend fun deleteCommunityPost(postId: String): Int

  @Query("DELETE FROM community_posts WHERE communityId = :communityId")
  suspend fun deleteAllPostsForCommunity(communityId: String): Int

  @Query("SELECT * FROM community_posts WHERE postId = :postId LIMIT 1")
  suspend fun getCommunityPostById(postId: String): CatchyCommunityPost?

  @Query("SELECT * FROM community_posts WHERE communityId = :communityId ORDER BY isPinned DESC, createdAt DESC")
  fun observeCommunityPosts(communityId: String): Flow<List<CatchyCommunityPost>>

  @Query("UPDATE community_posts SET likesCount = MAX(0, likesCount + :delta) WHERE postId = :postId")
  suspend fun updateCommunityPostLikesCount(postId: String, delta: Int): Int

  @Query("UPDATE community_posts SET commentsCount = MAX(0, commentsCount + :delta) WHERE postId = :postId")
  suspend fun updateCommunityPostCommentsCount(postId: String, delta: Int): Int

  @Query("UPDATE community_posts SET sharesCount = sharesCount + :delta WHERE postId = :postId")
  suspend fun updateCommunityPostSharesCount(postId: String, delta: Int): Int

  @Query("UPDATE community_posts SET isPinned = :pinned WHERE postId = :postId")
  suspend fun updateCommunityPostPinned(postId: String, pinned: Boolean): Int

  // --- Community Post Likes ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunityPostLike(like: CatchyCommunityPostLike): Long

  @Query("DELETE FROM community_post_likes WHERE postId = :postId AND userId = :userId")
  suspend fun deleteCommunityPostLike(postId: String, userId: String): Int

  @Query("SELECT COUNT(*) > 0 FROM community_post_likes WHERE postId = :postId AND userId = :userId")
  fun isUserLikedCommunityPost(postId: String, userId: String): Flow<Boolean>

  @Query("SELECT COUNT(*) > 0 FROM community_post_likes WHERE postId = :postId AND userId = :userId")
  suspend fun isUserLikedCommunityPostSync(postId: String, userId: String): Boolean

  // --- Community Post Comments ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunityPostComment(comment: CatchyCommunityPostComment): Long

  @Query("DELETE FROM community_post_comments WHERE commentId = :commentId")
  suspend fun deleteCommunityPostComment(commentId: String): Int

  @Query("DELETE FROM community_post_comments WHERE postId = :postId")
  suspend fun deleteAllCommentsForCommunityPost(postId: String): Int

  @Query("SELECT * FROM community_post_comments WHERE postId = :postId ORDER BY createdAt ASC")
  fun observeCommunityPostComments(postId: String): Flow<List<CatchyCommunityPostComment>>

  // --- Community Safety Reports ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunityReport(report: CatchyCommunityReport): Long

  @Query("SELECT * FROM community_reports WHERE communityId = :communityId ORDER BY createdAt DESC")
  fun observeCommunityReports(communityId: String): Flow<List<CatchyCommunityReport>>

  @Query("UPDATE community_reports SET status = :newStatus WHERE reportId = :reportId")
  suspend fun updateCommunityReportStatus(reportId: String, newStatus: String): Int

  // --- Catchy Jobs / Career ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJobPosting(job: CatchyJobPosting): Long

  @Update
  suspend fun updateJobPosting(job: CatchyJobPosting): Int

  @Query("DELETE FROM catchy_job_postings WHERE jobId = :jobId")
  suspend fun deleteJobPosting(jobId: String): Int

  @Query("SELECT * FROM catchy_job_postings WHERE jobId = :jobId LIMIT 1")
  suspend fun getJobPostingById(jobId: String): CatchyJobPosting?

  @Query("SELECT * FROM catchy_job_postings WHERE status != 'DELETED' ORDER BY createdAt DESC")
  fun getAllJobPostings(): Flow<List<CatchyJobPosting>>

  @Query("SELECT * FROM catchy_job_postings WHERE status = 'ACTIVE' ORDER BY createdAt DESC")
  fun getActiveJobPostings(): Flow<List<CatchyJobPosting>>

  @Query("SELECT * FROM catchy_job_postings WHERE employerId = :employerId ORDER BY createdAt DESC")
  fun getJobPostingsByEmployer(employerId: String): Flow<List<CatchyJobPosting>>

  // Applications
  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertJobApplication(application: CatchyJobApplication): Long

  @Query("SELECT * FROM catchy_job_applications WHERE jobId = :jobId AND applicantId = :applicantId LIMIT 1")
  suspend fun getApplication(jobId: String, applicantId: String): CatchyJobApplication?

  @Query("SELECT * FROM catchy_job_applications WHERE jobId = :jobId ORDER BY appliedAt DESC")
  fun getApplicationsForJob(jobId: String): Flow<List<CatchyJobApplication>>

  @Query("SELECT * FROM catchy_job_applications WHERE applicantId = :applicantId ORDER BY appliedAt DESC")
  fun getApplicationsByApplicant(applicantId: String): Flow<List<CatchyJobApplication>>

  @Query("UPDATE catchy_job_applications SET status = :status, updatedAt = :updatedAt WHERE applicationId = :applicationId")
  suspend fun updateJobApplicationStatus(applicationId: String, status: String, updatedAt: Long): Int

  // Seeker & Employer Profiles
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateJobSeekerProfile(profile: CatchyJobSeekerProfile): Long

  @Query("SELECT * FROM catchy_job_seeker_profiles WHERE userId = :userId LIMIT 1")
  fun getJobSeekerProfile(userId: String): Flow<CatchyJobSeekerProfile?>

  @Query("SELECT * FROM catchy_job_seeker_profiles WHERE userId = :userId LIMIT 1")
  suspend fun getJobSeekerProfileSync(userId: String): CatchyJobSeekerProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateEmployerProfile(profile: CatchyEmployerProfile): Long

  @Query("SELECT * FROM catchy_employer_profiles WHERE userId = :userId LIMIT 1")
  fun getEmployerProfile(userId: String): Flow<CatchyEmployerProfile?>

  @Query("SELECT * FROM catchy_employer_profiles WHERE userId = :userId LIMIT 1")
  suspend fun getEmployerProfileSync(userId: String): CatchyEmployerProfile?

  // --- Catchy Investment Network ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvestmentOpportunity(opportunity: CatchyInvestmentOpportunity): Long

  @Update
  suspend fun updateInvestmentOpportunity(opportunity: CatchyInvestmentOpportunity): Int

  @Query("DELETE FROM catchy_investment_opportunities WHERE opportunityId = :opportunityId")
  suspend fun deleteInvestmentOpportunity(opportunityId: String): Int

  @Query("SELECT * FROM catchy_investment_opportunities WHERE opportunityId = :opportunityId LIMIT 1")
  suspend fun getInvestmentOpportunityById(opportunityId: String): CatchyInvestmentOpportunity?

  @Query("SELECT * FROM catchy_investment_opportunities WHERE status = 'ACTIVE' ORDER BY createdAt DESC")
  fun getActiveInvestmentOpportunities(): Flow<List<CatchyInvestmentOpportunity>>

  @Query("SELECT * FROM catchy_investment_opportunities WHERE creatorUserId = :creatorUserId ORDER BY createdAt DESC")
  fun getInvestmentOpportunitiesByCreator(creatorUserId: String): Flow<List<CatchyInvestmentOpportunity>>

  @Query("UPDATE catchy_investment_opportunities SET status = :status, updatedAt = :updatedAt WHERE opportunityId = :opportunityId")
  suspend fun updateOpportunityStatus(opportunityId: String, status: String, updatedAt: Long): Int

  // Investment Requests / Interest
  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertInvestmentRequest(request: CatchyInvestmentRequest): Long

  @Query("SELECT * FROM catchy_investment_requests WHERE opportunityId = :opportunityId AND investorUserId = :investorUserId LIMIT 1")
  suspend fun getExistingInvestmentRequest(opportunityId: String, investorUserId: String): CatchyInvestmentRequest?

  @Query("SELECT * FROM catchy_investment_requests WHERE investorUserId = :investorUserId ORDER BY createdAt DESC")
  fun getInvestmentRequestsByInvestor(investorUserId: String): Flow<List<CatchyInvestmentRequest>>

  @Query("SELECT * FROM catchy_investment_requests WHERE founderUserId = :founderUserId ORDER BY createdAt DESC")
  fun getInvestmentRequestsForFounder(founderUserId: String): Flow<List<CatchyInvestmentRequest>>

  @Query("SELECT * FROM catchy_investment_requests WHERE opportunityId = :opportunityId ORDER BY createdAt DESC")
  fun getInvestmentRequestsForOpportunity(opportunityId: String): Flow<List<CatchyInvestmentRequest>>

  @Query("UPDATE catchy_investment_requests SET status = :status, updatedAt = :updatedAt WHERE requestId = :requestId")
  suspend fun updateInvestmentRequestStatus(requestId: String, status: String, updatedAt: Long): Int

  // Investor & Founder Profiles
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateInvestorProfile(profile: CatchyInvestorProfile): Long

  @Query("SELECT * FROM catchy_investor_profiles WHERE userId = :userId LIMIT 1")
  fun getInvestorProfile(userId: String): Flow<CatchyInvestorProfile?>

  @Query("SELECT * FROM catchy_investor_profiles WHERE userId = :userId LIMIT 1")
  suspend fun getInvestorProfileSync(userId: String): CatchyInvestorProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateFounderProfile(profile: CatchyFounderProfile): Long

  @Query("SELECT * FROM catchy_founder_profiles WHERE userId = :userId LIMIT 1")
  fun getFounderProfile(userId: String): Flow<CatchyFounderProfile?>

  @Query("SELECT * FROM catchy_founder_profiles WHERE userId = :userId LIMIT 1")
  suspend fun getFounderProfileSync(userId: String): CatchyFounderProfile?

  // --- Catchy Business / Business Page ---
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBusinessPage(page: CatchyBusinessPage): Long

  @Update
  suspend fun updateBusinessPage(page: CatchyBusinessPage): Int

  @Query("SELECT * FROM catchy_business_pages WHERE pageId = :pageId LIMIT 1")
  suspend fun getBusinessPageById(pageId: String): CatchyBusinessPage?

  @Query("SELECT * FROM catchy_business_pages WHERE handle = :handle LIMIT 1")
  suspend fun getBusinessPageByHandle(handle: String): CatchyBusinessPage?

  @Query("SELECT * FROM catchy_business_pages WHERE status = 'ACTIVE' ORDER BY followersCount DESC, createdAt DESC")
  fun observeActiveBusinessPages(): Flow<List<CatchyBusinessPage>>

  @Query("SELECT * FROM catchy_business_pages WHERE ownerUserId = :ownerUserId ORDER BY createdAt DESC")
  fun observeBusinessPagesByOwner(ownerUserId: String): Flow<List<CatchyBusinessPage>>

  @Query("DELETE FROM catchy_business_pages WHERE pageId = :pageId")
  suspend fun deleteBusinessPage(pageId: String): Int

  @Query("UPDATE catchy_business_pages SET followersCount = MAX(0, followersCount + :delta) WHERE pageId = :pageId")
  suspend fun updatePageFollowersCount(pageId: String, delta: Int): Int

  // Business Posts
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBusinessPost(post: CatchyBusinessPost): Long

  @Query("SELECT * FROM catchy_business_posts WHERE pageId = :pageId ORDER BY createdAt DESC")
  fun observePostsByPage(pageId: String): Flow<List<CatchyBusinessPost>>

  @Query("DELETE FROM catchy_business_posts WHERE postId = :postId")
  suspend fun deleteBusinessPost(postId: String): Int

  // Business Follows
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBusinessPageFollow(follow: CatchyBusinessPageFollow): Long

  @Query("DELETE FROM catchy_business_follows WHERE pageId = :pageId AND userId = :userId")
  suspend fun deleteBusinessPageFollow(pageId: String, userId: String): Int

  @Query("SELECT COUNT(*) > 0 FROM catchy_business_follows WHERE pageId = :pageId AND userId = :userId")
  fun isUserFollowingPage(pageId: String, userId: String): Flow<Boolean>

  @Query("SELECT catchy_business_pages.* FROM catchy_business_pages INNER JOIN catchy_business_follows ON catchy_business_pages.pageId = catchy_business_follows.pageId WHERE catchy_business_follows.userId = :userId ORDER BY catchy_business_follows.followedAt DESC")
  fun observeFollowedPages(userId: String): Flow<List<CatchyBusinessPage>>

  // Business Inquiries
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBusinessInquiry(inquiry: CatchyBusinessInquiry): Long

  @Query("SELECT * FROM catchy_business_inquiries WHERE pageId = :pageId ORDER BY createdAt DESC")
  fun observeInquiriesByPage(pageId: String): Flow<List<CatchyBusinessInquiry>>

  @Query("SELECT * FROM catchy_business_inquiries WHERE pageId IN (SELECT pageId FROM catchy_business_pages WHERE ownerUserId = :ownerUserId) ORDER BY createdAt DESC")
  fun observeInquiriesForOwner(ownerUserId: String): Flow<List<CatchyBusinessInquiry>>

  @Query("UPDATE catchy_business_inquiries SET status = :status WHERE inquiryId = :inquiryId")
  suspend fun updateInquiryStatus(inquiryId: String, status: String): Int

  @Query("DELETE FROM catchy_business_inquiries WHERE inquiryId = :inquiryId")
  suspend fun deleteInquiry(inquiryId: String): Int
}
