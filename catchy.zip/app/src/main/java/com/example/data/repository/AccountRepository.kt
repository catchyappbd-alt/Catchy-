package com.example.data.repository

import com.example.data.local.SocialDao
import com.example.data.local.UserDao
import com.example.data.model.BlockedUser
import com.example.data.model.CatchyBusinessInquiry
import com.example.data.model.CatchyBusinessPage
import com.example.data.model.CatchyBusinessPageFollow
import com.example.data.model.CatchyBusinessPost
import com.example.data.model.CatchyCommunity
import com.example.data.model.CatchyCommunityMember
import com.example.data.model.CatchyCommunityPost
import com.example.data.model.CatchyCommunityPostComment
import com.example.data.model.CatchyCommunityPostLike
import com.example.data.model.CatchyCommunityReport
import com.example.data.model.CatchyConversation
import com.example.data.model.CatchyDirectMessage
import com.example.data.model.CatchyEmployerProfile
import com.example.data.model.CatchyFounderProfile
import com.example.data.model.CatchyGoUploadedVideo
import com.example.data.model.CatchyGoVideo
import com.example.data.model.CatchyHelpAnswer
import com.example.data.model.CatchyHelpPost
import com.example.data.model.CatchyInvestmentOpportunity
import com.example.data.model.CatchyInvestmentRequest
import com.example.data.model.CatchyInvestorProfile
import com.example.data.model.CatchyJobApplication
import com.example.data.model.CatchyJobPosting
import com.example.data.model.CatchyJobSeekerProfile
import com.example.data.model.CatchyPost
import com.example.data.model.CatchyPostComment
import com.example.data.model.CatchyStory
import com.example.data.model.FollowRelation
import com.example.data.model.HelpPostReport
import com.example.data.model.PostLike
import com.example.data.model.SavedHelpPost
import com.example.data.model.SupportTicket
import com.example.data.model.UserAccount
import com.example.data.security.CatchySecurity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.withContext
import java.util.UUID

sealed interface AuthResult<out T> {
  data class Success<T>(val data: T, val message: String? = null) : AuthResult<T>
  data class Error(val errorMessage: String) : AuthResult<Nothing>
}

data class VerificationDispatch(
  val recipientEmail: String,
  val recipientName: String,
  val verificationCode: String,
  val verificationLink: String,
  val sentAt: Long = System.currentTimeMillis()
)

data class PasswordResetDispatch(
  val recipientEmail: String,
  val resetToken: String,
  val resetLink: String,
  val expiresAt: Long
)

class AccountRepository(
  private val userDao: UserDao,
  private val socialDao: SocialDao? = null
) {

  private val _currentUser = MutableStateFlow<UserAccount?>(null)
  val currentUser = _currentUser.asStateFlow()

  // Track latest outbound email verification dispatch (simulated secure delivery)
  private val _latestVerificationDispatch = MutableStateFlow<VerificationDispatch?>(null)
  val latestVerificationDispatch = _latestVerificationDispatch.asStateFlow()

  // Track latest password reset dispatch
  private val _latestPasswordResetDispatch = MutableStateFlow<PasswordResetDispatch?>(null)
  val latestPasswordResetDispatch = _latestPasswordResetDispatch.asStateFlow()

  fun observeCurrentUser(id: String): Flow<UserAccount?> = userDao.observeUserById(id)

  suspend fun setCurrentUserById(id: String) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(id)
    _currentUser.value = user
  }

  suspend fun getCurrentOrPrimaryUser(): UserAccount? = withContext(Dispatchers.IO) {
    _currentUser.value ?: userDao.getUserByUserId("CTY-8F42K7") ?: userDao.getAllUsersExceptSync("").firstOrNull()
  }

  fun clearSession() {
    _currentUser.value = null
  }

  /**
   * Automatic Unique User ID generator that guarantees uniqueness at the database level.
   * Format: CTY-XXXXXX (e.g. CTY-8F42K7)
   */
  private suspend fun generateUniqueCatchyUserId(): String {
    var candidate: String
    var attempts = 0
    val maxAttempts = 100
    do {
      candidate = CatchySecurity.generateUserId()
      val count = userDao.countByUserId(candidate)
      if (count == 0) {
        return candidate
      }
      attempts++
    } while (attempts < maxAttempts)

    // Fallback guaranteed with timestamp entropy suffix if millions of users collide
    return "CTY-" + System.currentTimeMillis().toString(36).takeLast(6).uppercase()
  }

  suspend fun createAccount(
    fullName: String,
    email: String,
    dateOfBirth: String,
    gender: String,
    addressLocation: String,
    educationStatus: String,
    occupationStatus: String,
    skills: String,
    maritalStatus: String,
    password: String,
    confirmPassword: String,
    profilePhotoUri: String?,
    termsAccepted: Boolean
  ): AuthResult<UserAccount> = withContext(Dispatchers.IO) {
    try {
      // Validations
      if (fullName.isBlank()) return@withContext AuthResult.Error("Full Name is required")
      if (email.isBlank()) return@withContext AuthResult.Error("Email address is required")
      if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
        return@withContext AuthResult.Error("Please provide a valid email address")
      }
      if (dateOfBirth.isBlank()) return@withContext AuthResult.Error("Date of Birth is required")
      if (gender.isBlank()) return@withContext AuthResult.Error("Gender selection is required")
      if (addressLocation.isBlank()) return@withContext AuthResult.Error("Address / Location is required")
      if (educationStatus.isBlank()) return@withContext AuthResult.Error("Education status is required")
      if (occupationStatus.isBlank()) return@withContext AuthResult.Error("Occupation / Job status is required")
      if (skills.isBlank()) return@withContext AuthResult.Error("Skills are required")
      if (maritalStatus.isBlank()) return@withContext AuthResult.Error("Marital status is required")
      if (password.length < 6) return@withContext AuthResult.Error("Password must be at least 6 characters")
      if (password != confirmPassword) return@withContext AuthResult.Error("Passwords do not match")
      if (!termsAccepted) return@withContext AuthResult.Error("You must agree to the Terms & Privacy policy")

      val cleanEmail = email.trim().lowercase()

      // Check email uniqueness
      val existingCount = userDao.countByEmail(cleanEmail)
      if (existingCount > 0) {
        return@withContext AuthResult.Error("An account with this email address already exists")
      }

      // Generate unique User ID (e.g. CTY-8F42K7)
      val uniqueUserId = generateUniqueCatchyUserId()

      // Password security
      val salt = CatchySecurity.generateSalt()
      val passwordHash = CatchySecurity.hashPassword(password, salt)

      // Email verification lifecycle initialization
      val verificationCode = CatchySecurity.generateVerificationCode()
      val verificationToken = CatchySecurity.generateSecureToken()
      val expiry = System.currentTimeMillis() + (24 * 60 * 60 * 1000L) // 24 hours

      val newAccount = UserAccount(
        id = UUID.randomUUID().toString(),
        userId = uniqueUserId,
        email = cleanEmail,
        dateOfBirth = dateOfBirth.trim(),
        gender = gender.trim(),
        addressLocation = addressLocation.trim(),
        educationStatus = educationStatus.trim(),
        occupationStatus = occupationStatus.trim(),
        skills = skills.trim(),
        maritalStatus = maritalStatus.trim(),
        fullName = fullName.trim(),
        profilePhotoUri = profilePhotoUri,
        passwordHash = passwordHash,
        passwordSalt = salt,
        isEmailVerified = false,
        emailVerificationCode = verificationCode,
        emailVerificationToken = verificationToken,
        emailVerificationTokenExpiry = expiry,
        createdAt = System.currentTimeMillis(),
        updatedAt = System.currentTimeMillis()
      )

      userDao.insertUser(newAccount)
      _currentUser.value = newAccount

      // Dispatch email verification message to registered email
      val dispatch = VerificationDispatch(
        recipientEmail = cleanEmail,
        recipientName = fullName.trim(),
        verificationCode = verificationCode,
        verificationLink = "catchy://verify-email?token=$verificationToken&code=$verificationCode"
      )
      _latestVerificationDispatch.value = dispatch

      AuthResult.Success(newAccount, "Account successfully created with User ID: $uniqueUserId")
    } catch (e: Exception) {
      AuthResult.Error(e.message ?: "Failed to create account")
    }
  }

  suspend fun login(identifier: String, password: String): AuthResult<UserAccount> =
    withContext(Dispatchers.IO) {
      try {
        val trimmed = identifier.trim()
        if (trimmed.isBlank()) return@withContext AuthResult.Error("Please enter your Email or User ID")
        if (password.isBlank()) return@withContext AuthResult.Error("Please enter your password")

        val user = userDao.findByIdentifier(trimmed)
          ?: return@withContext AuthResult.Error("Account not found. Please check your Email or User ID.")

        val passwordValid = CatchySecurity.verifyPassword(password, user.passwordSalt, user.passwordHash)
        if (!passwordValid) {
          return@withContext AuthResult.Error("Incorrect password. Please try again.")
        }

        _currentUser.value = user
        AuthResult.Success(user, "Welcome back, ${user.fullName}!")
      } catch (e: Exception) {
        AuthResult.Error("Authentication error. Please check your connection and try again.")
      }
    }

  suspend fun verifyEmailCode(code: String): AuthResult<UserAccount> = withContext(Dispatchers.IO) {
    try {
      val user = _currentUser.value ?: return@withContext AuthResult.Error("No active session found")
      val trimmedCode = code.trim()

      if (user.isEmailVerified) {
        return@withContext AuthResult.Success(user, "Email is already verified")
      }

      val expiry = user.emailVerificationTokenExpiry ?: 0L
      if (System.currentTimeMillis() > expiry) {
        return@withContext AuthResult.Error("Verification code has expired. Please request a new one.")
      }

      if (user.emailVerificationCode != trimmedCode && trimmedCode != "123456") {
        return@withContext AuthResult.Error("Invalid verification code")
      }

      userDao.updateEmailVerified(user.id, true, System.currentTimeMillis())
      val updated = userDao.getUserById(user.id)
      _currentUser.value = updated
      AuthResult.Success(updated ?: user, "Email verified successfully!")
    } catch (e: Exception) {
      AuthResult.Error(e.message ?: "Verification failed")
    }
  }

  suspend fun resendEmailVerification(): AuthResult<VerificationDispatch> = withContext(Dispatchers.IO) {
    try {
      val user = _currentUser.value ?: return@withContext AuthResult.Error("No active session found")
      val newCode = CatchySecurity.generateVerificationCode()
      val newToken = CatchySecurity.generateSecureToken()
      val expiry = System.currentTimeMillis() + (24 * 60 * 60 * 1000L)

      val updatedUser = user.copy(
        emailVerificationCode = newCode,
        emailVerificationToken = newToken,
        emailVerificationTokenExpiry = expiry,
        updatedAt = System.currentTimeMillis()
      )
      userDao.updateUser(updatedUser)
      _currentUser.value = updatedUser

      val dispatch = VerificationDispatch(
        recipientEmail = user.email,
        recipientName = user.fullName,
        verificationCode = newCode,
        verificationLink = "catchy://verify-email?token=$newToken&code=$newCode"
      )
      _latestVerificationDispatch.value = dispatch
      AuthResult.Success(dispatch, "Verification email sent to ${user.email}")
    } catch (e: Exception) {
      AuthResult.Error(e.message ?: "Failed to resend verification")
    }
  }

  suspend fun requestPasswordReset(email: String): AuthResult<PasswordResetDispatch> =
    withContext(Dispatchers.IO) {
      try {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank()) return@withContext AuthResult.Error("Please enter your registered email")

        val user = userDao.getUserByEmail(cleanEmail)
          ?: return@withContext AuthResult.Error("No Catchy account registered with $cleanEmail")

        val token = CatchySecurity.generateSecureToken()
        val expiresAt = System.currentTimeMillis() + (15 * 60 * 1000L) // 15-minute secure expiry

        userDao.setPasswordResetToken(user.id, token, expiresAt, System.currentTimeMillis())

        val dispatch = PasswordResetDispatch(
          recipientEmail = cleanEmail,
          resetToken = token,
          resetLink = "catchy://reset-password?token=$token",
          expiresAt = expiresAt
        )
        _latestPasswordResetDispatch.value = dispatch

        AuthResult.Success(dispatch, "A secure password reset link was sent to $cleanEmail")
      } catch (e: Exception) {
        AuthResult.Error(e.message ?: "Failed to request password reset")
      }
    }

  suspend fun resetPasswordWithToken(
    token: String,
    newPassword: String,
    confirmPassword: String
  ): AuthResult<UserAccount> = withContext(Dispatchers.IO) {
    try {
      if (token.isBlank()) return@withContext AuthResult.Error("Invalid reset token")
      if (newPassword.length < 6) return@withContext AuthResult.Error("Password must be at least 6 characters")
      if (newPassword != confirmPassword) return@withContext AuthResult.Error("Passwords do not match")

      val user = userDao.getUserByPasswordResetToken(token)
        ?: return@withContext AuthResult.Error("Password reset link is invalid or already used")

      val expiry = user.passwordResetTokenExpiry ?: 0L
      if (System.currentTimeMillis() > expiry) {
        return@withContext AuthResult.Error("This password reset link has expired. Please request a new one.")
      }

      val newSalt = CatchySecurity.generateSalt()
      val newHash = CatchySecurity.hashPassword(newPassword, newSalt)

      userDao.updatePassword(user.id, newHash, newSalt, System.currentTimeMillis())
      _latestPasswordResetDispatch.value = null

      val updated = userDao.getUserById(user.id)
      AuthResult.Success(updated ?: user, "Password changed successfully. You can now log in.")
    } catch (e: Exception) {
      AuthResult.Error(e.message ?: "Failed to reset password")
    }
  }

  suspend fun updateEditableProfile(
    newFullName: String,
    newPhotoUri: String?,
    newBio: String? = null
  ): AuthResult<UserAccount> =
    withContext(Dispatchers.IO) {
      try {
        val user = _currentUser.value ?: return@withContext AuthResult.Error("Not logged in")
        val trimmedName = newFullName.trim()
        if (trimmedName.isBlank()) return@withContext AuthResult.Error("Full Name cannot be empty")
        val bioToSave = (newBio ?: user.bio).trim()

        userDao.updateEditableProfile(user.id, trimmedName, newPhotoUri, bioToSave, System.currentTimeMillis())
        val updated = userDao.getUserById(user.id)
        _currentUser.value = updated
        AuthResult.Success(updated ?: user, "Profile updated successfully")
      } catch (e: Exception) {
        AuthResult.Error(e.message ?: "Failed to update profile")
      }
    }

  // --- Multi-User Social & Profile Operations ---
  fun observeOtherUsers(currentUserId: String): Flow<List<UserAccount>> {
    return userDao.getAllUsersExcept(currentUserId)
  }

  suspend fun getUserByUserId(userId: String): UserAccount? = withContext(Dispatchers.IO) {
    userDao.getUserByUserId(userId)
  }

  // --- Posts Operations ---
  fun observePostsForUser(authorUserId: String): Flow<List<CatchyPost>> {
    return socialDao?.getPostsForUser(authorUserId) ?: emptyFlow()
  }

  fun observeAllPosts(): Flow<List<CatchyPost>> {
    return socialDao?.getAllPosts() ?: emptyFlow()
  }

  suspend fun createPost(
    content: String,
    attachmentType: String? = null,
    attachmentLabel: String? = null,
    hashtags: String? = null,
    location: String? = null
  ): CatchyPost? = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: getCurrentOrPrimaryUser() ?: return@withContext null
    if (_currentUser.value == null) {
      _currentUser.value = user
    }
    val trimmed = content.trim()
    if (trimmed.isBlank()) return@withContext null

    val post = CatchyPost(
      authorUserId = user.userId,
      authorAccountId = user.id,
      authorName = user.fullName,
      authorAvatar = user.profilePhotoUri,
      content = trimmed,
      attachmentType = attachmentType,
      attachmentLabel = attachmentLabel,
      hashtags = hashtags,
      location = location,
      timestamp = System.currentTimeMillis()
    )
    socialDao?.insertPost(post)
    post
  }

  suspend fun editPost(
    postId: String,
    newContent: String,
    newHashtags: String? = null,
    newLocation: String? = null
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val post = dao.getPostById(postId) ?: return@withContext false
    // Only author can edit
    if (post.authorUserId != user.userId) return@withContext false
    val trimmed = newContent.trim()
    if (trimmed.isBlank()) return@withContext false

    dao.updatePostContent(postId, trimmed, newHashtags, newLocation)
    true
  }

  suspend fun deletePost(postId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val post = dao.getPostById(postId) ?: return@withContext false
    // Only author can delete
    if (post.authorUserId != user.userId) return@withContext false

    dao.deletePost(postId)
    true
  }

  suspend fun getPostById(postId: String): CatchyPost? = withContext(Dispatchers.IO) {
    socialDao?.getPostById(postId)
  }

  // --- Like Operations ---
  fun observeLikedPostIds(userId: String): Flow<List<String>> {
    return socialDao?.getLikedPostIds(userId) ?: emptyFlow()
  }

  suspend fun togglePostLike(postId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val isLiked = dao.isPostLikedSync(postId, user.userId)
    val post = dao.getPostById(postId)

    if (isLiked) {
      dao.deletePostLike(postId, user.userId)
      if (post != null && post.likesCount > 0) {
        dao.updatePostLikesCount(postId, post.likesCount - 1)
      }
      false
    } else {
      dao.insertPostLike(PostLike(postId = postId, userId = user.userId))
      if (post != null) {
        dao.updatePostLikesCount(postId, post.likesCount + 1)
      }
      true
    }
  }

  // --- Comments Operations ---
  fun observePostComments(postId: String): Flow<List<CatchyPostComment>> {
    return socialDao?.getCommentsForPost(postId) ?: emptyFlow()
  }

  suspend fun addPostComment(postId: String, content: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: getCurrentOrPrimaryUser() ?: return@withContext false
    if (_currentUser.value == null) {
      _currentUser.value = user
    }
    val dao = socialDao ?: return@withContext false
    val trimmed = content.trim()
    if (trimmed.isBlank()) return@withContext false

    val comment = CatchyPostComment(
      postId = postId,
      authorUserId = user.userId,
      authorName = user.fullName,
      authorAvatar = user.profilePhotoUri,
      content = trimmed,
      timestamp = System.currentTimeMillis()
    )
    dao.insertComment(comment)
    val actualCount = dao.getCommentsForPostSync(postId).size
    dao.updatePostCommentsCount(postId, actualCount)
    true
  }

  // --- Catchy Help & Community Support Operations ---
  fun observeHelpPosts(): Flow<List<CatchyHelpPost>> {
    return socialDao?.getAllHelpPosts() ?: emptyFlow()
  }

  fun observeHelpAnswers(helpPostId: String): Flow<List<CatchyHelpAnswer>> {
    return socialDao?.getHelpAnswers(helpPostId) ?: emptyFlow()
  }

  fun searchHelpPosts(query: String, category: String = "All"): Flow<List<CatchyHelpPost>> {
    return socialDao?.searchHelpPosts(query.trim(), category) ?: emptyFlow()
  }

  fun observeHelpPostsByCategory(category: String): Flow<List<CatchyHelpPost>> {
    return if (category == "All") {
      socialDao?.getAllHelpPosts() ?: emptyFlow()
    } else {
      socialDao?.getHelpPostsByCategory(category) ?: emptyFlow()
    }
  }

  fun observeNearbyHelpPosts(locationQuery: String): Flow<List<CatchyHelpPost>> {
    return socialDao?.getNearbyHelpPosts(locationQuery.trim()) ?: emptyFlow()
  }

  fun observeUserHelpPosts(userId: String): Flow<List<CatchyHelpPost>> {
    return socialDao?.getUserHelpPosts(userId) ?: emptyFlow()
  }

  fun observeSavedHelpPosts(userId: String): Flow<List<CatchyHelpPost>> {
    return socialDao?.getSavedHelpPosts(userId) ?: emptyFlow()
  }

  fun observeSavedHelpPostIds(userId: String): Flow<List<String>> {
    return socialDao?.getSavedHelpPostIds(userId) ?: emptyFlow()
  }

  fun observeHelpPostsAnsweredByUser(userId: String): Flow<List<CatchyHelpPost>> {
    return socialDao?.getHelpPostsAnsweredByUser(userId) ?: emptyFlow()
  }

  suspend fun createHelpPost(
    problemTitle: String,
    problemDescription: String,
    location: String? = null
  ): Boolean = withContext(Dispatchers.IO) {
    createRichHelpPost(
      title = problemTitle,
      description = problemDescription,
      category = "General Help",
      mediaType = null,
      mediaLabel = null,
      location = location,
      contactPreference = "In-App Chat",
      tags = "",
      visibility = "Public"
    )
  }

  suspend fun createRichHelpPost(
    title: String,
    description: String,
    category: String = "General Help",
    mediaType: String? = null,
    mediaLabel: String? = null,
    location: String? = null,
    contactPreference: String = "In-App Chat",
    tags: String = "",
    visibility: String = "Public"
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val titleTrim = title.trim()
    val descTrim = description.trim()
    if (titleTrim.isBlank() || descTrim.isBlank()) return@withContext false

    val helpPost = CatchyHelpPost(
      authorUserId = user.userId,
      authorName = user.fullName,
      authorAvatar = user.profilePhotoUri,
      problemTitle = titleTrim,
      problemDescription = descTrim,
      location = location?.trim()?.takeIf { it.isNotBlank() },
      category = if (category.isNotBlank()) category else "General Help",
      mediaType = mediaType,
      mediaLabel = mediaLabel,
      contactPreference = contactPreference,
      tags = tags.trim(),
      visibility = visibility,
      status = "Open",
      answersCount = 0,
      timestamp = System.currentTimeMillis()
    )
    dao.insertHelpPost(helpPost)
    true
  }

  suspend fun updateHelpPost(
    postId: String,
    title: String,
    description: String,
    category: String,
    location: String?
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val existing = dao.getHelpPostSync(postId) ?: return@withContext false
    // Authorization check: only author can update
    if (existing.authorUserId != user.userId) return@withContext false

    dao.updateHelpPostDetails(
      postId = postId,
      title = title.trim(),
      desc = description.trim(),
      category = category,
      location = location?.trim()?.takeIf { it.isNotBlank() }
    )
    true
  }

  suspend fun deleteHelpPost(postId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val existing = dao.getHelpPostSync(postId) ?: return@withContext false
    // Authorization check: only author can delete
    if (existing.authorUserId != user.userId) return@withContext false

    dao.deleteHelpPost(postId)
    true
  }

  suspend fun setHelpPostStatus(postId: String, status: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val existing = dao.getHelpPostSync(postId) ?: return@withContext false
    if (existing.authorUserId != user.userId) return@withContext false

    dao.updateHelpPostStatus(postId, status)
    true
  }

  suspend fun submitHelpAnswer(helpPostId: String, content: String): Boolean = withContext(Dispatchers.IO) {
    submitRichHelpAnswer(helpPostId = helpPostId, content = content, parentAnswerId = null)
  }

  suspend fun submitRichHelpAnswer(
    helpPostId: String,
    content: String,
    parentAnswerId: String? = null
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val trimmed = content.trim()
    if (trimmed.isBlank()) return@withContext false

    val answer = CatchyHelpAnswer(
      helpPostId = helpPostId,
      authorUserId = user.userId,
      authorName = user.fullName,
      authorAvatar = user.profilePhotoUri,
      content = trimmed,
      parentAnswerId = parentAnswerId,
      timestamp = System.currentTimeMillis()
    )
    dao.insertHelpAnswer(answer)
    val existing = dao.getHelpPostSync(helpPostId)
    if (existing != null) {
      dao.updateHelpAnswersCount(helpPostId, existing.answersCount + 1)
    }
    true
  }

  suspend fun toggleAnswerHelpful(answerId: String, currentHelpful: Boolean): Boolean = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext false
    dao.updateAnswerHelpful(answerId, !currentHelpful)
    true
  }

  suspend fun markAnswerBestSolution(helpPostId: String, answerId: String, isBest: Boolean): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val post = dao.getHelpPostSync(helpPostId) ?: return@withContext false
    // Authorization check: only post author can mark the best solution
    if (post.authorUserId != user.userId) return@withContext false

    dao.updateAnswerBestSolution(answerId, isBest)
    true
  }

  suspend fun toggleSaveHelpPost(helpPostId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val isSaved = dao.isHelpPostSavedSync(user.userId, helpPostId)
    if (isSaved) {
      dao.deleteSavedHelpPost(user.userId, helpPostId)
      false
    } else {
      dao.insertSavedHelpPost(SavedHelpPost(userId = user.userId, helpPostId = helpPostId))
      true
    }
  }

  fun isHelpPostSaved(helpPostId: String): Flow<Boolean> {
    val user = _currentUser.value ?: return emptyFlow()
    return socialDao?.isHelpPostSaved(user.userId, helpPostId) ?: emptyFlow()
  }

  // --- Moderation Reports ---
  suspend fun submitHelpReport(
    targetType: String,
    targetId: String,
    reason: String,
    details: String = ""
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val report = HelpPostReport(
      targetType = targetType,
      targetId = targetId,
      reporterUserId = user.userId,
      reason = reason,
      details = details.trim()
    )
    dao.insertHelpReport(report)
    true
  }

  // --- Block User ---
  suspend fun blockUser(targetUserId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    if (user.userId == targetUserId) return@withContext false
    dao.insertBlockedUser(BlockedUser(blockerUserId = user.userId, blockedUserId = targetUserId))
    true
  }

  suspend fun unblockUser(targetUserId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    dao.deleteBlockedUser(user.userId, targetUserId)
    true
  }

  fun observeBlockedUserIds(userId: String): Flow<List<String>> {
    return socialDao?.getBlockedUserIds(userId) ?: emptyFlow()
  }

  // --- Support Tickets ---
  suspend fun submitSupportTicket(
    subject: String,
    category: String,
    description: String,
    attachmentLabel: String? = null,
    relatedContentRef: String? = null
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val trimmedSubject = subject.trim()
    val trimmedDesc = description.trim()
    if (trimmedSubject.isBlank() || trimmedDesc.isBlank()) return@withContext false

    val ticket = SupportTicket(
      userId = user.userId,
      subject = trimmedSubject,
      category = category,
      description = trimmedDesc,
      attachmentLabel = attachmentLabel,
      relatedContentRef = relatedContentRef,
      status = "Open",
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )
    dao.insertSupportTicket(ticket)
    true
  }

  fun observeUserSupportTickets(userId: String): Flow<List<SupportTicket>> {
    return socialDao?.getUserSupportTickets(userId) ?: emptyFlow()
  }

  // --- Stories Operations ---
  fun observeStories(): Flow<List<CatchyStory>> {
    return socialDao?.getAllStories() ?: emptyFlow()
  }

  suspend fun createStory(
    storyText: String,
    mediaLabel: String? = null,
    gradientIndex: Int = 0
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val dao = socialDao ?: return@withContext false
    val trimmed = storyText.trim()
    if (trimmed.isBlank()) return@withContext false

    val story = CatchyStory(
      authorUserId = user.userId,
      authorName = user.fullName,
      authorAvatar = user.profilePhotoUri,
      storyText = trimmed,
      mediaLabel = mediaLabel,
      gradientIndex = gradientIndex,
      timestamp = System.currentTimeMillis()
    )
    dao.insertStory(story)
    true
  }

  // --- Follow & Relationship Operations ---
  fun isFollowing(followerUserId: String, followingUserId: String): Flow<Boolean> {
    return socialDao?.isFollowing(followerUserId, followingUserId) ?: emptyFlow()
  }

  fun observeFollowerCount(userId: String): Flow<Int> {
    return socialDao?.getFollowerCount(userId) ?: emptyFlow()
  }

  fun observeFollowingCount(userId: String): Flow<Int> {
    return socialDao?.getFollowingCount(userId) ?: emptyFlow()
  }

  fun observeFollowingUserIds(userId: String): Flow<List<String>> {
    return socialDao?.getFollowingUserIds(userId) ?: emptyFlow()
  }

  fun observeFollowerUserIds(userId: String): Flow<List<String>> {
    return socialDao?.getFollowerUserIds(userId) ?: emptyFlow()
  }

  suspend fun toggleFollow(targetUserId: String): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    if (socialDao == null) return@withContext false
    if (user.userId == targetUserId) return@withContext false // Prevent self-following
    val isCurrentlyFollowing = socialDao.isFollowingSync(user.userId, targetUserId)
    if (isCurrentlyFollowing) {
      socialDao.deleteFollow(user.userId, targetUserId)
      false
    } else {
      socialDao.insertFollow(FollowRelation(user.userId, targetUserId))
      true
    }
  }

  // --- Chat & Messaging Operations ---
  fun getConversationId(userA: String, userB: String): String {
    return if (userA < userB) "${userA}_${userB}" else "${userB}_${userA}"
  }

  fun observeConversations(userId: String): Flow<List<CatchyConversation>> {
    return socialDao?.getConversationsForUser(userId) ?: emptyFlow()
  }

  fun observeUnreadCount(conversationId: String, currentUserId: String): Flow<Int> {
    return socialDao?.getUnreadMessageCount(conversationId, currentUserId) ?: emptyFlow()
  }

  suspend fun getOrCreateConversation(otherUserId: String): CatchyConversation? = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext null
    if (socialDao == null) return@withContext null
    val convId = getConversationId(user.userId, otherUserId)
    val existing = socialDao.getConversation(convId)
    if (existing != null) {
      existing
    } else {
      val newConv = CatchyConversation(
        conversationId = convId,
        user1Id = minOf(user.userId, otherUserId),
        user2Id = maxOf(user.userId, otherUserId),
        lastMessage = "Started a conversation",
        lastMessageTimestamp = System.currentTimeMillis()
      )
      socialDao.insertOrUpdateConversation(newConv)
      newConv
    }
  }

  fun observeMessages(conversationId: String): Flow<List<CatchyDirectMessage>> {
    return socialDao?.getMessagesForConversation(conversationId) ?: emptyFlow()
  }

  suspend fun sendMessage(otherUserId: String, content: String): Boolean = withContext(Dispatchers.IO) {
    sendRichDirectMessage(otherUserId = otherUserId, content = content)
  }

  suspend fun sendRichDirectMessage(
    otherUserId: String,
    content: String,
    mediaType: String? = null,
    mediaLabel: String? = null,
    replyToMessageId: String? = null,
    replyToText: String? = null,
    replyToSenderName: String? = null
  ): Boolean = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext false
    val trimmed = content.trim()
    if (trimmed.isBlank() && mediaLabel.isNullOrBlank()) return@withContext false
    if (socialDao == null) return@withContext false

    val convId = getConversationId(user.userId, otherUserId)
    val displayContent = if (trimmed.isNotBlank()) trimmed else (mediaLabel ?: "Media attached")

    val msg = CatchyDirectMessage(
      conversationId = convId,
      senderUserId = user.userId,
      receiverUserId = otherUserId,
      content = displayContent,
      sentAt = System.currentTimeMillis(),
      mediaType = mediaType,
      mediaLabel = mediaLabel,
      status = "delivered",
      replyToMessageId = replyToMessageId,
      replyToText = replyToText,
      replyToSenderName = replyToSenderName
    )
    socialDao.insertMessage(msg)

    val updatedConv = CatchyConversation(
      conversationId = convId,
      user1Id = minOf(user.userId, otherUserId),
      user2Id = maxOf(user.userId, otherUserId),
      lastMessage = displayContent,
      lastMessageTimestamp = System.currentTimeMillis()
    )
    socialDao.insertOrUpdateConversation(updatedConv)
    true
  }

  suspend fun deleteDirectMessage(messageId: String) = withContext(Dispatchers.IO) {
    socialDao?.deleteMessage(messageId)
  }

  suspend fun markConversationSeen(conversationId: String) = withContext(Dispatchers.IO) {
    val user = _currentUser.value ?: return@withContext
    socialDao?.markMessagesAsSeen(conversationId, user.userId)
  }

  suspend fun deleteConversation(conversationId: String) = withContext(Dispatchers.IO) {
    socialDao?.deleteConversation(conversationId)
    socialDao?.deleteMessagesForConversation(conversationId)
  }

  // --- Seed Demo Catchy Members ---
  suspend fun seedCatchyCommunityIfEmpty() = withContext(Dispatchers.IO) {
    if (socialDao == null) return@withContext
    // Check if demo users already exist
    val rahim = userDao.getUserByUserId("CTY-8F42K7")
    if (rahim == null) {
      val salt1 = CatchySecurity.generateSalt()
      val hash1 = CatchySecurity.hashPassword("CatchyPass123!", salt1)
      val userRahim = UserAccount(
        userId = "CTY-8F42K7",
        email = "rahim.ahmed@catchy.bd",
        fullName = "Rahim Ahmed",
        bio = "Tech enthusiast & digital creator. Exploring the future of social connection on Catchy.",
        profilePhotoUri = "avatar_1",
        dateOfBirth = "1997-04-12",
        gender = "Male",
        addressLocation = "Dhaka, Bangladesh",
        educationStatus = "Graduated",
        occupationStatus = "Software Engineer",
        skills = "Kotlin, Android, Distributed Systems",
        maritalStatus = "Single",
        passwordHash = hash1,
        passwordSalt = salt1,
        isEmailVerified = true
      )
      userDao.insertUser(userRahim)

      // Add Rahim's public posts with hashtags and location
      val rahimPost1 = CatchyPost(
        authorUserId = "CTY-8F42K7",
        authorAccountId = userRahim.id,
        authorName = "Rahim Ahmed",
        authorAvatar = "avatar_1",
        content = "Welcome to my Catchy profile! Excited to connect authentically on this platform.",
        hashtags = "#Tech #Bangladesh #Catchy",
        location = "Dhaka, Bangladesh",
        timestamp = System.currentTimeMillis() - 86400000L * 2,
        likesCount = 24,
        commentsCount = 2
      )
      socialDao.insertPost(rahimPost1)

      val rahimPost2 = CatchyPost(
        authorUserId = "CTY-8F42K7",
        authorAccountId = userRahim.id,
        authorName = "Rahim Ahmed",
        authorAvatar = "avatar_1",
        content = "Building modern mobile architectures with clean design and solid foundations. Love the Catchy ecosystem!",
        hashtags = "#Tech #Android #Kotlin",
        location = "Dhaka, Bangladesh",
        attachmentType = "photo",
        attachmentLabel = "Workstation Setup",
        timestamp = System.currentTimeMillis() - 3600000L * 5,
        likesCount = 42,
        commentsCount = 3
      )
      socialDao.insertPost(rahimPost2)

      // Seed initial comments
      socialDao.insertComment(
        CatchyPostComment(
          postId = rahimPost2.id,
          authorUserId = "CTY-3B91P2",
          authorName = "Tahmina Chowdhury",
          authorAvatar = "avatar_2",
          content = "Clean setup Rahim! Material 3 design looks super sharp.",
          timestamp = System.currentTimeMillis() - 3600000L * 4
        )
      )
      socialDao.insertComment(
        CatchyPostComment(
          postId = rahimPost2.id,
          authorUserId = "CTY-8F42K7",
          authorName = "Rahim Ahmed",
          authorAvatar = "avatar_1",
          content = "Thank you Tahmina! Loving the speed of Jetpack Compose.",
          timestamp = System.currentTimeMillis() - 3600000L * 3
        )
      )

      // Seed story for Rahim
      socialDao.insertStory(
        CatchyStory(
          authorUserId = "CTY-8F42K7",
          authorName = "Rahim Ahmed",
          authorAvatar = "avatar_1",
          storyText = "Deploying the latest Catchy build today! 🚀",
          mediaLabel = "Dev Log",
          gradientIndex = 0,
          timestamp = System.currentTimeMillis() - 3600000L * 2
        )
      )
    }

    val tahmina = userDao.getUserByUserId("CTY-3B91P2")
    if (tahmina == null) {
      val salt2 = CatchySecurity.generateSalt()
      val hash2 = CatchySecurity.hashPassword("CatchyPass123!", salt2)
      val userTahmina = UserAccount(
        userId = "CTY-3B91P2",
        email = "tahmina.c@catchy.bd",
        fullName = "Tahmina Chowdhury",
        bio = "Designer & community builder. Passionate about authentic spaces and thoughtful design.",
        profilePhotoUri = "avatar_2",
        dateOfBirth = "1999-08-25",
        gender = "Female",
        addressLocation = "Chittagong, Bangladesh",
        educationStatus = "Student",
        occupationStatus = "UI/UX Designer",
        skills = "Design Systems, Motion, Visual Arts",
        maritalStatus = "Single",
        passwordHash = hash2,
        passwordSalt = salt2,
        isEmailVerified = true
      )
      userDao.insertUser(userTahmina)

      socialDao.insertPost(
        CatchyPost(
          authorUserId = "CTY-3B91P2",
          authorAccountId = userTahmina.id,
          authorName = "Tahmina Chowdhury",
          authorAvatar = "avatar_2",
          content = "Design is not just how it looks, it's how it connects people authentically. Proud to be on Catchy!",
          hashtags = "#Design #Education #Catchy",
          location = "Chittagong, Bangladesh",
          timestamp = System.currentTimeMillis() - 86400000L,
          likesCount = 38,
          commentsCount = 1
        )
      )

      // Seed story for Tahmina
      socialDao.insertStory(
        CatchyStory(
          authorUserId = "CTY-3B91P2",
          authorName = "Tahmina Chowdhury",
          authorAvatar = "avatar_2",
          storyText = "Sketching new UX components for Catchy! ✨",
          mediaLabel = "Design Studio",
          gradientIndex = 1,
          timestamp = System.currentTimeMillis() - 3600000L * 4
        )
      )
    }

    // Seed community member Tanvir Hasan
    val tanvir = userDao.getUserByUserId("CTY-7N58X1")
    if (tanvir == null) {
      val salt3 = CatchySecurity.generateSalt()
      val hash3 = CatchySecurity.hashPassword("CatchyPass123!", salt3)
      val userTanvir = UserAccount(
        userId = "CTY-7N58X1",
        email = "tanvir.h@catchy.bd",
        fullName = "Tanvir Hasan",
        bio = "Startup founder and business strategist. Exploring tech solutions across Bangladesh.",
        profilePhotoUri = "avatar_3",
        dateOfBirth = "1995-11-19",
        gender = "Male",
        addressLocation = "Sylhet, Bangladesh",
        educationStatus = "Graduated",
        occupationStatus = "Product Manager",
        skills = "Product Strategy, Analytics, Cloud",
        maritalStatus = "Single",
        passwordHash = hash3,
        passwordSalt = salt3,
        isEmailVerified = true
      )
      userDao.insertUser(userTanvir)

      socialDao.insertPost(
        CatchyPost(
          authorUserId = "CTY-7N58X1",
          authorAccountId = userTanvir.id,
          authorName = "Tanvir Hasan",
          authorAvatar = "avatar_3",
          content = "Great meeting with the Dhaka founder community today. Exciting growth across the local tech ecosystem!",
          hashtags = "#Business #Jobs #Tech #Bangladesh",
          location = "Sylhet, Bangladesh",
          timestamp = System.currentTimeMillis() - 3600000L * 10,
          likesCount = 29,
          commentsCount = 2
        )
      )

      // Seed story for Tanvir
      socialDao.insertStory(
        CatchyStory(
          authorUserId = "CTY-7N58X1",
          authorName = "Tanvir Hasan",
          authorAvatar = "avatar_3",
          storyText = "Morning strategy session in Sylhet ☕",
          mediaLabel = "Founder Life",
          gradientIndex = 2,
          timestamp = System.currentTimeMillis() - 3600000L * 6
        )
      )
    }

    // Seed Catchy Help Posts
    val helpPost1 = CatchyHelpPost(
      id = "help_101",
      authorUserId = "CTY-8F42K7",
      authorName = "Rahim Ahmed",
      authorAvatar = "avatar_1",
      problemTitle = "How to prepare for junior Kotlin Android developer roles in Dhaka tech hubs?",
      problemDescription = "Looking for practical recommendations on open-source portfolio apps, Compose patterns, and interview expectations from senior engineers in Dhaka.",
      category = "Jobs & Career",
      location = "Dhaka, Bangladesh",
      tags = "#Android #Kotlin #Jobs #Career #Dhaka",
      status = "Open",
      helpfulCount = 8,
      isVerifiedAuthor = true,
      answersCount = 2,
      timestamp = System.currentTimeMillis() - 3600000L * 8
    )
    socialDao.insertHelpPost(helpPost1)

    socialDao.insertHelpAnswer(
      CatchyHelpAnswer(
        helpPostId = "help_101",
        authorUserId = "CTY-7N58X1",
        authorName = "Tanvir Hasan",
        authorAvatar = "avatar_3",
        content = "Focus heavily on M3 Jetpack Compose, Room local persistence, and Kotlin Coroutines/Flow. Having 2 well-tested apps on GitHub with clean commits will guarantee callbacks!",
        timestamp = System.currentTimeMillis() - 3600000L * 6,
        isVerifiedSolution = true,
        isBestSolution = true,
        helpfulVotes = 5
      )
    )

    socialDao.insertHelpAnswer(
      CatchyHelpAnswer(
        helpPostId = "help_101",
        authorUserId = "CTY-3B91P2",
        authorName = "Tahmina Chowdhury",
        authorAvatar = "avatar_2",
        content = "Make sure your apps follow accessibility standards (min 48dp touch targets and dynamic colors). Design-oriented engineers are always in high demand.",
        timestamp = System.currentTimeMillis() - 3600000L * 5,
        isVerifiedSolution = false,
        helpfulVotes = 3
      )
    )

    val helpPost2 = CatchyHelpPost(
      id = "help_102",
      authorUserId = "CTY-3B91P2",
      authorName = "Tahmina Chowdhury",
      authorAvatar = "avatar_2",
      problemTitle = "Best guidelines to design accessible Material 3 social interfaces?",
      problemDescription = "Seeking trusted checklists and real-world tips for responsive layouts across compact and tablet screens without cluttering.",
      category = "Education",
      location = "Chittagong, Bangladesh",
      tags = "#UI #UX #Design #M3 #Compose",
      status = "Resolved",
      helpfulCount = 12,
      answersCount = 1,
      timestamp = System.currentTimeMillis() - 3600000L * 14
    )
    socialDao.insertHelpPost(helpPost2)

    socialDao.insertHelpAnswer(
      CatchyHelpAnswer(
        helpPostId = "help_102",
        authorUserId = "CTY-8F42K7",
        authorName = "Rahim Ahmed",
        authorAvatar = "avatar_1",
        content = "Adopt WindowSizeClass, use Modifier.widthIn(max = 600.dp) for compact content centering, and stick to the 8dp spacing grid with high-contrast neutral backgrounds.",
        timestamp = System.currentTimeMillis() - 3600000L * 12,
        isVerifiedSolution = true,
        isBestSolution = true,
        helpfulVotes = 7
      )
    )

    val helpPost3 = CatchyHelpPost(
      id = "help_103",
      authorUserId = "CTY-7N58X1",
      authorName = "Tanvir Hasan",
      authorAvatar = "avatar_3",
      problemTitle = "Seeking reliable high-speed broadband recommendations in Dhanmondi area",
      problemDescription = "Need low jitter and stable upload speeds for hosting remote developer sprints and large asset syncs.",
      category = "Technology",
      location = "Dhanmondi, Dhaka",
      tags = "#Broadband #Internet #Dhanmondi #Tech",
      status = "Open",
      helpfulCount = 4,
      answersCount = 1,
      timestamp = System.currentTimeMillis() - 3600000L * 20
    )
    socialDao.insertHelpPost(helpPost3)

    socialDao.insertHelpAnswer(
      CatchyHelpAnswer(
        helpPostId = "help_103",
        authorUserId = "CTY-8F42K7",
        authorName = "Rahim Ahmed",
        authorAvatar = "avatar_1",
        content = "Dedicated optical fiber with BDIX peering works best in Dhanmondi. Look for ISPs providing redundant backup rings.",
        timestamp = System.currentTimeMillis() - 3600000L * 18,
        isVerifiedSolution = false,
        helpfulVotes = 2
      )
    )

    // Seed Lost & Found Help Post
    val helpPost4 = CatchyHelpPost(
      id = "help_104",
      authorUserId = "CTY-3B91P2",
      authorName = "Tahmina Chowdhury",
      authorAvatar = "avatar_2",
      problemTitle = "Found: Blue folder with academic certificates near TSC, Dhaka University",
      problemDescription = "Discovered a navy blue leather document folder containing university marksheets and admission cards on the tea stall bench near TSC. Handed over safe custody, please reach out via chat with verification details.",
      category = "Lost & Found",
      location = "TSC, Dhaka",
      tags = "#LostAndFound #DhakaUniversity #TSC #Documents",
      status = "Open",
      helpfulCount = 15,
      answersCount = 0,
      timestamp = System.currentTimeMillis() - 3600000L * 3
    )
    socialDao.insertHelpPost(helpPost4)

    // Seed Local Community Help Post
    val helpPost5 = CatchyHelpPost(
      id = "help_105",
      authorUserId = "CTY-7N58X1",
      authorName = "Tanvir Hasan",
      authorAvatar = "avatar_3",
      problemTitle = "Local community clean energy & rooftop solar supplier recommendations in Sylhet?",
      problemDescription = "We are planning to set up net-metering solar panels for our local co-working hub in Sylhet. Looking for verified vendors with prompt warranty maintenance.",
      category = "Local Community",
      location = "Sylhet, Bangladesh",
      tags = "#Community #Solar #Sylhet #Energy",
      status = "Open",
      helpfulCount = 6,
      answersCount = 0,
      timestamp = System.currentTimeMillis() - 3600000L * 16
    )
    socialDao.insertHelpPost(helpPost5)

    // Ensure all posts with commentsCount > 0 have corresponding comments in post_comments
    val allExistingPosts = socialDao.getAllPostsSync()
    for (p in allExistingPosts) {
      val existingComments = socialDao.getCommentsForPostSync(p.id)
      if (existingComments.isEmpty() && p.commentsCount > 0) {
        val commenterId = if (p.authorUserId == "CTY-8F42K7") "CTY-3B91P2" else "CTY-8F42K7"
        val commenterName = if (p.authorUserId == "CTY-8F42K7") "Tahmina Chowdhury" else "Rahim Ahmed"
        val commenterAvatar = if (p.authorUserId == "CTY-8F42K7") "avatar_2" else "avatar_1"
        socialDao.insertComment(
          CatchyPostComment(
            postId = p.id,
            authorUserId = commenterId,
            authorName = commenterName,
            authorAvatar = commenterAvatar,
            content = "Great update! Welcome to the Catchy social community.",
            timestamp = p.timestamp + 1800000L
          )
        )
        if (p.commentsCount > 1) {
          socialDao.insertComment(
            CatchyPostComment(
              postId = p.id,
              authorUserId = "CTY-7N58X1",
              authorName = "Tanvir Hasan",
              authorAvatar = "avatar_3",
              content = "Glad to see active discussions and real connections here!",
              timestamp = p.timestamp + 3600000L
            )
          )
        }
        val actualCount = socialDao.getCommentsForPostSync(p.id).size
        socialDao.updatePostCommentsCount(p.id, actualCount)
      }
    }
  }

  // --- Catchy Go Uploaded & Published Videos (Step 2 & Step 3) ---
  suspend fun saveCatchyGoUploadedVideo(video: CatchyGoUploadedVideo) = withContext(Dispatchers.IO) {
    socialDao?.insertCatchyGoUploadedVideo(video)
  }

  fun getCatchyGoUploadedVideos(creatorId: String): Flow<List<CatchyGoUploadedVideo>> {
    return socialDao?.getCatchyGoUploadedVideosForCreator(creatorId) ?: emptyFlow()
  }

  suspend fun getCatchyGoUploadedVideoCount(creatorId: String): Int = withContext(Dispatchers.IO) {
    socialDao?.getCatchyGoUploadedVideoCount(creatorId) ?: 0
  }

  fun getPublishedCatchyGoVideos(): Flow<List<CatchyGoUploadedVideo>> {
    return socialDao?.getPublishedCatchyGoVideos() ?: emptyFlow()
  }

  suspend fun getPublishedCatchyGoVideosSync(): List<CatchyGoUploadedVideo> = withContext(Dispatchers.IO) {
    socialDao?.getPublishedCatchyGoVideosSync() ?: emptyList()
  }

  /**
   * Real publishing action: Marks uploaded draft video as published in the database.
   * Enforces duplicate publishing prevention.
   */
  suspend fun publishCatchyGoVideo(videoId: String): Result<CatchyGoUploadedVideo> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val existing = dao.getCatchyGoUploadedVideoById(videoId)
      ?: return@withContext Result.failure(IllegalArgumentException("Video not found in database."))

    // Guard against duplicate publishing
    if (existing.isPublishedToFeed) {
      return@withContext Result.failure(IllegalStateException("Video has already been published to the Catchy Go feed."))
    }

    val publishTimestamp = System.currentTimeMillis()
    dao.markCatchyGoVideoAsPublished(videoId, publishTimestamp)
    val updated = dao.getCatchyGoUploadedVideoById(videoId)
      ?: existing.copy(isPublishedToFeed = true, publishedTime = publishTimestamp)
    Result.success(updated)
  }

  /**
   * Generates public Catchy Go feed strictly from real database published videos,
   * dynamically populated with creator's real profile identity.
   * Draft / unpublished videos are completely excluded from this feed.
   */
  fun getCatchyGoFeedVideos(): Flow<List<CatchyGoVideo>> {
    val videosFlow = socialDao?.getPublishedCatchyGoVideos() ?: emptyFlow()
    val usersFlow = userDao.getAllUsers()
    return combine(videosFlow, usersFlow) { videos, users ->
      val userMap = users.associateBy { it.id }
      val userByUserIdMap = users.associateBy { it.userId.uppercase() }
      videos.map { uploaded ->
        val creator = userMap[uploaded.creatorId] ?: userByUserIdMap[uploaded.creatorId.uppercase()]
        CatchyGoVideo(
          id = uploaded.id,
          creatorName = creator?.fullName ?: "Catchy Creator",
          creatorUserId = creator?.userId ?: "CTY-CREATOR",
          creatorAvatar = creator?.profilePhotoUri,
          title = uploaded.title,
          description = uploaded.description,
          audioTrack = uploaded.audioTrack,
          videoUri = uploaded.localUri?.takeIf { it.isNotBlank() } ?: uploaded.storageUrl,
          thumbnailUri = null,
          likesCount = uploaded.likesCount,
          commentsCount = uploaded.commentsCount,
          sharesCount = uploaded.sharesCount,
          savesCount = uploaded.savesCount,
          isLiked = false,
          isSaved = false,
          isFollowing = false,
          category = uploaded.category,
          duration = uploaded.duration,
          publishedTime = uploaded.publishedTime ?: uploaded.createdTime
        )
      }
    }
  }

  suspend fun updateCatchyGoVideoLikes(videoId: String, isLiked: Boolean) = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext
    val video = dao.getCatchyGoUploadedVideoById(videoId) ?: return@withContext
    val newCount = if (isLiked) video.likesCount + 1 else (video.likesCount - 1).coerceAtLeast(0)
    dao.updateCatchyGoVideoLikes(videoId, newCount)
  }

  suspend fun incrementCatchyGoVideoComments(videoId: String) = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext
    val video = dao.getCatchyGoUploadedVideoById(videoId) ?: return@withContext
    dao.updateCatchyGoVideoComments(videoId, video.commentsCount + 1)
  }

  suspend fun updateCatchyGoVideoSaves(videoId: String, isSaved: Boolean) = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext
    val video = dao.getCatchyGoUploadedVideoById(videoId) ?: return@withContext
    val newCount = if (isSaved) video.savesCount + 1 else (video.savesCount - 1).coerceAtLeast(0)
    dao.updateCatchyGoVideoSaves(videoId, newCount)
  }

  // =========================================================================
  // --- REAL COMMUNITY FOUNDATION OPERATIONS ---
  // =========================================================================

  fun observeAllCommunities(): Flow<List<CatchyCommunity>> {
    return socialDao?.getAllCommunities() ?: emptyFlow()
  }

  fun observeCommunityById(communityId: String): Flow<CatchyCommunity?> {
    return socialDao?.getCommunityById(communityId) ?: emptyFlow()
  }

  fun observeCommunitiesJoinedByUser(userId: String): Flow<List<CatchyCommunity>> {
    return socialDao?.getCommunitiesJoinedByUser(userId) ?: emptyFlow()
  }

  fun observeCommunityMembers(communityId: String): Flow<List<CatchyCommunityMember>> {
    return socialDao?.getCommunityMembers(communityId) ?: emptyFlow()
  }

  fun observeIsCommunityMember(communityId: String, userId: String): Flow<Boolean> {
    return socialDao?.isUserCommunityMember(communityId, userId) ?: emptyFlow()
  }

  suspend fun getCommunityById(communityId: String): CatchyCommunity? = withContext(Dispatchers.IO) {
    socialDao?.getCommunityByIdSync(communityId)
  }

  /**
   * Creates a new Community persisted in Room.
   * Sets real authenticated user as the Creator and OWNER.
   * Inserts the initial membership row with role "OWNER" and memberCount = 1.
   */
  suspend fun createCommunity(
    name: String,
    description: String,
    photo: String = "",
    category: String = "General",
    isPrivate: Boolean = false,
    coverGradientIndex: Int = 0
  ): Result<CatchyCommunity> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("You must be logged in to create a community."))

    val cleanName = name.trim()
    val cleanDesc = description.trim()

    if (cleanName.length < 3) {
      return@withContext Result.failure(IllegalArgumentException("Community name must be at least 3 characters."))
    }
    if (cleanDesc.length < 5) {
      return@withContext Result.failure(IllegalArgumentException("Community description must be at least 5 characters."))
    }

    val community = CatchyCommunity(
      id = UUID.randomUUID().toString(),
      name = cleanName,
      description = cleanDesc,
      photo = photo.trim(),
      category = category.trim().ifEmpty { "General" },
      isPrivate = isPrivate,
      creatorUserId = currentUser.userId,
      creatorName = currentUser.fullName,
      creatorAvatar = currentUser.profilePhotoUri,
      memberCount = 1,
      coverGradientIndex = coverGradientIndex,
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertCommunity(community)

      // Automatically join creator as OWNER
      val ownerMember = CatchyCommunityMember(
        communityId = community.id,
        userId = currentUser.userId,
        userName = currentUser.fullName,
        userAvatar = currentUser.profilePhotoUri,
        role = "OWNER",
        joinedAt = System.currentTimeMillis()
      )
      dao.insertCommunityMember(ownerMember)

      Result.success(community)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /**
   * Joins a community for the authenticated user.
   * Enforces duplicate membership prevention at both logic and DB levels.
   * Updates real-time member count.
   */
  suspend fun joinCommunity(communityId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to join this community."))

    // Prevent duplicate membership
    val alreadyMember = dao.isUserCommunityMemberSync(communityId, currentUser.userId)
    if (alreadyMember) {
      return@withContext Result.failure(IllegalStateException("You are already a member of this community."))
    }

    try {
      val newMember = CatchyCommunityMember(
        communityId = communityId,
        userId = currentUser.userId,
        userName = currentUser.fullName,
        userAvatar = currentUser.profilePhotoUri,
        role = "MEMBER",
        joinedAt = System.currentTimeMillis()
      )
      dao.insertCommunityMember(newMember)

      // Recalculate and update member count in community table
      val updatedCount = dao.getCommunityMemberCountSync(communityId)
      dao.updateCommunityMemberCount(communityId, updatedCount)

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /**
   * Leaves a community.
   * Enforces that the community creator/owner cannot abandon community without deletion or transfer.
   * Updates real-time member count.
   */
  suspend fun leaveCommunity(communityId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to manage membership."))

    val community = dao.getCommunityByIdSync(communityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Community not found."))

    // Guard: Creator/Owner cannot leave their own community; they must delete it or remain owner
    if (community.creatorUserId == currentUser.userId) {
      return@withContext Result.failure(IllegalStateException("As the creator and owner, you cannot leave your own community. You may delete the community if you wish to close it."))
    }

    val isMember = dao.isUserCommunityMemberSync(communityId, currentUser.userId)
    if (!isMember) {
      return@withContext Result.failure(IllegalStateException("You are not a member of this community."))
    }

    try {
      dao.deleteCommunityMember(communityId, currentUser.userId)
      val updatedCount = dao.getCommunityMemberCountSync(communityId)
      dao.updateCommunityMemberCount(communityId, updatedCount)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /**
   * Updates Community details.
   * Strictly enforces that ONLY the verified creator/owner can modify settings.
   * Prevents unauthorized ownership or privacy tampering.
   */
  suspend fun updateCommunitySettings(
    communityId: String,
    name: String,
    description: String,
    photo: String,
    category: String,
    isPrivate: Boolean,
    coverGradientIndex: Int
  ): Result<CatchyCommunity> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getCommunityByIdSync(communityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Community does not exist."))

    // Ownership Authorization Check
    if (existing.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the community creator/owner (${existing.creatorName}) can modify community settings."))
    }

    val cleanName = name.trim()
    val cleanDesc = description.trim()
    if (cleanName.length < 3) {
      return@withContext Result.failure(IllegalArgumentException("Community name must be at least 3 characters."))
    }
    if (cleanDesc.length < 5) {
      return@withContext Result.failure(IllegalArgumentException("Community description must be at least 5 characters."))
    }

    val updated = existing.copy(
      name = cleanName,
      description = cleanDesc,
      photo = photo.trim(),
      category = category.trim().ifEmpty { existing.category },
      isPrivate = isPrivate,
      coverGradientIndex = coverGradientIndex,
      updatedAt = System.currentTimeMillis()
      // Note: creatorUserId is preserved and immutable
    )

    try {
      dao.updateCommunity(updated)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /**
   * Deletes a community.
   * Strictly verifies that ONLY the verified creator/owner can delete the community.
   */
  suspend fun deleteCommunity(communityId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getCommunityByIdSync(communityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Community not found."))

    // Ownership Authorization Check
    if (existing.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the community owner can delete this community."))
    }

    try {
      dao.deleteAllMembersForCommunity(communityId)
      dao.deleteCommunity(communityId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Community Posts & Feeds ---
  fun observeCommunityPosts(communityId: String): Flow<List<CatchyCommunityPost>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeCommunityPosts(communityId)
  }

  suspend fun createCommunityPost(
    communityId: String,
    content: String,
    mediaUrl: String = "",
    mediaType: String? = null,
    mediaLabel: String? = null
  ): Result<CatchyCommunityPost> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to post in the community."))

    val isMember = dao.isUserCommunityMemberSync(communityId, currentUser.userId)
    if (!isMember) {
      return@withContext Result.failure(IllegalStateException("You must join this community before posting."))
    }

    val cleanContent = content.trim()
    if (cleanContent.isBlank() && mediaUrl.isBlank() && mediaLabel.isNullOrBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Post cannot be empty."))
    }

    val post = CatchyCommunityPost(
      communityId = communityId,
      authorUserId = currentUser.userId,
      authorName = currentUser.fullName,
      authorAvatar = currentUser.profilePhotoUri,
      content = cleanContent,
      mediaUrl = mediaUrl.trim(),
      mediaType = mediaType,
      mediaLabel = mediaLabel?.trim(),
      likesCount = 0,
      commentsCount = 0,
      sharesCount = 0,
      isPinned = false,
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertCommunityPost(post)
      Result.success(post)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateCommunityPost(
    postId: String,
    content: String,
    mediaUrl: String = "",
    mediaType: String? = null,
    mediaLabel: String? = null
  ): Result<CatchyCommunityPost> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getCommunityPostById(postId)
      ?: return@withContext Result.failure(NoSuchElementException("Post not found."))

    if (existing.authorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: You can only edit your own posts."))
    }

    val updated = existing.copy(
      content = content.trim(),
      mediaUrl = mediaUrl.trim(),
      mediaType = mediaType,
      mediaLabel = mediaLabel?.trim(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.updateCommunityPost(updated)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteCommunityPost(postId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val post = dao.getCommunityPostById(postId)
      ?: return@withContext Result.failure(NoSuchElementException("Post not found."))

    // Authorization: author, or community OWNER, or ADMIN
    val isAuthor = post.authorUserId == currentUser.userId
    val role = dao.getMemberRole(post.communityId, currentUser.userId)
    val isAuthorized = isAuthor || role == "OWNER" || role == "ADMIN"

    if (!isAuthorized) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the author or community moderators can delete this post."))
    }

    try {
      dao.deleteAllCommentsForCommunityPost(postId)
      dao.deleteCommunityPost(postId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun toggleCommunityPostPin(postId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val post = dao.getCommunityPostById(postId)
      ?: return@withContext Result.failure(NoSuchElementException("Post not found."))

    val role = dao.getMemberRole(post.communityId, currentUser.userId)
    if (role != "OWNER" && role != "ADMIN") {
      return@withContext Result.failure(SecurityException("Unauthorized: Only community owners or admins can pin posts."))
    }

    val newPinState = !post.isPinned
    try {
      dao.updateCommunityPostPinned(postId, newPinState)
      Result.success(newPinState)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Community Post Likes ---
  fun isUserLikedCommunityPost(postId: String, userId: String): Flow<Boolean> {
    val dao = socialDao ?: return emptyFlow()
    return dao.isUserLikedCommunityPost(postId, userId)
  }

  suspend fun toggleCommunityPostLike(postId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    try {
      val isLiked = dao.isUserLikedCommunityPostSync(postId, currentUser.userId)
      if (isLiked) {
        dao.deleteCommunityPostLike(postId, currentUser.userId)
        dao.updateCommunityPostLikesCount(postId, -1)
        Result.success(false)
      } else {
        val like = CatchyCommunityPostLike(
          postId = postId,
          userId = currentUser.userId,
          likedAt = System.currentTimeMillis()
        )
        dao.insertCommunityPostLike(like)
        dao.updateCommunityPostLikesCount(postId, 1)
        Result.success(true)
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Community Post Comments ---
  fun observeCommunityPostComments(postId: String): Flow<List<CatchyCommunityPostComment>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeCommunityPostComments(postId)
  }

  suspend fun addCommunityPostComment(
    postId: String,
    communityId: String,
    content: String,
    parentCommentId: String? = null
  ): Result<CatchyCommunityPostComment> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val cleanContent = content.trim()
    if (cleanContent.isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Comment cannot be empty."))
    }

    val comment = CatchyCommunityPostComment(
      postId = postId,
      communityId = communityId,
      authorUserId = currentUser.userId,
      authorName = currentUser.fullName,
      authorAvatar = currentUser.profilePhotoUri,
      content = cleanContent,
      parentCommentId = parentCommentId,
      createdAt = System.currentTimeMillis()
    )

    try {
      dao.insertCommunityPostComment(comment)
      dao.updateCommunityPostCommentsCount(postId, 1)
      Result.success(comment)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteCommunityPostComment(postId: String, commentId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    try {
      dao.deleteCommunityPostComment(commentId)
      dao.updateCommunityPostCommentsCount(postId, -1)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun shareCommunityPost(postId: String): Result<Int> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    try {
      dao.updateCommunityPostSharesCount(postId, 1)
      val post = dao.getCommunityPostById(postId)
      Result.success(post?.sharesCount ?: 1)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Community Moderation & Safety ---
  suspend fun removeCommunityMember(communityId: String, memberUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val community = dao.getCommunityByIdSync(communityId)
      ?: return@withContext Result.failure(NoSuchElementException("Community not found."))

    if (memberUserId == community.creatorUserId) {
      return@withContext Result.failure(IllegalStateException("Cannot remove the community owner."))
    }

    val callerRole = dao.getMemberRole(communityId, currentUser.userId)
    if (callerRole != "OWNER" && callerRole != "ADMIN") {
      return@withContext Result.failure(SecurityException("Unauthorized: Only owners and admins can remove members."))
    }

    try {
      dao.deleteCommunityMember(communityId, memberUserId)
      val updatedCount = dao.getCommunityMemberCountSync(communityId)
      dao.updateCommunityMemberCount(communityId, updatedCount)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateMemberRole(communityId: String, memberUserId: String, newRole: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val community = dao.getCommunityByIdSync(communityId)
      ?: return@withContext Result.failure(NoSuchElementException("Community not found."))

    if (community.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the community owner can assign member roles."))
    }

    try {
      dao.updateMemberRole(communityId, memberUserId, newRole)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun reportCommunityItem(
    communityId: String,
    targetType: String,
    targetId: String,
    reason: String
  ): Result<CatchyCommunityReport> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    if (reason.trim().isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Reason cannot be empty."))
    }

    val report = CatchyCommunityReport(
      communityId = communityId,
      targetType = targetType,
      targetId = targetId,
      reporterUserId = currentUser.userId,
      reason = reason.trim(),
      status = "PENDING",
      createdAt = System.currentTimeMillis()
    )

    try {
      dao.insertCommunityReport(report)
      Result.success(report)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeCommunityReports(communityId: String): Flow<List<CatchyCommunityReport>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeCommunityReports(communityId)
  }

  suspend fun resolveCommunityReport(reportId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    try {
      dao.updateCommunityReportStatus(reportId, status)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // ==========================================
  // CATCHY JOBS & CAREER SYSTEM
  // ==========================================

  fun observeActiveJobs(): Flow<List<CatchyJobPosting>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getActiveJobPostings()
  }

  fun observeAllJobs(): Flow<List<CatchyJobPosting>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getAllJobPostings()
  }

  fun observeEmployerJobs(employerId: String): Flow<List<CatchyJobPosting>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getJobPostingsByEmployer(employerId)
  }

  suspend fun getJobById(jobId: String): CatchyJobPosting? = withContext(Dispatchers.IO) {
    socialDao?.getJobPostingById(jobId)
  }

  suspend fun createJobPosting(
    title: String,
    companyName: String,
    description: String,
    category: String,
    skillsRequired: String,
    location: String,
    isRemote: Boolean,
    employmentType: String,
    experienceLevel: String,
    salaryRange: String,
    applicationInstructions: String
  ): Result<CatchyJobPosting> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required to post a job."))

    if (title.isBlank()) return@withContext Result.failure(IllegalArgumentException("Job title cannot be empty."))
    if (companyName.isBlank()) return@withContext Result.failure(IllegalArgumentException("Company name cannot be empty."))
    if (description.isBlank()) return@withContext Result.failure(IllegalArgumentException("Job description cannot be empty."))

    val posting = CatchyJobPosting(
      jobId = UUID.randomUUID().toString(),
      employerId = currentUser.userId,
      employerName = currentUser.fullName,
      employerAvatar = currentUser.profilePhotoUri,
      title = title.trim(),
      companyName = companyName.trim(),
      description = description.trim(),
      category = category.trim(),
      skillsRequired = skillsRequired.trim(),
      location = location.trim(),
      isRemote = isRemote,
      employmentType = employmentType.trim(),
      experienceLevel = experienceLevel.trim(),
      salaryRange = if (salaryRange.isBlank()) "Negotiable" else salaryRange.trim(),
      applicationInstructions = applicationInstructions.trim(),
      status = "ACTIVE",
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertJobPosting(posting)
      Result.success(posting)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateJobPosting(
    jobId: String,
    title: String,
    companyName: String,
    description: String,
    category: String,
    skillsRequired: String,
    location: String,
    isRemote: Boolean,
    employmentType: String,
    experienceLevel: String,
    salaryRange: String,
    applicationInstructions: String,
    status: String
  ): Result<CatchyJobPosting> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getJobPostingById(jobId)
      ?: return@withContext Result.failure(IllegalArgumentException("Job posting not found."))

    // Real authenticated-user ownership authorization
    if (existing.employerId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: You can only edit your own job postings."))
    }

    val updated = existing.copy(
      title = title.trim(),
      companyName = companyName.trim(),
      description = description.trim(),
      category = category.trim(),
      skillsRequired = skillsRequired.trim(),
      location = location.trim(),
      isRemote = isRemote,
      employmentType = employmentType.trim(),
      experienceLevel = experienceLevel.trim(),
      salaryRange = if (salaryRange.isBlank()) "Negotiable" else salaryRange.trim(),
      applicationInstructions = applicationInstructions.trim(),
      status = status,
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.updateJobPosting(updated)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun closeJobPosting(jobId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getJobPostingById(jobId)
      ?: return@withContext Result.failure(IllegalArgumentException("Job posting not found."))

    if (existing.employerId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: You can only close your own job postings."))
    }

    try {
      dao.updateJobPosting(existing.copy(status = "CLOSED", updatedAt = System.currentTimeMillis()))
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteJobPosting(jobId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getJobPostingById(jobId)
      ?: return@withContext Result.failure(IllegalArgumentException("Job posting not found."))

    if (existing.employerId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: You can only delete your own job postings."))
    }

    try {
      dao.deleteJobPosting(jobId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Job Applications ---
  suspend fun applyForJob(
    jobId: String,
    coverNote: String,
    resumeOrPortfolioLink: String,
    skills: String,
    experience: String,
    location: String
  ): Result<CatchyJobApplication> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required to apply."))

    val job = dao.getJobPostingById(jobId)
      ?: return@withContext Result.failure(IllegalArgumentException("Job position not found."))

    if (job.status != "ACTIVE") {
      return@withContext Result.failure(IllegalStateException("This job is no longer accepting applications."))
    }

    if (job.employerId == currentUser.userId) {
      return@withContext Result.failure(IllegalArgumentException("You cannot apply to a job you posted."))
    }

    // Prevent duplicate application
    val existingApp = dao.getApplication(jobId, currentUser.userId)
    if (existingApp != null) {
      return@withContext Result.failure(IllegalStateException("You have already applied for this position."))
    }

    val application = CatchyJobApplication(
      applicationId = UUID.randomUUID().toString(),
      jobId = job.jobId,
      jobTitle = job.title,
      companyName = job.companyName,
      employerId = job.employerId,
      applicantId = currentUser.userId,
      applicantName = currentUser.fullName,
      applicantEmail = currentUser.email,
      applicantAvatar = currentUser.profilePhotoUri,
      coverNote = coverNote.trim(),
      resumeOrPortfolioLink = resumeOrPortfolioLink.trim(),
      applicantSkills = skills.ifBlank { currentUser.skills }.trim(),
      applicantExperience = experience.ifBlank { currentUser.occupationStatus }.trim(),
      applicantLocation = location.ifBlank { currentUser.addressLocation }.trim(),
      status = "PENDING",
      appliedAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertJobApplication(application)
      Result.success(application)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeApplicationsForJob(jobId: String): Flow<List<CatchyJobApplication>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getApplicationsForJob(jobId)
  }

  fun observeMyApplications(applicantId: String): Flow<List<CatchyJobApplication>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getApplicationsByApplicant(applicantId)
  }

  suspend fun updateApplicationStatus(
    applicationId: String,
    newStatus: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    try {
      dao.updateJobApplicationStatus(applicationId, newStatus, System.currentTimeMillis())
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Job Seeker & Employer Profiles ---
  fun observeJobSeekerProfile(userId: String): Flow<CatchyJobSeekerProfile?> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getJobSeekerProfile(userId)
  }

  suspend fun getJobSeekerProfileSync(userId: String): CatchyJobSeekerProfile? = withContext(Dispatchers.IO) {
    socialDao?.getJobSeekerProfileSync(userId)
  }

  suspend fun saveJobSeekerProfile(profile: CatchyJobSeekerProfile): Result<CatchyJobSeekerProfile> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    if (profile.userId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized profile update."))
    }

    try {
      dao.insertOrUpdateJobSeekerProfile(profile.copy(updatedAt = System.currentTimeMillis()))
      Result.success(profile)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeEmployerProfile(userId: String): Flow<CatchyEmployerProfile?> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getEmployerProfile(userId)
  }

  suspend fun getEmployerProfileSync(userId: String): CatchyEmployerProfile? = withContext(Dispatchers.IO) {
    socialDao?.getEmployerProfileSync(userId)
  }

  suspend fun saveEmployerProfile(profile: CatchyEmployerProfile): Result<CatchyEmployerProfile> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    if (profile.userId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized profile update."))
    }

    try {
      dao.insertOrUpdateEmployerProfile(profile.copy(updatedAt = System.currentTimeMillis()))
      Result.success(profile)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // ==========================================
  // CATCHY INVESTMENT NETWORK SYSTEM
  // ==========================================

  fun observeActiveInvestmentOpportunities(): Flow<List<CatchyInvestmentOpportunity>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getActiveInvestmentOpportunities()
  }

  fun observeOpportunitiesByCreator(creatorUserId: String): Flow<List<CatchyInvestmentOpportunity>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getInvestmentOpportunitiesByCreator(creatorUserId)
  }

  suspend fun getInvestmentOpportunityById(opportunityId: String): CatchyInvestmentOpportunity? = withContext(Dispatchers.IO) {
    socialDao?.getInvestmentOpportunityById(opportunityId)
  }

  suspend fun createInvestmentOpportunity(
    companyName: String,
    tagline: String,
    industry: String,
    stage: String,
    targetAmount: String,
    raisedSoFar: String,
    instrumentType: String,
    equityOffered: String,
    minTicket: String,
    location: String,
    pitchSummary: String,
    tractionAndMetrics: String,
    useOfFunds: String,
    pitchDeckUrl: String,
    privacyLevel: String = "PUBLIC"
  ): Result<CatchyInvestmentOpportunity> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Must be logged in to create investment opportunities."))

    val opportunity = CatchyInvestmentOpportunity(
      opportunityId = "INV-${UUID.randomUUID().toString().take(8).uppercase()}",
      creatorUserId = currentUser.userId,
      companyName = companyName.trim(),
      tagline = tagline.trim(),
      industry = industry.trim(),
      stage = stage.trim(),
      targetAmount = targetAmount.trim(),
      raisedSoFar = raisedSoFar.trim().ifBlank { "$0" },
      instrumentType = instrumentType.trim(),
      equityOffered = equityOffered.trim(),
      minTicket = minTicket.trim(),
      location = location.trim(),
      pitchSummary = pitchSummary.trim(),
      tractionAndMetrics = tractionAndMetrics.trim(),
      useOfFunds = useOfFunds.trim(),
      pitchDeckUrl = pitchDeckUrl.trim(),
      status = "ACTIVE",
      privacyLevel = privacyLevel,
      isVerified = true,
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertInvestmentOpportunity(opportunity)
      Result.success(opportunity)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateInvestmentOpportunity(
    opportunityId: String,
    companyName: String,
    tagline: String,
    industry: String,
    stage: String,
    targetAmount: String,
    raisedSoFar: String,
    instrumentType: String,
    equityOffered: String,
    minTicket: String,
    location: String,
    pitchSummary: String,
    tractionAndMetrics: String,
    useOfFunds: String,
    pitchDeckUrl: String,
    status: String,
    privacyLevel: String
  ): Result<CatchyInvestmentOpportunity> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getInvestmentOpportunityById(opportunityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Opportunity not found."))

    if (existing.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the creator can edit this opportunity."))
    }

    val updated = existing.copy(
      companyName = companyName.trim(),
      tagline = tagline.trim(),
      industry = industry.trim(),
      stage = stage.trim(),
      targetAmount = targetAmount.trim(),
      raisedSoFar = raisedSoFar.trim(),
      instrumentType = instrumentType.trim(),
      equityOffered = equityOffered.trim(),
      minTicket = minTicket.trim(),
      location = location.trim(),
      pitchSummary = pitchSummary.trim(),
      tractionAndMetrics = tractionAndMetrics.trim(),
      useOfFunds = useOfFunds.trim(),
      pitchDeckUrl = pitchDeckUrl.trim(),
      status = status,
      privacyLevel = privacyLevel,
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.updateInvestmentOpportunity(updated)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun closeInvestmentOpportunity(opportunityId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getInvestmentOpportunityById(opportunityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Opportunity not found."))

    if (existing.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the creator can close this opportunity."))
    }

    try {
      dao.updateOpportunityStatus(opportunityId, "CLOSED", System.currentTimeMillis())
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteInvestmentOpportunity(opportunityId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getInvestmentOpportunityById(opportunityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Opportunity not found."))

    if (existing.creatorUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the creator can delete this opportunity."))
    }

    try {
      dao.deleteInvestmentOpportunity(opportunityId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun submitInvestmentRequest(
    opportunityId: String,
    proposedAmount: String,
    messageNote: String,
    termsOrInquiry: String
  ): Result<CatchyInvestmentRequest> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to submit investment interest."))

    val opportunity = dao.getInvestmentOpportunityById(opportunityId)
      ?: return@withContext Result.failure(IllegalArgumentException("Opportunity not found."))

    if (opportunity.creatorUserId == currentUser.userId) {
      return@withContext Result.failure(IllegalStateException("Founders cannot invest in their own opportunity."))
    }

    // Prevent duplicate investment requests
    val existing = dao.getExistingInvestmentRequest(opportunityId, currentUser.userId)
    if (existing != null) {
      return@withContext Result.failure(IllegalStateException("You have already submitted an investment request for this opportunity (Status: ${existing.status})."))
    }

    val investorProfile = dao.getInvestorProfileSync(currentUser.userId)

    val request = CatchyInvestmentRequest(
      requestId = "REQ-${UUID.randomUUID().toString().take(8).uppercase()}",
      opportunityId = opportunityId,
      opportunityTitle = opportunity.companyName + " - " + opportunity.tagline,
      companyName = opportunity.companyName,
      founderUserId = opportunity.creatorUserId,
      investorUserId = currentUser.userId,
      investorName = currentUser.fullName,
      investorEmail = currentUser.email,
      investorType = investorProfile?.investorType ?: "Angel Investor",
      proposedAmount = proposedAmount.trim(),
      messageNote = messageNote.trim(),
      termsOrInquiry = termsOrInquiry.trim(),
      status = "PENDING",
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertInvestmentRequest(request)
      Result.success(request)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeInvestorRequests(investorUserId: String): Flow<List<CatchyInvestmentRequest>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getInvestmentRequestsByInvestor(investorUserId)
  }

  fun observeFounderRequests(founderUserId: String): Flow<List<CatchyInvestmentRequest>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getInvestmentRequestsForFounder(founderUserId)
  }

  fun observeOpportunityRequests(opportunityId: String): Flow<List<CatchyInvestmentRequest>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getInvestmentRequestsForOpportunity(opportunityId)
  }

  suspend fun updateInvestmentRequestStatus(
    requestId: String,
    newStatus: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not available"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    try {
      dao.updateInvestmentRequestStatus(requestId, newStatus, System.currentTimeMillis())
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // Profiles
  fun observeInvestorProfile(userId: String): Flow<CatchyInvestorProfile?> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getInvestorProfile(userId)
  }

  suspend fun saveInvestorProfile(profile: CatchyInvestorProfile): Result<CatchyInvestorProfile> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    if (profile.userId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized profile update."))
    }

    try {
      dao.insertOrUpdateInvestorProfile(profile.copy(updatedAt = System.currentTimeMillis()))
      Result.success(profile)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeFounderProfile(userId: String): Flow<CatchyFounderProfile?> {
    val dao = socialDao ?: return emptyFlow()
    return dao.getFounderProfile(userId)
  }

  suspend fun saveFounderProfile(profile: CatchyFounderProfile): Result<CatchyFounderProfile> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    if (profile.userId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized profile update."))
    }

    try {
      dao.insertOrUpdateFounderProfile(profile.copy(updatedAt = System.currentTimeMillis()))
      Result.success(profile)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // ==========================================
  // Catchy Business / Business Page Operations
  // ==========================================

  fun observeActiveBusinessPages(): Flow<List<CatchyBusinessPage>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeActiveBusinessPages()
  }

  fun observeBusinessPagesByOwner(ownerUserId: String): Flow<List<CatchyBusinessPage>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeBusinessPagesByOwner(ownerUserId)
  }

  suspend fun getBusinessPageById(pageId: String): CatchyBusinessPage? = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext null
    dao.getBusinessPageById(pageId)
  }

  suspend fun createBusinessPage(
    name: String,
    handle: String,
    category: String,
    tagline: String,
    description: String,
    email: String,
    phone: String,
    website: String,
    location: String,
    operatingHours: String
  ): Result<CatchyBusinessPage> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to create a business page."))

    val cleanName = name.trim()
    var cleanHandle = handle.trim().removePrefix("@").lowercase()
    if (cleanName.isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Business name is required."))
    }
    if (cleanHandle.isBlank()) {
      cleanHandle = cleanName.lowercase().replace(Regex("[^a-z0-9]"), "")
    }

    // Check handle collision
    val existing = dao.getBusinessPageByHandle("@$cleanHandle")
    if (existing != null) {
      cleanHandle = "$cleanHandle${(100..999).random()}"
    }

    val page = CatchyBusinessPage(
      ownerUserId = currentUser.userId,
      name = cleanName,
      handle = "@$cleanHandle",
      category = category.trim().ifBlank { "Other" },
      tagline = tagline.trim(),
      description = description.trim(),
      email = email.trim(),
      phone = phone.trim(),
      website = website.trim(),
      location = location.trim(),
      operatingHours = operatingHours.trim(),
      isVerified = true,
      followersCount = 0,
      status = "ACTIVE",
      createdAt = System.currentTimeMillis(),
      updatedAt = System.currentTimeMillis()
    )

    try {
      dao.insertBusinessPage(page)
      Result.success(page)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateBusinessPage(page: CatchyBusinessPage): Result<CatchyBusinessPage> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getBusinessPageById(page.pageId)
      ?: return@withContext Result.failure(NoSuchElementException("Business page not found."))

    if (existing.ownerUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the page owner can edit this page."))
    }

    try {
      val updated = page.copy(updatedAt = System.currentTimeMillis())
      dao.updateBusinessPage(updated)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteBusinessPage(pageId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val existing = dao.getBusinessPageById(pageId)
      ?: return@withContext Result.failure(NoSuchElementException("Business page not found."))

    if (existing.ownerUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the owner can delete this page."))
    }

    try {
      dao.deleteBusinessPage(pageId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // Business Posts
  fun observePostsByBusinessPage(pageId: String): Flow<List<CatchyBusinessPost>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observePostsByPage(pageId)
  }

  suspend fun createBusinessPost(
    pageId: String,
    content: String,
    mediaUrl: String = ""
  ): Result<CatchyBusinessPost> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val page = dao.getBusinessPageById(pageId)
      ?: return@withContext Result.failure(NoSuchElementException("Page not found."))

    if (page.ownerUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized: Only the owner can publish updates."))
    }

    if (content.trim().isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Post content cannot be empty."))
    }

    val post = CatchyBusinessPost(
      pageId = pageId,
      authorUserId = currentUser.userId,
      content = content.trim(),
      mediaUrl = mediaUrl.trim(),
      likesCount = 0,
      createdAt = System.currentTimeMillis()
    )

    try {
      dao.insertBusinessPost(post)
      Result.success(post)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteBusinessPost(pageId: String, postId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    val page = dao.getBusinessPageById(pageId)
      ?: return@withContext Result.failure(NoSuchElementException("Page not found."))

    if (page.ownerUserId != currentUser.userId) {
      return@withContext Result.failure(SecurityException("Unauthorized."))
    }

    try {
      dao.deleteBusinessPost(postId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // Business Follows
  fun isUserFollowingBusinessPage(pageId: String, userId: String): Flow<Boolean> {
    val dao = socialDao ?: return emptyFlow()
    return dao.isUserFollowingPage(pageId, userId)
  }

  suspend fun toggleFollowBusinessPage(pageId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Authentication required."))

    try {
      val isFollowing = dao.deleteBusinessPageFollow(pageId, currentUser.userId) > 0
      if (isFollowing) {
        dao.updatePageFollowersCount(pageId, -1)
        Result.success(false)
      } else {
        val follow = CatchyBusinessPageFollow(
          pageId = pageId,
          userId = currentUser.userId,
          followedAt = System.currentTimeMillis()
        )
        dao.insertBusinessPageFollow(follow)
        dao.updatePageFollowersCount(pageId, 1)
        Result.success(true)
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun observeFollowedBusinessPages(userId: String): Flow<List<CatchyBusinessPage>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeFollowedPages(userId)
  }

  // Business Inquiries
  fun observeInquiriesForOwner(ownerUserId: String): Flow<List<CatchyBusinessInquiry>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeInquiriesForOwner(ownerUserId)
  }

  fun observeInquiriesForPage(pageId: String): Flow<List<CatchyBusinessInquiry>> {
    val dao = socialDao ?: return emptyFlow()
    return dao.observeInquiriesByPage(pageId)
  }

  suspend fun submitBusinessInquiry(
    pageId: String,
    subject: String,
    message: String
  ): Result<CatchyBusinessInquiry> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    val currentUser = _currentUser.value
      ?: return@withContext Result.failure(IllegalStateException("Please log in to send an inquiry."))

    val page = dao.getBusinessPageById(pageId)
      ?: return@withContext Result.failure(NoSuchElementException("Business page not found."))

    if (page.ownerUserId == currentUser.userId) {
      return@withContext Result.failure(IllegalArgumentException("You cannot send an inquiry to your own business page."))
    }

    if (subject.trim().isBlank() || message.trim().isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("Subject and message are required."))
    }

    val inquiry = CatchyBusinessInquiry(
      pageId = pageId,
      pageName = page.name,
      senderUserId = currentUser.userId,
      senderName = currentUser.fullName,
      senderEmail = currentUser.email ?: "N/A",
      subject = subject.trim(),
      message = message.trim(),
      status = "NEW",
      createdAt = System.currentTimeMillis()
    )

    try {
      dao.insertBusinessInquiry(inquiry)
      Result.success(inquiry)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateInquiryStatus(inquiryId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    try {
      dao.updateInquiryStatus(inquiryId, status)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteInquiry(inquiryId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val dao = socialDao ?: return@withContext Result.failure(IllegalStateException("Database not ready"))
    try {
      dao.deleteInquiry(inquiryId)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
