package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CatchyDatabase
import com.example.data.model.UserAccount
import com.example.data.repository.AccountRepository
import com.example.data.security.CatchySecurity
import com.example.ui.viewmodel.AccountViewModel
import com.example.ui.viewmodel.CatchyNavTab
import com.example.ui.viewmodel.CatchyScreen
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProfileSystemTest {

  private lateinit var app: Application
  private lateinit var db: CatchyDatabase
  private lateinit var repository: AccountRepository

  @Before
  fun setup() {
    app = ApplicationProvider.getApplicationContext()
    db = CatchyDatabase.getInstance(app)
    repository = AccountRepository(db.userDao(), db.socialDao())
  }

  @Test
  fun `test account isolation between logged in users`() = runBlocking {
    // 1. Create Account A
    val resA = repository.createAccount(
      fullName = "Alice Smith",
      email = "alice@example.com",
      dateOfBirth = "1995-03-10",
      gender = "Female",
      addressLocation = "Sylhet, Bangladesh",
      educationStatus = "Graduate",
      occupationStatus = "Designer",
      skills = "Figma, UI",
      maritalStatus = "Single",
      password = "Password123!",
      confirmPassword = "Password123!",
      profilePhotoUri = null,
      termsAccepted = true
    )
    val userA = (resA as com.example.data.repository.AuthResult.Success<UserAccount>).data
    assertTrue("User ID must start with CTY-", userA.userId.startsWith("CTY-"))

    // Login as Account A
    val loginA = repository.login(userA.userId, "Password123!")
    assertTrue(loginA is com.example.data.repository.AuthResult.Success<*>)
    val currentA = repository.currentUser.value
    assertNotNull(currentA)
    assertEquals(userA.userId, currentA?.userId)
    assertEquals("Alice Smith", currentA?.fullName)

    // Clear session & Login as Account B
    val resB = repository.createAccount(
      fullName = "Bob Rahman",
      email = "bob@example.com",
      dateOfBirth = "1992-07-22",
      gender = "Male",
      addressLocation = "Khulna, Bangladesh",
      educationStatus = "Postgraduate",
      occupationStatus = "Engineer",
      skills = "Kotlin, Architecture",
      maritalStatus = "Married",
      password = "Password123!",
      confirmPassword = "Password123!",
      profilePhotoUri = null,
      termsAccepted = true
    )
    val userB = (resB as com.example.data.repository.AuthResult.Success<UserAccount>).data

    repository.login(userB.userId, "Password123!")
    val currentB = repository.currentUser.value
    assertNotNull(currentB)
    assertEquals(userB.userId, currentB?.userId)
    assertEquals("Bob Rahman", currentB?.fullName)
    // Never mix user information
    assertTrue(currentB?.userId != currentA?.userId)
  }

  @Test
  fun `test user id is immutable and only full name and bio are editable`() = runBlocking {
    val res = repository.createAccount(
      fullName = "Initial Name",
      email = "immutable.test@example.com",
      dateOfBirth = "1990-01-01",
      gender = "Male",
      addressLocation = "Dhaka",
      educationStatus = "Student",
      occupationStatus = "Intern",
      skills = "Coding",
      maritalStatus = "Single",
      password = "Password123!",
      confirmPassword = "Password123!",
      profilePhotoUri = null,
      termsAccepted = true
    )
    val user = (res as com.example.data.repository.AuthResult.Success<UserAccount>).data
    val originalUserId = user.userId
    val originalDob = user.dateOfBirth
    val originalEmail = user.email

    repository.login(originalUserId, "Password123!")

    // Update editable profile details
    val updateRes = repository.updateEditableProfile(
      newFullName = "Updated Name",
      newPhotoUri = "avatar_3",
      newBio = "New inspiring bio on Catchy."
    )
    assertTrue(updateRes is com.example.data.repository.AuthResult.Success)

    val updatedUser = repository.currentUser.value
    assertNotNull(updatedUser)
    // User ID is strictly unchanged
    assertEquals(originalUserId, updatedUser?.userId)
    // Core details are strictly locked
    assertEquals(originalDob, updatedUser?.dateOfBirth)
    assertEquals(originalEmail, updatedUser?.email)
    // Editable details are updated
    assertEquals("Updated Name", updatedUser?.fullName)
    assertEquals("avatar_3", updatedUser?.profilePhotoUri)
    assertEquals("New inspiring bio on Catchy.", updatedUser?.bio)
  }

  @Test
  fun `test social follow and direct chat between users`() = runBlocking {
    // Seed Rahim and Tahmina
    repository.seedCatchyCommunityIfEmpty()

    val rahim = repository.getUserByUserId("CTY-8F42K7")
    val tahmina = repository.getUserByUserId("CTY-3B91P2")
    assertNotNull("Rahim must exist", rahim)
    assertNotNull("Tahmina must exist", tahmina)

    // Login as Rahim
    repository.login("CTY-8F42K7", "CatchyPass123!")

    // Rahim follows Tahmina
    val followed = repository.toggleFollow("CTY-3B91P2")
    assertTrue("Should now be following Tahmina", followed)

    // Rahim messages Tahmina
    val conv = repository.getOrCreateConversation("CTY-3B91P2")
    assertNotNull(conv)

    val sent = repository.sendMessage("CTY-3B91P2", "Hey Tahmina! Great seeing your design work.")
    assertTrue("Message should be sent", sent)

    // Opening conversation again must reuse the same conversationId without duplication
    val convAgain = repository.getOrCreateConversation("CTY-3B91P2")
    assertEquals(conv?.conversationId, convAgain?.conversationId)
  }

  @Test
  fun `test user can publish posts from profile`() = runBlocking {
    repository.seedCatchyCommunityIfEmpty()
    repository.login("CTY-8F42K7", "CatchyPass123!")

    val post = repository.createPost("Excited to share updates on Catchy!")
    assertNotNull(post)
    assertEquals("CTY-8F42K7", post?.authorUserId)
    assertEquals("Excited to share updates on Catchy!", post?.content)
  }

  @Test
  fun `test post creation with photo and video attachments`() = runBlocking {
    repository.seedCatchyCommunityIfEmpty()
    repository.login("CTY-8F42K7", "CatchyPass123!")

    val photoPost = repository.createPost(
      content = "Sunset at the beach",
      attachmentType = "photo",
      attachmentLabel = "Catchy Moments Snapshot"
    )
    assertNotNull(photoPost)
    assertEquals("photo", photoPost?.attachmentType)
    assertEquals("Catchy Moments Snapshot", photoPost?.attachmentLabel)

    val videoPost = repository.createPost(
      content = "Tech demo preview",
      attachmentType = "video",
      attachmentLabel = "Catchy Short Clip"
    )
    assertNotNull(videoPost)
    assertEquals("video", videoPost?.attachmentType)
    assertEquals("Catchy Short Clip", videoPost?.attachmentLabel)
  }

  @Test
  fun `test bottom navigation tabs structure`() {
    val tabs = CatchyNavTab.values()
    assertEquals(4, tabs.size)
    assertEquals(CatchyNavTab.HOME, tabs[0])
    assertEquals(CatchyNavTab.CHAT, tabs[1])
    assertEquals(CatchyNavTab.REELS, tabs[2])
    assertEquals(CatchyNavTab.PROFILE, tabs[3])
  }

  @Test
  fun `test home viewmodel state and controls`() = runBlocking {
    val viewModel = AccountViewModel(app)
    assertEquals(CatchyNavTab.HOME, viewModel.currentTab.value)

    // Test search state
    viewModel.onHomeSearchQueryChange("Rahim")
    assertEquals("Rahim", viewModel.homeSearchQuery.value)
    viewModel.clearHomeSearchQuery()
    assertEquals("", viewModel.homeSearchQuery.value)

    // Test help dialog state
    assertFalse(viewModel.showHelpDialog.value)
    viewModel.openHelpDialog()
    assertTrue(viewModel.showHelpDialog.value)
    viewModel.closeHelpDialog()
    assertFalse(viewModel.showHelpDialog.value)

    // Test menu sheet state
    assertFalse(viewModel.showCatchyMenuSheet.value)
    viewModel.openCatchyMenu()
    assertTrue(viewModel.showCatchyMenuSheet.value)
    viewModel.closeCatchyMenu()
    assertFalse(viewModel.showCatchyMenuSheet.value)

    // Test notification sheet state
    assertFalse(viewModel.showNotificationsSheet.value)
    viewModel.openNotifications()
    assertTrue(viewModel.showNotificationsSheet.value)
    viewModel.closeNotifications()
    assertFalse(viewModel.showNotificationsSheet.value)
  }

  @Test
  fun `test home feed post creation and comment flow`() = runBlocking {
    // Ensure community seed is finished before ViewModel starts
    repository.seedCatchyCommunityIfEmpty()
    val viewModel = AccountViewModel(app)
    kotlinx.coroutines.delay(100)

    // 1. Enter text in "What's on your mind?" and verify Post button enabled condition
    assertEquals("", viewModel.newPostInput.value)
    val isInitiallyEnabled = viewModel.newPostInput.value.isNotBlank() || viewModel.postAttachmentType.value != null
    assertFalse("Post button must be disabled initially", isInitiallyEnabled)

    viewModel.onNewPostInputChange("Connecting authentically on Catchy today! #CatchyCommunity")
    assertEquals("Connecting authentically on Catchy today! #CatchyCommunity", viewModel.newPostInput.value)
    val isEnabledAfterInput = viewModel.newPostInput.value.isNotBlank() || viewModel.postAttachmentType.value != null
    assertTrue("Post button must be enabled when text is entered", isEnabledAfterInput)

    // Publish post
    viewModel.publishPost().join()
    assertEquals("", viewModel.newPostInput.value)

    val posts = db.socialDao().getAllPostsSync()
    val savedPost = posts.find { it.content.contains("Connecting authentically on Catchy today!") }
    assertNotNull("Created post must be persisted in database", savedPost)
    assertEquals(0, savedPost!!.commentsCount)

    // 2. Open Comment on an existing feed post
    assertNull(viewModel.activeCommentPost.value)
    viewModel.openComments(savedPost)
    assertNotNull(viewModel.activeCommentPost.value)
    assertEquals(savedPost.id, viewModel.activeCommentPost.value?.id)

    // 3. Type a comment and submit it
    assertEquals("", viewModel.commentInput.value)
    viewModel.onCommentInputChange("This is a genuine real-time comment!")
    assertEquals("This is a genuine real-time comment!", viewModel.commentInput.value)
    viewModel.submitComment().join()

    // Verify comment input reset
    assertEquals("", viewModel.commentInput.value)

    // 4. Verify comment is saved and appears under the post
    val comments = db.socialDao().getCommentsForPostSync(savedPost.id)
    assertEquals(1, comments.size)
    assertEquals("This is a genuine real-time comment!", comments[0].content)

    // 5. Verify comment count updates
    val updatedPost = repository.getPostById(savedPost.id)
    assertNotNull(updatedPost)
    assertEquals(1, updatedPost!!.commentsCount)
    assertEquals(1, viewModel.activeCommentPost.value?.commentsCount)
  }

  @Test
  fun `test chat system navigation conversation list send receive reply and rich messages`() = runBlocking {
    repository.seedCatchyCommunityIfEmpty()
    val viewModel = AccountViewModel(app, repository)

    // Login as Rahim (CTY-8F42K7)
    repository.login("CTY-8F42K7", "CatchyPass123!")
    assertEquals("CTY-8F42K7", viewModel.currentUser.value?.userId)

    // 1. Users can open Chat from bottom navigation
    viewModel.selectTab(CatchyNavTab.CHAT)
    assertEquals(CatchyNavTab.CHAT, viewModel.currentTab.value)
    assertNull("Opening Chat from bottom navigation shows conversation list (no active chat user)", viewModel.activeChatUser.value)

    // 2. Conversation list works
    val otherUsers = viewModel.otherUsers.value
    assertTrue("Other community members should be present in conversation list", otherUsers.isNotEmpty())
    val tahmina = otherUsers.find { it.userId == "CTY-3B91P2" }
    assertNotNull("Tahmina must be in community member conversation list", tahmina)

    // 3. Users can open a conversation
    viewModel.openChatWithUser(tahmina!!).join()
    assertEquals("CTY-3B91P2", viewModel.activeChatUser.value?.userId)
    assertEquals(CatchyNavTab.CHAT, viewModel.currentTab.value)
    val convId = viewModel.activeConversationId.value
    assertNotNull("Active conversationId must be established", convId)

    // 4. Messages can be sent and saved
    viewModel.onChatMessageInputChange("Hello Tahmina! Checking in on our Catchy project.")
    assertEquals("Hello Tahmina! Checking in on our Catchy project.", viewModel.chatMessageInput.value)
    viewModel.sendChatMessage().join()

    // Verify input cleared
    assertEquals("", viewModel.chatMessageInput.value)

    // 5. Messages appear correctly in conversation and database
    val messages = db.socialDao().getMessagesForConversationSync(convId!!)
    assertTrue("At least 1 message should be saved", messages.isNotEmpty())
    val firstMsg = messages.find { it.content == "Hello Tahmina! Checking in on our Catchy project." }
    assertNotNull("Message must be saved in database", firstMsg)
    assertEquals("CTY-8F42K7", firstMsg!!.senderUserId)
    assertEquals("CTY-3B91P2", firstMsg.receiverUserId)
    assertEquals("delivered", firstMsg.status)
    assertTrue("Timestamp must be valid", firstMsg.sentAt > 0)

    // 6. Test Reply Feature
    viewModel.setReplyMessage(firstMsg)
    assertEquals(firstMsg.id, viewModel.replyMessage.value?.id)
    viewModel.onChatMessageInputChange("Replying to previous note.")
    viewModel.sendChatMessage().join()
    assertNull("Reply message state should be reset after sending", viewModel.replyMessage.value)

    val updatedMessages = db.socialDao().getMessagesForConversationSync(convId)
    val replyMsg = updatedMessages.find { it.content == "Replying to previous note." }
    assertNotNull("Reply message must be saved", replyMsg)
    assertEquals(firstMsg.id, replyMsg!!.replyToMessageId)
    assertEquals("Hello Tahmina! Checking in on our Catchy project.", replyMsg.replyToText)

    // 7. Test Media and Voice Options
    // Media snap
    viewModel.sendRichMessage(mediaType = "photo", mediaLabel = "Catchy Snap").join()
    val mediaMsg = db.socialDao().getMessagesForConversationSync(convId).find { it.mediaType == "photo" }
    assertNotNull("Photo media message must be recorded", mediaMsg)
    assertEquals("Catchy Snap", mediaMsg!!.mediaLabel)

    // Voice note
    viewModel.sendVoiceNote(seconds = 6).join()
    val voiceMsg = db.socialDao().getMessagesForConversationSync(convId).find { it.mediaType == "voice" }
    assertNotNull("Voice note message must be recorded", voiceMsg)
    assertTrue(voiceMsg!!.content.contains("Voice Message (6s)"))

    // 8. Test Message Deletion
    viewModel.deleteDirectMessage(replyMsg.id).join()
    val afterDeleteMessages = db.socialDao().getMessagesForConversationSync(convId)
    assertNull("Deleted message should no longer exist", afterDeleteMessages.find { it.id == replyMsg.id })

    // 9. Close chat returns to conversation list
    viewModel.closeChat()
    assertNull(viewModel.activeChatUser.value)
    assertNull(viewModel.activeConversationId.value)

    // Verify conversation record exists in database with last message
    val conversationRecord = db.socialDao().getConversation(convId)
    assertNotNull("Conversation record must be persisted", conversationRecord)
    assertTrue(conversationRecord!!.lastMessage.isNotBlank())
  }
}
